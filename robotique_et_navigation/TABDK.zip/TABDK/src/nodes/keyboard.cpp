#include <TABDK/MoveAction.h>
#include <TABDK/global_control.h>
#include <TABDK/set_mode.h>
#include <actionlib/client/simple_action_client.h>
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <std_msgs/Empty.h>
#include <std_msgs/String.h>

#include <cmath>
#include <cstdio>
#include <string>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>

const int KEY_M = 109;
const int KEY_P = 112;
const int KEY_R = 114;
const int KEY_SYNC = 33;
const double PAS_CIBLE = 0.1;
const double SEUIL_ARRET = 0.01;
const int MESURES_ARRET = 3;
const double DELAI_SYNCHRONISATION = 10.0;

class ClavierClient {
public:
  explicit ClavierClient(ros::NodeHandle &nh)
      : action_("/move", true) {
    mode_ = nh.serviceClient<TABDK::set_mode>("/set_mode");
    global_ = nh.serviceClient<TABDK::global_control>("/global_control");
    odom_ = nh.subscribe("/odom", 10, &ClavierClient::odometryCallback, this);
    reset_ = nh.subscribe("/reset", 10, &ClavierClient::resetCallback, this);
    etat_mode_ = nh.subscribe("/mode", 1, &ClavierClient::modeCallback, this);
  }

  void touche(int key) {
    if (key == KEY_M) {
      TABDK::set_mode srv;
      srv.request.mode = "toggle";
      if (!mode_.call(srv) || !srv.response.success) {
        ROS_WARN("Changement de mode impossible");
      }
    } else if (key == KEY_P || key == KEY_R) {
      TABDK::global_control srv;
      srv.request.command = key == KEY_P ? "play_pause" : "reset";
      if (!global_.call(srv) || !srv.response.success) {
        ROS_WARN("Commande globale impossible");
      }
    } else if (key == KEY_SYNC) {
      if (modeManuel()) {
        TABDK::global_control srv;
        srv.request.command = "stop";
        if (!global_.call(srv) || !srv.response.success) {
          ROS_WARN("Arret refuse ou service /global_control indisponible");
          return;
        }
        synchronisation_ = true;
        mesures_arret_ = 0;
        debut_sync_ = ros::WallTime::now();
        ROS_INFO("Attente de l'arret du robot avant synchronisation de la cible");
      }
    }
  }

  void fleche(int key) {
    if (synchronisation_) {
      ROS_WARN("Synchronisation de la cible en cours");
      return;
    }
    if (!modeManuel()) {
      return;
    }
    if (!action_.isServerConnected() && !action_.waitForServer(ros::Duration(2.0))) {
      ROS_WARN("Serveur /move indisponible");
      return;
    }
    switch (key) {
      case 'A': cible_x_ += PAS_CIBLE; break;
      case 'B': cible_x_ -= PAS_CIBLE; break;
      case 'D': cible_y_ -= PAS_CIBLE; break;
      case 'C': cible_y_ += PAS_CIBLE; break;
      default: return;
    }
    TABDK::MoveGoal goal;
    goal.position_x = cible_x_;
    goal.position_y = cible_y_;
    action_.sendGoal(goal);
    ROS_INFO("Cible clavier : (%.2f, %.2f)", cible_x_, cible_y_);
  }

  void update() {
    if (synchronisation_ &&
        (ros::WallTime::now() - debut_sync_).toSec() > DELAI_SYNCHRONISATION) {
      synchronisation_ = false;
      ROS_WARN("Synchronisation impossible : arret non confirme par l'odometrie");
    }
  }

private:
  actionlib::SimpleActionClient<TABDK::MoveAction> action_;
  ros::ServiceClient mode_, global_;
  ros::Subscriber odom_, reset_, etat_mode_;
  double cible_x_ = 0.0, cible_y_ = 0.0;
  bool synchronisation_ = false;
  int mesures_arret_ = 0;
  ros::WallTime debut_sync_;
  std::string mode_courant_;

  bool modeManuel() const {
    if (mode_courant_ != "manual") {
      ROS_WARN("Commande reservee au mode manuel (mode connu : %s)",
               mode_courant_.empty() ? "inconnu" : mode_courant_.c_str());
      return false;
    }
    return true;
  }

  void modeCallback(const std_msgs::String::ConstPtr &msg) {
    mode_courant_ = msg->data;
    if (mode_courant_ != "manual" && synchronisation_) {
      synchronisation_ = false;
      ROS_WARN("Synchronisation annulee : le robot n'est plus en mode manuel");
    }
  }

  void resetCallback(const std_msgs::Empty::ConstPtr &) {
    cible_x_ = cible_y_ = 0.0;
    synchronisation_ = false;
    ROS_INFO("Cible clavier reinitialisee");
  }

  void odometryCallback(const nav_msgs::Odometry::ConstPtr &msg) {
    if (!synchronisation_) {
      return;
    }
    const geometry_msgs::Twist &v = msg->twist.twist;
    const double lineaire = std::sqrt(v.linear.x * v.linear.x +
                                      v.linear.y * v.linear.y + v.linear.z * v.linear.z);
    const double angulaire = std::sqrt(v.angular.x * v.angular.x +
                                       v.angular.y * v.angular.y + v.angular.z * v.angular.z);
    mesures_arret_ = lineaire < SEUIL_ARRET && angulaire < SEUIL_ARRET
                         ? mesures_arret_ + 1 : 0;
    if (mesures_arret_ >= MESURES_ARRET) {
      synchronisation_ = false;
      if (!modeManuel()) {
        return;
      }
      cible_x_ = msg->pose.pose.position.x;
      cible_y_ = msg->pose.pose.position.y;
      ROS_INFO("Cible clavier synchronisee : (%.2f, %.2f)", cible_x_, cible_y_);
    }
  }
};

int main(int argc, char **argv) {
  ros::init(argc, argv, "key_input_node");
  ros::NodeHandle nh;
  ClavierClient clavier(nh);
  termios ancien;
  if (tcgetattr(STDIN_FILENO, &ancien) != 0) {
    ROS_ERROR("Impossible de lire la configuration du terminal");
    return 1;
  }
  termios mode = ancien;
  mode.c_lflag &= ~(ICANON | ECHO);
  if (tcsetattr(STDIN_FILENO, TCSANOW, &mode) != 0) {
    ROS_ERROR("Impossible de configurer le terminal");
    return 1;
  }
  int sequence = 0;
  while (ros::ok()) {
    ros::spinOnce();
    clavier.update();
    fd_set input;
    FD_ZERO(&input);
    FD_SET(STDIN_FILENO, &input);
    timeval timeout = {0, 100000};
    const int ready = select(STDIN_FILENO + 1, &input, nullptr, nullptr, &timeout);
    if (ready < 0) {
      if (ros::ok()) ROS_ERROR("Erreur de lecture du clavier");
      break;
    }
    if (ready == 0) continue;
    unsigned char key;
    if (read(STDIN_FILENO, &key, 1) != 1) {
      ROS_WARN("Lecture du clavier terminee");
      break;
    }
    if (sequence == 0 && key == 27) {
      sequence = 1;
    } else if (sequence == 1 && key == '[') {
      sequence = 2;
    } else if (sequence == 2) {
      clavier.fleche(key);
      sequence = 0;
    } else {
      sequence = 0;
      clavier.touche(key);
    }
  }
  if (tcsetattr(STDIN_FILENO, TCSANOW, &ancien) != 0) {
    ROS_ERROR("Impossible de restaurer la configuration du terminal");
    return 1;
  }
  return 0;
}
