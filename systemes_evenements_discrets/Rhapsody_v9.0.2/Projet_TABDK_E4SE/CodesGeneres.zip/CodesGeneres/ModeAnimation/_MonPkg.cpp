/********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _MonPkg
//!	Generated Date	: Wed, 21, Oct 2026  
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "_MonPkg.h"
//## auto_generated
#include "_SysVehicule.h"
//#[ ignore
#define Push_Carburant_SERIALIZE OM_NO_OP

#define Push_Carburant_UNSERIALIZE OM_NO_OP

#define Push_Carburant_CONSTRUCTOR Push_Carburant()

#define cablage_SERIALIZE OM_NO_OP

#define cablage_UNSERIALIZE OM_NO_OP

#define cablage_CONSTRUCTOR cablage()

#define f_SERIALIZE OM_NO_OP

#define f_UNSERIALIZE OM_NO_OP

#define f_CONSTRUCTOR f()

#define Operation_108_SERIALIZE OM_NO_OP

#define Operation_108_UNSERIALIZE OM_NO_OP

#define Operation_108_CONSTRUCTOR Operation_108()

#define decr_vitesseConsigne_SERIALIZE OM_NO_OP

#define decr_vitesseConsigne_UNSERIALIZE OM_NO_OP

#define decr_vitesseConsigne_CONSTRUCTOR decr_vitesseConsigne()

#define incr_vitesseConsigne_SERIALIZE OM_NO_OP

#define incr_vitesseConsigne_UNSERIALIZE OM_NO_OP

#define incr_vitesseConsigne_CONSTRUCTOR incr_vitesseConsigne()

#define ev_Demarrer_SERIALIZE OM_NO_OP

#define ev_Demarrer_UNSERIALIZE OM_NO_OP

#define ev_Demarrer_CONSTRUCTOR ev_Demarrer()

#define evDemarrer_SERIALIZE OM_NO_OP

#define evDemarrer_UNSERIALIZE OM_NO_OP

#define evDemarrer_CONSTRUCTOR evDemarrer()

#define ev_demarrer_SERIALIZE OM_NO_OP

#define ev_demarrer_UNSERIALIZE OM_NO_OP

#define ev_demarrer_CONSTRUCTOR ev_demarrer()

#define ev_depanner_batterie_SERIALIZE OM_NO_OP

#define ev_depanner_batterie_UNSERIALIZE OM_NO_OP

#define ev_depanner_batterie_CONSTRUCTOR ev_depanner_batterie()

#define ev_remplir_carburant_SERIALIZE OM_NO_OP

#define ev_remplir_carburant_UNSERIALIZE OM_NO_OP

#define ev_remplir_carburant_CONSTRUCTOR ev_remplir_carburant()

#define ev_vitesseConsigne_moins_SERIALIZE OM_NO_OP

#define ev_vitesseConsigne_moins_UNSERIALIZE OM_NO_OP

#define ev_vitesseConsigne_moins_CONSTRUCTOR ev_vitesseConsigne_moins()

#define ev_vitesseConsigne_plus_SERIALIZE OM_NO_OP

#define ev_vitesseConsigne_plus_UNSERIALIZE OM_NO_OP

#define ev_vitesseConsigne_plus_CONSTRUCTOR ev_vitesseConsigne_plus()

#define ev__SERIALIZE OM_NO_OP

#define ev__UNSERIALIZE OM_NO_OP

#define ev__CONSTRUCTOR ev_()

#define moteur_SERIALIZE OM_NO_OP

#define moteur_UNSERIALIZE OM_NO_OP

#define moteur_CONSTRUCTOR moteur()

#define t_SERIALIZE OM_NO_OP

#define t_UNSERIALIZE OM_NO_OP

#define t_CONSTRUCTOR t()

#define EVAL_SERIALIZE OM_NO_OP

#define EVAL_UNSERIALIZE OM_NO_OP

#define EVAL_CONSTRUCTOR EVAL()

#define ev_limiteur_SERIALIZE OM_NO_OP

#define ev_limiteur_UNSERIALIZE OM_NO_OP

#define ev_limiteur_CONSTRUCTOR ev_limiteur()

#define ev_regulateur_SERIALIZE OM_NO_OP

#define ev_regulateur_UNSERIALIZE OM_NO_OP

#define ev_regulateur_CONSTRUCTOR ev_regulateur()

#define ev_ok_SERIALIZE OM_NO_OP

#define ev_ok_UNSERIALIZE OM_NO_OP

#define ev_ok_CONSTRUCTOR ev_ok()

#define ev_jumeler_SERIALIZE OM_NO_OP

#define ev_jumeler_UNSERIALIZE OM_NO_OP

#define ev_jumeler_CONSTRUCTOR ev_jumeler()

#define GEN_SERIALIZE OM_NO_OP

#define GEN_UNSERIALIZE OM_NO_OP

#define GEN_CONSTRUCTOR GEN()

#define ev_kit_vehicule_pret_SERIALIZE OM_NO_OP

#define ev_kit_vehicule_pret_UNSERIALIZE OM_NO_OP

#define ev_kit_vehicule_pret_CONSTRUCTOR ev_kit_vehicule_pret()
//#]

//## package _MonPkg


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(_MonPkg, _MonPkg)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

//## event Push_Carburant()
Push_Carburant::Push_Carburant() {
    NOTIFY_EVENT_CONSTRUCTOR(Push_Carburant)
    setId(Push_Carburant__MonPkg_id);
}

bool Push_Carburant::isTypeOf(const short id) const {
    return (Push_Carburant__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(Push_Carburant, _MonPkg, _MonPkg, Push_Carburant())

//## event cablage()
cablage::cablage() {
    NOTIFY_EVENT_CONSTRUCTOR(cablage)
    setId(cablage__MonPkg_id);
}

bool cablage::isTypeOf(const short id) const {
    return (cablage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(cablage, _MonPkg, _MonPkg, cablage())

//## event f()
f::f() {
    NOTIFY_EVENT_CONSTRUCTOR(f)
    setId(f__MonPkg_id);
}

bool f::isTypeOf(const short id) const {
    return (f__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(f, _MonPkg, _MonPkg, f())

//## event Operation_108()
Operation_108::Operation_108() {
    NOTIFY_EVENT_CONSTRUCTOR(Operation_108)
    setId(Operation_108__MonPkg_id);
}

bool Operation_108::isTypeOf(const short id) const {
    return (Operation_108__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(Operation_108, _MonPkg, _MonPkg, Operation_108())

//## event decr_vitesseConsigne()
decr_vitesseConsigne::decr_vitesseConsigne() {
    NOTIFY_EVENT_CONSTRUCTOR(decr_vitesseConsigne)
    setId(decr_vitesseConsigne__MonPkg_id);
}

bool decr_vitesseConsigne::isTypeOf(const short id) const {
    return (decr_vitesseConsigne__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(decr_vitesseConsigne, _MonPkg, _MonPkg, decr_vitesseConsigne())

//## event incr_vitesseConsigne()
incr_vitesseConsigne::incr_vitesseConsigne() {
    NOTIFY_EVENT_CONSTRUCTOR(incr_vitesseConsigne)
    setId(incr_vitesseConsigne__MonPkg_id);
}

bool incr_vitesseConsigne::isTypeOf(const short id) const {
    return (incr_vitesseConsigne__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(incr_vitesseConsigne, _MonPkg, _MonPkg, incr_vitesseConsigne())

//## event ev_Demarrer()
ev_Demarrer::ev_Demarrer() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_Demarrer)
    setId(ev_Demarrer__MonPkg_id);
}

bool ev_Demarrer::isTypeOf(const short id) const {
    return (ev_Demarrer__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_Demarrer, _MonPkg, _MonPkg, ev_Demarrer())

//## event evDemarrer()
evDemarrer::evDemarrer() {
    NOTIFY_EVENT_CONSTRUCTOR(evDemarrer)
    setId(evDemarrer__MonPkg_id);
}

bool evDemarrer::isTypeOf(const short id) const {
    return (evDemarrer__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(evDemarrer, _MonPkg, _MonPkg, evDemarrer())

//## event ev_demarrer()
ev_demarrer::ev_demarrer() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demarrer)
    setId(ev_demarrer__MonPkg_id);
}

bool ev_demarrer::isTypeOf(const short id) const {
    return (ev_demarrer__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demarrer, _MonPkg, _MonPkg, ev_demarrer())

//## event ev_depanner_batterie()
ev_depanner_batterie::ev_depanner_batterie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_depanner_batterie)
    setId(ev_depanner_batterie__MonPkg_id);
}

bool ev_depanner_batterie::isTypeOf(const short id) const {
    return (ev_depanner_batterie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_depanner_batterie, _MonPkg, _MonPkg, ev_depanner_batterie())

//## event ev_remplir_carburant()
ev_remplir_carburant::ev_remplir_carburant() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_remplir_carburant)
    setId(ev_remplir_carburant__MonPkg_id);
}

bool ev_remplir_carburant::isTypeOf(const short id) const {
    return (ev_remplir_carburant__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_remplir_carburant, _MonPkg, _MonPkg, ev_remplir_carburant())

//## event ev_vitesseConsigne_moins()
ev_vitesseConsigne_moins::ev_vitesseConsigne_moins() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_vitesseConsigne_moins)
    setId(ev_vitesseConsigne_moins__MonPkg_id);
}

bool ev_vitesseConsigne_moins::isTypeOf(const short id) const {
    return (ev_vitesseConsigne_moins__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_vitesseConsigne_moins, _MonPkg, _MonPkg, ev_vitesseConsigne_moins())

//## event ev_vitesseConsigne_plus()
ev_vitesseConsigne_plus::ev_vitesseConsigne_plus() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_vitesseConsigne_plus)
    setId(ev_vitesseConsigne_plus__MonPkg_id);
}

bool ev_vitesseConsigne_plus::isTypeOf(const short id) const {
    return (ev_vitesseConsigne_plus__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_vitesseConsigne_plus, _MonPkg, _MonPkg, ev_vitesseConsigne_plus())

//## event ev_()
ev_::ev_() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_)
    setId(ev___MonPkg_id);
}

bool ev_::isTypeOf(const short id) const {
    return (ev___MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_, _MonPkg, _MonPkg, ev_())

//## event moteur()
moteur::moteur() {
    NOTIFY_EVENT_CONSTRUCTOR(moteur)
    setId(moteur__MonPkg_id);
}

bool moteur::isTypeOf(const short id) const {
    return (moteur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(moteur, _MonPkg, _MonPkg, moteur())

//## event t()
t::t() {
    NOTIFY_EVENT_CONSTRUCTOR(t)
    setId(t__MonPkg_id);
}

bool t::isTypeOf(const short id) const {
    return (t__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(t, _MonPkg, _MonPkg, t())

//## event EVAL()
EVAL::EVAL() {
    NOTIFY_EVENT_CONSTRUCTOR(EVAL)
    setId(EVAL__MonPkg_id);
}

bool EVAL::isTypeOf(const short id) const {
    return (EVAL__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(EVAL, _MonPkg, _MonPkg, EVAL())

//## event ev_limiteur()
ev_limiteur::ev_limiteur() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_limiteur)
    setId(ev_limiteur__MonPkg_id);
}

bool ev_limiteur::isTypeOf(const short id) const {
    return (ev_limiteur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_limiteur, _MonPkg, _MonPkg, ev_limiteur())

//## event ev_regulateur()
ev_regulateur::ev_regulateur() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_regulateur)
    setId(ev_regulateur__MonPkg_id);
}

bool ev_regulateur::isTypeOf(const short id) const {
    return (ev_regulateur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_regulateur, _MonPkg, _MonPkg, ev_regulateur())

//## event ev_ok()
ev_ok::ev_ok() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_ok)
    setId(ev_ok__MonPkg_id);
}

bool ev_ok::isTypeOf(const short id) const {
    return (ev_ok__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_ok, _MonPkg, _MonPkg, ev_ok())

//## event ev_jumeler()
ev_jumeler::ev_jumeler() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_jumeler)
    setId(ev_jumeler__MonPkg_id);
}

bool ev_jumeler::isTypeOf(const short id) const {
    return (ev_jumeler__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_jumeler, _MonPkg, _MonPkg, ev_jumeler())

//## event GEN()
GEN::GEN() {
    NOTIFY_EVENT_CONSTRUCTOR(GEN)
    setId(GEN__MonPkg_id);
}

bool GEN::isTypeOf(const short id) const {
    return (GEN__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(GEN, _MonPkg, _MonPkg, GEN())

//## event ev_kit_vehicule_pret()
ev_kit_vehicule_pret::ev_kit_vehicule_pret() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_vehicule_pret)
    setId(ev_kit_vehicule_pret__MonPkg_id);
}

bool ev_kit_vehicule_pret::isTypeOf(const short id) const {
    return (ev_kit_vehicule_pret__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_vehicule_pret, _MonPkg, _MonPkg, ev_kit_vehicule_pret())

/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.cpp
*********************************************************************/
