#ifndef SERVEUR_NAVIGATION_CPP
#define SERVEUR_NAVIGATION_CPP

#include "controleur.cpp"

#include <TABDK/MoveAction.h>
#include <actionlib/server/simple_action_server.h>
#include <boost/bind.hpp>
#include <cmath>
#include <string>

class ServeurNavigation {
public:
  ServeurNavigation(ros::NodeHandle &nh, Controleur &controleur)
      : controleur_(controleur), serveur_(nh, "/move", false) {
    serveur_.registerGoalCallback(boost::bind(&ServeurNavigation::nouvelleCible, this));
    serveur_.registerPreemptCallback(boost::bind(&ServeurNavigation::annuler, this));
    controleur_.definirAnnulationNavigation(
        [this]() { terminer(false, "Navigation annulee par le controleur"); });
    serveur_.start();
  }

  ~ServeurNavigation() {
    controleur_.definirAnnulationNavigation(std::function<void()>());
  }

  void step() {
    if (!serveur_.isActive()) {
      return;
    }
    const geometry_msgs::Pose2D &position = controleur_.position();
    const double distance = std::hypot(cible_x_ - position.x, cible_y_ - position.y);
    TABDK::MoveFeedback feedback;
    feedback.position = position;
    feedback.vitesse = controleur_.vitesse();
    feedback.distance_restante = distance;
    feedback.mode = controleur_.modeNavigation();
    feedback.pause = controleur_.enPause();
    serveur_.publishFeedback(feedback);
    if (controleur_.navigationAtteinte()) {
      terminer(true, "Cible atteinte");
    }
  }

private:
  Controleur &controleur_;
  actionlib::SimpleActionServer<TABDK::MoveAction> serveur_;
  double cible_x_ = 0.0;
  double cible_y_ = 0.0;
  double distance_initiale_ = 0.0;

  TABDK::MoveResult resultat(bool atteint) const {
    TABDK::MoveResult result;
    result.atteint = atteint;
    result.temps_pris = controleur_.tempsNavigation();
    result.distance_parcourue = controleur_.distanceTotale() - distance_initiale_;
    result.position = controleur_.position();
    return result;
  }

  void terminer(bool atteint, const std::string &message) {
    if (!serveur_.isActive()) {
      return;
    }
    controleur_.arreterNavigation();
    const TABDK::MoveResult result = resultat(atteint);
    if (atteint) {
      serveur_.setSucceeded(result, message);
    } else {
      serveur_.setPreempted(result, message);
    }
  }

  void nouvelleCible() {
    terminer(false, "Objectif remplace");
    const TABDK::MoveGoalConstPtr goal = serveur_.acceptNewGoal();
    distance_initiale_ = controleur_.distanceTotale();

    if (serveur_.isPreemptRequested()) {
      TABDK::MoveResult result;
      result.atteint = false;
      result.position = controleur_.position();
      serveur_.setPreempted(result, "Objectif annule avant son demarrage");
    } else if (!controleur_.modeManuel() ||
               !std::isfinite(goal->position_x) || !std::isfinite(goal->position_y)) {
      ROS_WARN("Objectif refuse : mode auto ou coordonnees invalides");
      TABDK::MoveResult result;
      result.atteint = false;
      result.position = controleur_.position();
      serveur_.setAborted(result, "Mode auto ou coordonnees invalides");
    } else {
      cible_x_ = goal->position_x;
      cible_y_ = goal->position_y;
      controleur_.demarrerNavigation(cible_x_, cible_y_);
    }
  }

  void annuler() {
    terminer(false, "Objectif annule");
  }
};

#endif
