/********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _MonPkg
//!	Generated Date	: Thu, 26, Nov 2026  
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "_MonPkg.h"
//## auto_generated
#include "_SysVehicule.h"
//#[ ignore
#define Push_Carburant_SERIALIZE OM_NO_OP

#define Push_Carburant_UNSERIALIZE OM_NO_OP

#define Push_Carburant_CONSTRUCTOR Push_Carburant()

#define cablage_SERIALIZE OM_NO_OP

#define cablage_UNSERIALIZE OM_NO_OP

#define cablage_CONSTRUCTOR cablage()

#define f_SERIALIZE OM_NO_OP

#define f_UNSERIALIZE OM_NO_OP

#define f_CONSTRUCTOR f()

#define Operation_108_SERIALIZE OM_NO_OP

#define Operation_108_UNSERIALIZE OM_NO_OP

#define Operation_108_CONSTRUCTOR Operation_108()

#define decr_vitesseConsigne_SERIALIZE OM_NO_OP

#define decr_vitesseConsigne_UNSERIALIZE OM_NO_OP

#define decr_vitesseConsigne_CONSTRUCTOR decr_vitesseConsigne()

#define incr_vitesseConsigne_SERIALIZE OM_NO_OP

#define incr_vitesseConsigne_UNSERIALIZE OM_NO_OP

#define incr_vitesseConsigne_CONSTRUCTOR incr_vitesseConsigne()

#define ev_Demarrer_SERIALIZE OM_NO_OP

#define ev_Demarrer_UNSERIALIZE OM_NO_OP

#define ev_Demarrer_CONSTRUCTOR ev_Demarrer()

#define evDemarrer_SERIALIZE OM_NO_OP

#define evDemarrer_UNSERIALIZE OM_NO_OP

#define evDemarrer_CONSTRUCTOR evDemarrer()

#define ev_demarrer_SERIALIZE OM_NO_OP

#define ev_demarrer_UNSERIALIZE OM_NO_OP

#define ev_demarrer_CONSTRUCTOR ev_demarrer()

#define ev_depanner_batterie_SERIALIZE OM_NO_OP

#define ev_depanner_batterie_UNSERIALIZE OM_NO_OP

#define ev_depanner_batterie_CONSTRUCTOR ev_depanner_batterie()

#define ev_remplir_carburant_SERIALIZE OM_NO_OP

#define ev_remplir_carburant_UNSERIALIZE OM_NO_OP

#define ev_remplir_carburant_CONSTRUCTOR ev_remplir_carburant()

#define ev_vitesseConsigne_moins_SERIALIZE OM_NO_OP

#define ev_vitesseConsigne_moins_UNSERIALIZE OM_NO_OP

#define ev_vitesseConsigne_moins_CONSTRUCTOR ev_vitesseConsigne_moins()

#define ev_vitesseConsigne_plus_SERIALIZE OM_NO_OP

#define ev_vitesseConsigne_plus_UNSERIALIZE OM_NO_OP

#define ev_vitesseConsigne_plus_CONSTRUCTOR ev_vitesseConsigne_plus()

#define moteur_SERIALIZE OM_NO_OP

#define moteur_UNSERIALIZE OM_NO_OP

#define moteur_CONSTRUCTOR moteur()

#define t_SERIALIZE OM_NO_OP

#define t_UNSERIALIZE OM_NO_OP

#define t_CONSTRUCTOR t()

#define EVAL_SERIALIZE OM_NO_OP

#define EVAL_UNSERIALIZE OM_NO_OP

#define EVAL_CONSTRUCTOR EVAL()

#define ev_limiteur_SERIALIZE OM_NO_OP

#define ev_limiteur_UNSERIALIZE OM_NO_OP

#define ev_limiteur_CONSTRUCTOR ev_limiteur()

#define ev_regulateur_SERIALIZE OM_NO_OP

#define ev_regulateur_UNSERIALIZE OM_NO_OP

#define ev_regulateur_CONSTRUCTOR ev_regulateur()

#define ev_ok_SERIALIZE OM_NO_OP

#define ev_ok_UNSERIALIZE OM_NO_OP

#define ev_ok_CONSTRUCTOR ev_ok()

#define ev_jumeler_SERIALIZE OM_NO_OP

#define ev_jumeler_UNSERIALIZE OM_NO_OP

#define ev_jumeler_CONSTRUCTOR ev_jumeler()

#define ev_kit_vehicule_pret_SERIALIZE OM_NO_OP

#define ev_kit_vehicule_pret_UNSERIALIZE OM_NO_OP

#define ev_kit_vehicule_pret_CONSTRUCTOR ev_kit_vehicule_pret()

#define ev_OK_SERIALIZE OM_NO_OP

#define ev_OK_UNSERIALIZE OM_NO_OP

#define ev_OK_CONSTRUCTOR ev_OK()

#define kit_connecte_SERIALIZE OM_NO_OP

#define kit_connecte_UNSERIALIZE OM_NO_OP

#define kit_connecte_CONSTRUCTOR kit_connecte()

#define connexion_demandee_SERIALIZE OM_NO_OP

#define connexion_demandee_UNSERIALIZE OM_NO_OP

#define connexion_demandee_CONSTRUCTOR connexion_demandee()

#define ev_connexion_demandee_SERIALIZE OM_NO_OP

#define ev_connexion_demandee_UNSERIALIZE OM_NO_OP

#define ev_connexion_demandee_CONSTRUCTOR ev_connexion_demandee()

#define connexion_acceptee_SERIALIZE OM_NO_OP

#define connexion_acceptee_UNSERIALIZE OM_NO_OP

#define connexion_acceptee_CONSTRUCTOR connexion_acceptee()

#define bluetooth_vehicule_desactive_SERIALIZE OM_NO_OP

#define bluetooth_vehicule_desactive_UNSERIALIZE OM_NO_OP

#define bluetooth_vehicule_desactive_CONSTRUCTOR bluetooth_vehicule_desactive()

#define bluetooth_kit_desactive_SERIALIZE OM_NO_OP

#define bluetooth_kit_desactive_UNSERIALIZE OM_NO_OP

#define bluetooth_kit_desactive_CONSTRUCTOR bluetooth_kit_desactive()

#define ev_bluetooth_telephone_desactive_SERIALIZE OM_NO_OP

#define ev_bluetooth_telephone_desactive_UNSERIALIZE OM_NO_OP

#define ev_bluetooth_telephone_desactive_CONSTRUCTOR ev_bluetooth_telephone_desactive()

#define ev_bluetooth_kit_desactive_SERIALIZE OM_NO_OP

#define ev_bluetooth_kit_desactive_UNSERIALIZE OM_NO_OP

#define ev_bluetooth_kit_desactive_CONSTRUCTOR ev_bluetooth_kit_desactive()

#define evJumelage_demandee_SERIALIZE OM_NO_OP

#define evJumelage_demandee_UNSERIALIZE OM_NO_OP

#define evJumelage_demandee_CONSTRUCTOR evJumelage_demandee()

#define ev_jumelage_demande_SERIALIZE OMADD_SER(mot_de_passe, x2String(myEvent->mot_de_passe))

#define ev_jumelage_demande_UNSERIALIZE OMADD_UNSER(OMString, mot_de_passe, OMDestructiveString2X)

#define ev_jumelage_demande_CONSTRUCTOR ev_jumelage_demande(mot_de_passe)

#define ev_mdp_incorrect_SERIALIZE OM_NO_OP

#define ev_mdp_incorrect_UNSERIALIZE OM_NO_OP

#define ev_mdp_incorrect_CONSTRUCTOR ev_mdp_incorrect()

#define ev_mdp_correct_SERIALIZE OM_NO_OP

#define ev_mdp_correct_UNSERIALIZE OM_NO_OP

#define ev_mdp_correct_CONSTRUCTOR ev_mdp_correct()

#define ev_jumelage_demandee_SERIALIZE OM_NO_OP

#define ev_jumelage_demandee_UNSERIALIZE OM_NO_OP

#define ev_jumelage_demandee_CONSTRUCTOR ev_jumelage_demandee()

#define ev_jumelage_reussit_SERIALIZE OM_NO_OP

#define ev_jumelage_reussit_UNSERIALIZE OM_NO_OP

#define ev_jumelage_reussit_CONSTRUCTOR ev_jumelage_reussit()

#define ev_tentative_jumelage_SERIALIZE OM_NO_OP

#define ev_tentative_jumelage_UNSERIALIZE OM_NO_OP

#define ev_tentative_jumelage_CONSTRUCTOR ev_tentative_jumelage()

#define ev_demande_jumelage_SERIALIZE OM_NO_OP

#define ev_demande_jumelage_UNSERIALIZE OM_NO_OP

#define ev_demande_jumelage_CONSTRUCTOR ev_demande_jumelage()

#define ev_demande_mot_de_passe_SERIALIZE OM_NO_OP

#define ev_demande_mot_de_passe_UNSERIALIZE OM_NO_OP

#define ev_demande_mot_de_passe_CONSTRUCTOR ev_demande_mot_de_passe()

#define ev_tentative_password_SERIALIZE OM_NO_OP

#define ev_tentative_password_UNSERIALIZE OM_NO_OP

#define ev_tentative_password_CONSTRUCTOR ev_tentative_password()

#define ev_tentative_code_pin_SERIALIZE OMADD_SER(code_pin, x2String(myEvent->code_pin))

#define ev_tentative_code_pin_UNSERIALIZE OMADD_UNSER(OMString, code_pin, OMDestructiveString2X)

#define ev_tentative_code_pin_CONSTRUCTOR ev_tentative_code_pin(code_pin)

#define ev_demande_code_pin_SERIALIZE OM_NO_OP

#define ev_demande_code_pin_UNSERIALIZE OM_NO_OP

#define ev_demande_code_pin_CONSTRUCTOR ev_demande_code_pin()

#define ev_code_pin_incorrect_SERIALIZE OM_NO_OP

#define ev_code_pin_incorrect_UNSERIALIZE OM_NO_OP

#define ev_code_pin_incorrect_CONSTRUCTOR ev_code_pin_incorrect()

#define ev_demande_mdp_SERIALIZE OM_NO_OP

#define ev_demande_mdp_UNSERIALIZE OM_NO_OP

#define ev_demande_mdp_CONSTRUCTOR ev_demande_mdp()

#define ev_demande_connexion_SERIALIZE OM_NO_OP

#define ev_demande_connexion_UNSERIALIZE OM_NO_OP

#define ev_demande_connexion_CONSTRUCTOR ev_demande_connexion()

#define ev_tentative_mdp_SERIALIZE OMADD_SER(mdp, x2String(myEvent->mdp))

#define ev_tentative_mdp_UNSERIALIZE OMADD_UNSER(OMString, mdp, OMDestructiveString2X)

#define ev_tentative_mdp_CONSTRUCTOR ev_tentative_mdp(mdp)

#define ev_actualisation_telephone_SERIALIZE OM_NO_OP

#define ev_actualisation_telephone_UNSERIALIZE OM_NO_OP

#define ev_actualisation_telephone_CONSTRUCTOR ev_actualisation_telephone()

#define ev_actualisation_batterie_telephone_vehicule_SERIALIZE OMADD_SER(pourcentage, x2String(myEvent->pourcentage))

#define ev_actualisation_batterie_telephone_vehicule_UNSERIALIZE OMADD_UNSER(int, pourcentage, OMDestructiveString2X)

#define ev_actualisation_batterie_telephone_vehicule_CONSTRUCTOR ev_actualisation_batterie_telephone_vehicule(pourcentage)

#define ev_appel_SERIALIZE OM_NO_OP

#define ev_appel_UNSERIALIZE OM_NO_OP

#define ev_appel_CONSTRUCTOR ev_appel()

#define ev_sms_SERIALIZE OM_NO_OP

#define ev_sms_UNSERIALIZE OM_NO_OP

#define ev_sms_CONSTRUCTOR ev_sms()

#define ev_appel_recu_SERIALIZE OM_NO_OP

#define ev_appel_recu_UNSERIALIZE OM_NO_OP

#define ev_appel_recu_CONSTRUCTOR ev_appel_recu()

#define ev_appel_fin_SERIALIZE OM_NO_OP

#define ev_appel_fin_UNSERIALIZE OM_NO_OP

#define ev_appel_fin_CONSTRUCTOR ev_appel_fin()

#define ev_raccrocher_SERIALIZE OM_NO_OP

#define ev_raccrocher_UNSERIALIZE OM_NO_OP

#define ev_raccrocher_CONSTRUCTOR ev_raccrocher()

#define ev_connexion_acceptee_SERIALIZE OM_NO_OP

#define ev_connexion_acceptee_UNSERIALIZE OM_NO_OP

#define ev_connexion_acceptee_CONSTRUCTOR ev_connexion_acceptee()

#define ev_blue_telephone_desactive_SERIALIZE OM_NO_OP

#define ev_blue_telephone_desactive_UNSERIALIZE OM_NO_OP

#define ev_blue_telephone_desactive_CONSTRUCTOR ev_blue_telephone_desactive()

#define ev_appel_recu_kit_SERIALIZE OM_NO_OP

#define ev_appel_recu_kit_UNSERIALIZE OM_NO_OP

#define ev_appel_recu_kit_CONSTRUCTOR ev_appel_recu_kit()

#define ev_appel_demande_SERIALIZE OM_NO_OP

#define ev_appel_demande_UNSERIALIZE OM_NO_OP

#define ev_appel_demande_CONSTRUCTOR ev_appel_demande()

#define ev_bouton_appel_SERIALIZE OM_NO_OP

#define ev_bouton_appel_UNSERIALIZE OM_NO_OP

#define ev_bouton_appel_CONSTRUCTOR ev_bouton_appel()

#define ev_appel_exterieur_SERIALIZE OM_NO_OP

#define ev_appel_exterieur_UNSERIALIZE OM_NO_OP

#define ev_appel_exterieur_CONSTRUCTOR ev_appel_exterieur()

#define ev_refuser_appel_SERIALIZE OM_NO_OP

#define ev_refuser_appel_UNSERIALIZE OM_NO_OP

#define ev_refuser_appel_CONSTRUCTOR ev_refuser_appel()

#define ev_appel_externe_SERIALIZE OM_NO_OP

#define ev_appel_externe_UNSERIALIZE OM_NO_OP

#define ev_appel_externe_CONSTRUCTOR ev_appel_externe()

#define ev_decrocher_telephone_SERIALIZE OM_NO_OP

#define ev_decrocher_telephone_UNSERIALIZE OM_NO_OP

#define ev_decrocher_telephone_CONSTRUCTOR ev_decrocher_telephone()

#define ev_racrocher_telephone_SERIALIZE OM_NO_OP

#define ev_racrocher_telephone_UNSERIALIZE OM_NO_OP

#define ev_racrocher_telephone_CONSTRUCTOR ev_racrocher_telephone()

#define ev_raccrocher_telephone_SERIALIZE OM_NO_OP

#define ev_raccrocher_telephone_UNSERIALIZE OM_NO_OP

#define ev_raccrocher_telephone_CONSTRUCTOR ev_raccrocher_telephone()

#define ev_decrocher_kit__SERIALIZE OM_NO_OP

#define ev_decrocher_kit__UNSERIALIZE OM_NO_OP

#define ev_decrocher_kit__CONSTRUCTOR ev_decrocher_kit_()

#define ev_raccrocher_kit_SERIALIZE OM_NO_OP

#define ev_raccrocher_kit_UNSERIALIZE OM_NO_OP

#define ev_raccrocher_kit_CONSTRUCTOR ev_raccrocher_kit()

#define ev_decrocher_kit_SERIALIZE OM_NO_OP

#define ev_decrocher_kit_UNSERIALIZE OM_NO_OP

#define ev_decrocher_kit_CONSTRUCTOR ev_decrocher_kit()

#define ev_btn_decrocher_kit_SERIALIZE OM_NO_OP

#define ev_btn_decrocher_kit_UNSERIALIZE OM_NO_OP

#define ev_btn_decrocher_kit_CONSTRUCTOR ev_btn_decrocher_kit()

#define ev_btn_raccrocher_kit_SERIALIZE OM_NO_OP

#define ev_btn_raccrocher_kit_UNSERIALIZE OM_NO_OP

#define ev_btn_raccrocher_kit_CONSTRUCTOR ev_btn_raccrocher_kit()

#define ev_appel_entrant_kit_SERIALIZE OM_NO_OP

#define ev_appel_entrant_kit_UNSERIALIZE OM_NO_OP

#define ev_appel_entrant_kit_CONSTRUCTOR ev_appel_entrant_kit()

#define ev_appel_transfere_SERIALIZE OM_NO_OP

#define ev_appel_transfere_UNSERIALIZE OM_NO_OP

#define ev_appel_transfere_CONSTRUCTOR ev_appel_transfere()

#define ev_appel_transfere_kit_SERIALIZE OM_NO_OP

#define ev_appel_transfere_kit_UNSERIALIZE OM_NO_OP

#define ev_appel_transfere_kit_CONSTRUCTOR ev_appel_transfere_kit()

#define ev_eppel_termine_kit_SERIALIZE OM_NO_OP

#define ev_eppel_termine_kit_UNSERIALIZE OM_NO_OP

#define ev_eppel_termine_kit_CONSTRUCTOR ev_eppel_termine_kit()

#define ev_appel_termine_kit_SERIALIZE OM_NO_OP

#define ev_appel_termine_kit_UNSERIALIZE OM_NO_OP

#define ev_appel_termine_kit_CONSTRUCTOR ev_appel_termine_kit()

#define ev_appel_en_cours_SERIALIZE OM_NO_OP

#define ev_appel_en_cours_UNSERIALIZE OM_NO_OP

#define ev_appel_en_cours_CONSTRUCTOR ev_appel_en_cours()

#define ev_raccroher_telephone_SERIALIZE OM_NO_OP

#define ev_raccroher_telephone_UNSERIALIZE OM_NO_OP

#define ev_raccroher_telephone_CONSTRUCTOR ev_raccroher_telephone()

#define ev_rraccrocher_telephonel_SERIALIZE OM_NO_OP

#define ev_rraccrocher_telephonel_UNSERIALIZE OM_NO_OP

#define ev_rraccrocher_telephonel_CONSTRUCTOR ev_rraccrocher_telephonel()

#define ev_raccrocher_telephonel_SERIALIZE OM_NO_OP

#define ev_raccrocher_telephonel_UNSERIALIZE OM_NO_OP

#define ev_raccrocher_telephonel_CONSTRUCTOR ev_raccrocher_telephonel()

#define ev_envoi_sms_SERIALIZE OM_NO_OP

#define ev_envoi_sms_UNSERIALIZE OM_NO_OP

#define ev_envoi_sms_CONSTRUCTOR ev_envoi_sms()

#define ev_btn_telephone_sms_SERIALIZE OM_NO_OP

#define ev_btn_telephone_sms_UNSERIALIZE OM_NO_OP

#define ev_btn_telephone_sms_CONSTRUCTOR ev_btn_telephone_sms()

#define ev_lire_sms_kit_SERIALIZE OM_NO_OP

#define ev_lire_sms_kit_UNSERIALIZE OM_NO_OP

#define ev_lire_sms_kit_CONSTRUCTOR ev_lire_sms_kit()

#define ev_nv_message_kit_SERIALIZE OM_NO_OP

#define ev_nv_message_kit_UNSERIALIZE OM_NO_OP

#define ev_nv_message_kit_CONSTRUCTOR ev_nv_message_kit()

#define ev_messagerie_vide_kit_SERIALIZE OM_NO_OP

#define ev_messagerie_vide_kit_UNSERIALIZE OM_NO_OP

#define ev_messagerie_vide_kit_CONSTRUCTOR ev_messagerie_vide_kit()

#define ev_btn_lire_sms_kit_SERIALIZE OM_NO_OP

#define ev_btn_lire_sms_kit_UNSERIALIZE OM_NO_OP

#define ev_btn_lire_sms_kit_CONSTRUCTOR ev_btn_lire_sms_kit()

#define ev_transfert_sms_telephone_to_kit_SERIALIZE OM_NO_OP

#define ev_transfert_sms_telephone_to_kit_UNSERIALIZE OM_NO_OP

#define ev_transfert_sms_telephone_to_kit_CONSTRUCTOR ev_transfert_sms_telephone_to_kit()

#define ev_transfert_sms_to_kit_SERIALIZE OMADD_SER(historique, x2String(myEvent->historique))

#define ev_transfert_sms_to_kit_UNSERIALIZE OMADD_UNSER(int, historique, OMDestructiveString2X)

#define ev_transfert_sms_to_kit_CONSTRUCTOR ev_transfert_sms_to_kit(historique)

#define ev_transfert_sms_to_telephone_SERIALIZE OMADD_SER(historique, x2String(myEvent->historique))

#define ev_transfert_sms_to_telephone_UNSERIALIZE OMADD_UNSER(int, historique, OMDestructiveString2X)

#define ev_transfert_sms_to_telephone_CONSTRUCTOR ev_transfert_sms_to_telephone(historique)

#define ev_tentative_lire_sms_kit_SERIALIZE OM_NO_OP

#define ev_tentative_lire_sms_kit_UNSERIALIZE OM_NO_OP

#define ev_tentative_lire_sms_kit_CONSTRUCTOR ev_tentative_lire_sms_kit()

#define ev_nv_sms_kit_SERIALIZE OMADD_SER(sms_telephone, x2String(myEvent->sms_telephone))

#define ev_nv_sms_kit_UNSERIALIZE OMADD_UNSER(int, sms_telephone, OMDestructiveString2X)

#define ev_nv_sms_kit_CONSTRUCTOR ev_nv_sms_kit(sms_telephone)

#define ev_actualisation_sms_kit_SERIALIZE OMADD_SER(sms_tel, x2String(myEvent->sms_tel))

#define ev_actualisation_sms_kit_UNSERIALIZE OMADD_UNSER(int, sms_tel, OMDestructiveString2X)

#define ev_actualisation_sms_kit_CONSTRUCTOR ev_actualisation_sms_kit(sms_tel)

#define ev_btn_radio_on_SERIALIZE OM_NO_OP

#define ev_btn_radio_on_UNSERIALIZE OM_NO_OP

#define ev_btn_radio_on_CONSTRUCTOR ev_btn_radio_on()

#define ev_btn_radio_off_SERIALIZE OM_NO_OP

#define ev_btn_radio_off_UNSERIALIZE OM_NO_OP

#define ev_btn_radio_off_CONSTRUCTOR ev_btn_radio_off()

#define ev_transition_musique_1_SERIALIZE OM_NO_OP

#define ev_transition_musique_1_UNSERIALIZE OM_NO_OP

#define ev_transition_musique_1_CONSTRUCTOR ev_transition_musique_1()

#define ev_skip_musique_SERIALIZE OM_NO_OP

#define ev_skip_musique_UNSERIALIZE OM_NO_OP

#define ev_skip_musique_CONSTRUCTOR ev_skip_musique()

#define ev_btn_radio_skip_SERIALIZE OM_NO_OP

#define ev_btn_radio_skip_UNSERIALIZE OM_NO_OP

#define ev_btn_radio_skip_CONSTRUCTOR ev_btn_radio_skip()

#define ev_btn_start_radio_SERIALIZE OM_NO_OP

#define ev_btn_start_radio_UNSERIALIZE OM_NO_OP

#define ev_btn_start_radio_CONSTRUCTOR ev_btn_start_radio()

#define ev_sonnerie_kit_SERIALIZE OM_NO_OP

#define ev_sonnerie_kit_UNSERIALIZE OM_NO_OP

#define ev_sonnerie_kit_CONSTRUCTOR ev_sonnerie_kit()

#define eval_SERIALIZE OM_NO_OP

#define eval_UNSERIALIZE OM_NO_OP

#define eval_CONSTRUCTOR eval()

#define ev_fin_sonnerie_SERIALIZE OM_NO_OP

#define ev_fin_sonnerie_UNSERIALIZE OM_NO_OP

#define ev_fin_sonnerie_CONSTRUCTOR ev_fin_sonnerie()

#define ev_bnt_appel_externe_SERIALIZE OM_NO_OP

#define ev_bnt_appel_externe_UNSERIALIZE OM_NO_OP

#define ev_bnt_appel_externe_CONSTRUCTOR ev_bnt_appel_externe()

#define ev_btn_appel_externe_SERIALIZE OM_NO_OP

#define ev_btn_appel_externe_UNSERIALIZE OM_NO_OP

#define ev_btn_appel_externe_CONSTRUCTOR ev_btn_appel_externe()

#define ev_btn_appel_SIM_SERIALIZE OM_NO_OP

#define ev_btn_appel_SIM_UNSERIALIZE OM_NO_OP

#define ev_btn_appel_SIM_CONSTRUCTOR ev_btn_appel_SIM()

#define ev_btn_SIM_appel_SERIALIZE OM_NO_OP

#define ev_btn_SIM_appel_UNSERIALIZE OM_NO_OP

#define ev_btn_SIM_appel_CONSTRUCTOR ev_btn_SIM_appel()

#define ev_SIM_appel_SERIALIZE OM_NO_OP

#define ev_SIM_appel_UNSERIALIZE OM_NO_OP

#define ev_SIM_appel_CONSTRUCTOR ev_SIM_appel()

#define ev_SIM_raccrocher_SERIALIZE OM_NO_OP

#define ev_SIM_raccrocher_UNSERIALIZE OM_NO_OP

#define ev_SIM_raccrocher_CONSTRUCTOR ev_SIM_raccrocher()

#define ev_btn_raccrocher_telephone_SERIALIZE OM_NO_OP

#define ev_btn_raccrocher_telephone_UNSERIALIZE OM_NO_OP

#define ev_btn_raccrocher_telephone_CONSTRUCTOR ev_btn_raccrocher_telephone()

#define ev_SIM_refuser_appel_SERIALIZE OM_NO_OP

#define ev_SIM_refuser_appel_UNSERIALIZE OM_NO_OP

#define ev_SIM_refuser_appel_CONSTRUCTOR ev_SIM_refuser_appel()

#define ev_telephone_decrocher_SERIALIZE OM_NO_OP

#define ev_telephone_decrocher_UNSERIALIZE OM_NO_OP

#define ev_telephone_decrocher_CONSTRUCTOR ev_telephone_decrocher()

#define ev_telephone_raccrocher_SERIALIZE OM_NO_OP

#define ev_telephone_raccrocher_UNSERIALIZE OM_NO_OP

#define ev_telephone_raccrocher_CONSTRUCTOR ev_telephone_raccrocher()

#define ev_btn_telephone_raccrocher__SERIALIZE OM_NO_OP

#define ev_btn_telephone_raccrocher__UNSERIALIZE OM_NO_OP

#define ev_btn_telephone_raccrocher__CONSTRUCTOR ev_btn_telephone_raccrocher_()

#define ev_kit_decrocher_SERIALIZE OM_NO_OP

#define ev_kit_decrocher_UNSERIALIZE OM_NO_OP

#define ev_kit_decrocher_CONSTRUCTOR ev_kit_decrocher()

#define ev_kit_raccrocher_SERIALIZE OM_NO_OP

#define ev_kit_raccrocher_UNSERIALIZE OM_NO_OP

#define ev_kit_raccrocher_CONSTRUCTOR ev_kit_raccrocher()

#define ev_kit_appel_entrant_SERIALIZE OM_NO_OP

#define ev_kit_appel_entrant_UNSERIALIZE OM_NO_OP

#define ev_kit_appel_entrant_CONSTRUCTOR ev_kit_appel_entrant()

#define ev_kit_sonnerie_SERIALIZE OM_NO_OP

#define ev_kit_sonnerie_UNSERIALIZE OM_NO_OP

#define ev_kit_sonnerie_CONSTRUCTOR ev_kit_sonnerie()

#define ev_kit_appel_transfere_SERIALIZE OM_NO_OP

#define ev_kit_appel_transfere_UNSERIALIZE OM_NO_OP

#define ev_kit_appel_transfere_CONSTRUCTOR ev_kit_appel_transfere()

#define ev_kit_appel_termine_SERIALIZE OM_NO_OP

#define ev_kit_appel_termine_UNSERIALIZE OM_NO_OP

#define ev_kit_appel_termine_CONSTRUCTOR ev_kit_appel_termine()

#define ev_btn_kit_raccrocher_SERIALIZE OM_NO_OP

#define ev_btn_kit_raccrocher_UNSERIALIZE OM_NO_OP

#define ev_btn_kit_raccrocher_CONSTRUCTOR ev_btn_kit_raccrocher()

#define ev_btn_kit_decrocher_SERIALIZE OM_NO_OP

#define ev_btn_kit_decrocher_UNSERIALIZE OM_NO_OP

#define ev_btn_kit_decrocher_CONSTRUCTOR ev_btn_kit_decrocher()

#define ev_btn_SIM_sms_SERIALIZE OM_NO_OP

#define ev_btn_SIM_sms_UNSERIALIZE OM_NO_OP

#define ev_btn_SIM_sms_CONSTRUCTOR ev_btn_SIM_sms()

#define ev_SIM_envoi_sms_SERIALIZE OM_NO_OP

#define ev_SIM_envoi_sms_UNSERIALIZE OM_NO_OP

#define ev_SIM_envoi_sms_CONSTRUCTOR ev_SIM_envoi_sms()

#define ev_lire_sms_SERIALIZE OM_NO_OP

#define ev_lire_sms_UNSERIALIZE OM_NO_OP

#define ev_lire_sms_CONSTRUCTOR ev_lire_sms()

#define ev_kit_lire_sms_SERIALIZE OM_NO_OP

#define ev_kit_lire_sms_UNSERIALIZE OM_NO_OP

#define ev_kit_lire_sms_CONSTRUCTOR ev_kit_lire_sms()

#define ev_btn_telephone_lire_sms_SERIALIZE OM_NO_OP

#define ev_btn_telephone_lire_sms_UNSERIALIZE OM_NO_OP

#define ev_btn_telephone_lire_sms_CONSTRUCTOR ev_btn_telephone_lire_sms()

#define ev_btn_kit_lire_sms_SERIALIZE OM_NO_OP

#define ev_btn_kit_lire_sms_UNSERIALIZE OM_NO_OP

#define ev_btn_kit_lire_sms_CONSTRUCTOR ev_btn_kit_lire_sms()

#define ev_SIM_appel_en_cours_SERIALIZE OM_NO_OP

#define ev_SIM_appel_en_cours_UNSERIALIZE OM_NO_OP

#define ev_SIM_appel_en_cours_CONSTRUCTOR ev_SIM_appel_en_cours()

#define ev_btn_telephone_decrocher_SERIALIZE OM_NO_OP

#define ev_btn_telephone_decrocher_UNSERIALIZE OM_NO_OP

#define ev_btn_telephone_decrocher_CONSTRUCTOR ev_btn_telephone_decrocher()

#define ev_btn_telephone_raccrocher_SERIALIZE OM_NO_OP

#define ev_btn_telephone_raccrocher_UNSERIALIZE OM_NO_OP

#define ev_btn_telephone_raccrocher_CONSTRUCTOR ev_btn_telephone_raccrocher()

#define ev_bnt_telephone_decrocher_SERIALIZE OM_NO_OP

#define ev_bnt_telephone_decrocher_UNSERIALIZE OM_NO_OP

#define ev_bnt_telephone_decrocher_CONSTRUCTOR ev_bnt_telephone_decrocher()

#define ev_kit_fin_sonnerie_SERIALIZE OM_NO_OP

#define ev_kit_fin_sonnerie_UNSERIALIZE OM_NO_OP

#define ev_kit_fin_sonnerie_CONSTRUCTOR ev_kit_fin_sonnerie()

#define ev_btn_ok_SERIALIZE OM_NO_OP

#define ev_btn_ok_UNSERIALIZE OM_NO_OP

#define ev_btn_ok_CONSTRUCTOR ev_btn_ok()

#define ev_kit_bluetooth_desactive_SERIALIZE OM_NO_OP

#define ev_kit_bluetooth_desactive_UNSERIALIZE OM_NO_OP

#define ev_kit_bluetooth_desactive_CONSTRUCTOR ev_kit_bluetooth_desactive()

#define ev_SERIALIZE OM_NO_OP

#define ev_UNSERIALIZE OM_NO_OP

#define ev_CONSTRUCTOR ev()

#define ev_tel_demande_jumelage_SERIALIZE OM_NO_OP

#define ev_tel_demande_jumelage_UNSERIALIZE OM_NO_OP

#define ev_tel_demande_jumelage_CONSTRUCTOR ev_tel_demande_jumelage()

#define ev_telephone_demande_jumelage_SERIALIZE OMADD_SER(mot_de_passe, x2String(myEvent->mot_de_passe))

#define ev_telephone_demande_jumelage_UNSERIALIZE OMADD_UNSER(OMString, mot_de_passe, OMDestructiveString2X)

#define ev_telephone_demande_jumelage_CONSTRUCTOR ev_telephone_demande_jumelage(mot_de_passe)

#define ev_kit_demande_mdp_SERIALIZE OM_NO_OP

#define ev_kit_demande_mdp_UNSERIALIZE OM_NO_OP

#define ev_kit_demande_mdp_CONSTRUCTOR ev_kit_demande_mdp()

#define ev_telephone_tentative_mdp_SERIALIZE OMADD_SER(mdp, x2String(myEvent->mdp))

#define ev_telephone_tentative_mdp_UNSERIALIZE OMADD_UNSER(OMString, mdp, OMDestructiveString2X)

#define ev_telephone_tentative_mdp_CONSTRUCTOR ev_telephone_tentative_mdp(mdp)

#define ev_kit_mdp_correct_SERIALIZE OM_NO_OP

#define ev_kit_mdp_correct_UNSERIALIZE OM_NO_OP

#define ev_kit_mdp_correct_CONSTRUCTOR ev_kit_mdp_correct()

#define ev_kit_mdp_incorrect_SERIALIZE OM_NO_OP

#define ev_kit_mdp_incorrect_UNSERIALIZE OM_NO_OP

#define ev_kit_mdp_incorrect_CONSTRUCTOR ev_kit_mdp_incorrect()

#define ev_telephone_demande_connexion_SERIALIZE OM_NO_OP

#define ev_telephone_demande_connexion_UNSERIALIZE OM_NO_OP

#define ev_telephone_demande_connexion_CONSTRUCTOR ev_telephone_demande_connexion()

#define ev_kit_connexion_acceptee_SERIALIZE OM_NO_OP

#define ev_kit_connexion_acceptee_UNSERIALIZE OM_NO_OP

#define ev_kit_connexion_acceptee_CONSTRUCTOR ev_kit_connexion_acceptee()

#define ev_btn_appairage_SERIALIZE OM_NO_OP

#define ev_btn_appairage_UNSERIALIZE OM_NO_OP

#define ev_btn_appairage_CONSTRUCTOR ev_btn_appairage()

#define ev_btn_telephone_appairage_SERIALIZE OM_NO_OP

#define ev_btn_telephone_appairage_UNSERIALIZE OM_NO_OP

#define ev_btn_telephone_appairage_CONSTRUCTOR ev_btn_telephone_appairage()

#define ev_telephone_kit_appel_entrant_SERIALIZE OM_NO_OP

#define ev_telephone_kit_appel_entrant_UNSERIALIZE OM_NO_OP

#define ev_telephone_kit_appel_entrant_CONSTRUCTOR ev_telephone_kit_appel_entrant()

#define ev_telephone_kit_sonnerie_SERIALIZE OM_NO_OP

#define ev_telephone_kit_sonnerie_UNSERIALIZE OM_NO_OP

#define ev_telephone_kit_sonnerie_CONSTRUCTOR ev_telephone_kit_sonnerie()

#define ev_telephone_kit_fin_sonnerie_SERIALIZE OM_NO_OP

#define ev_telephone_kit_fin_sonnerie_UNSERIALIZE OM_NO_OP

#define ev_telephone_kit_fin_sonnerie_CONSTRUCTOR ev_telephone_kit_fin_sonnerie()

#define ev_telephone_kit_appel_transfere_SERIALIZE OM_NO_OP

#define ev_telephone_kit_appel_transfere_UNSERIALIZE OM_NO_OP

#define ev_telephone_kit_appel_transfere_CONSTRUCTOR ev_telephone_kit_appel_transfere()

#define ev_telephone_kit_appel_termine_SERIALIZE OM_NO_OP

#define ev_telephone_kit_appel_termine_UNSERIALIZE OM_NO_OP

#define ev_telephone_kit_appel_termine_CONSTRUCTOR ev_telephone_kit_appel_termine()

#define ev_telephone_appel_entrant_kit_SERIALIZE OM_NO_OP

#define ev_telephone_appel_entrant_kit_UNSERIALIZE OM_NO_OP

#define ev_telephone_appel_entrant_kit_CONSTRUCTOR ev_telephone_appel_entrant_kit()

#define ev_telephone_sonnerie_kit_SERIALIZE OM_NO_OP

#define ev_telephone_sonnerie_kit_UNSERIALIZE OM_NO_OP

#define ev_telephone_sonnerie_kit_CONSTRUCTOR ev_telephone_sonnerie_kit()

#define ev_telephone_appel_transfere_kit_SERIALIZE OM_NO_OP

#define ev_telephone_appel_transfere_kit_UNSERIALIZE OM_NO_OP

#define ev_telephone_appel_transfere_kit_CONSTRUCTOR ev_telephone_appel_transfere_kit()

#define ev_telephone_appel_kit_termine_SERIALIZE OM_NO_OP

#define ev_telephone_appel_kit_termine_UNSERIALIZE OM_NO_OP

#define ev_telephone_appel_kit_termine_CONSTRUCTOR ev_telephone_appel_kit_termine()

#define ev_telephone_appel_termine_kit_SERIALIZE OM_NO_OP

#define ev_telephone_appel_termine_kit_UNSERIALIZE OM_NO_OP

#define ev_telephone_appel_termine_kit_CONSTRUCTOR ev_telephone_appel_termine_kit()

#define ev_telephone_fin_sonnerie_kit_SERIALIZE OM_NO_OP

#define ev_telephone_fin_sonnerie_kit_UNSERIALIZE OM_NO_OP

#define ev_telephone_fin_sonnerie_kit_CONSTRUCTOR ev_telephone_fin_sonnerie_kit()

#define ev_kit_tentative_lire_sms_SERIALIZE OM_NO_OP

#define ev_kit_tentative_lire_sms_UNSERIALIZE OM_NO_OP

#define ev_kit_tentative_lire_sms_CONSTRUCTOR ev_kit_tentative_lire_sms()

#define ev_telephone_sms_historique_kit_SERIALIZE OMADD_SER(historique, x2String(myEvent->historique))

#define ev_telephone_sms_historique_kit_UNSERIALIZE OMADD_UNSER(int, historique, OMDestructiveString2X)

#define ev_telephone_sms_historique_kit_CONSTRUCTOR ev_telephone_sms_historique_kit(historique)

#define ev_telephone_sms_nouveau_kit_SERIALIZE OMADD_SER(sms_telephone, x2String(myEvent->sms_telephone))

#define ev_telephone_sms_nouveau_kit_UNSERIALIZE OMADD_UNSER(int, sms_telephone, OMDestructiveString2X)

#define ev_telephone_sms_nouveau_kit_CONSTRUCTOR ev_telephone_sms_nouveau_kit(sms_telephone)

#define ev_telephone_appel_en_cours_SERIALIZE OM_NO_OP

#define ev_telephone_appel_en_cours_UNSERIALIZE OM_NO_OP

#define ev_telephone_appel_en_cours_CONSTRUCTOR ev_telephone_appel_en_cours()

#define ev_telephone_appel_en_cours_SIM_SERIALIZE OM_NO_OP

#define ev_telephone_appel_en_cours_SIM_UNSERIALIZE OM_NO_OP

#define ev_telephone_appel_en_cours_SIM_CONSTRUCTOR ev_telephone_appel_en_cours_SIM()

#define ev_telephone_raccrocher_SIM_SERIALIZE OM_NO_OP

#define ev_telephone_raccrocher_SIM_UNSERIALIZE OM_NO_OP

#define ev_telephone_raccrocher_SIM_CONSTRUCTOR ev_telephone_raccrocher_SIM()

#define ev_kit_actualisation_sms_SERIALIZE OMADD_SER(sms_tel, x2String(myEvent->sms_tel))

#define ev_kit_actualisation_sms_UNSERIALIZE OMADD_UNSER(int, sms_tel, OMDestructiveString2X)

#define ev_kit_actualisation_sms_CONSTRUCTOR ev_kit_actualisation_sms(sms_tel)

#define ev_telephone_actualisation_batterie_kit_SERIALIZE OMADD_SER(pourcentage, x2String(myEvent->pourcentage))

#define ev_telephone_actualisation_batterie_kit_UNSERIALIZE OMADD_UNSER(int, pourcentage, OMDestructiveString2X)

#define ev_telephone_actualisation_batterie_kit_CONSTRUCTOR ev_telephone_actualisation_batterie_kit(pourcentage)

#define ev_telephone_actualisation_sms_kit_SERIALIZE OMADD_SER(sms_tel, x2String(myEvent->sms_tel))

#define ev_telephone_actualisation_sms_kit_UNSERIALIZE OMADD_UNSER(int, sms_tel, OMDestructiveString2X)

#define ev_telephone_actualisation_sms_kit_CONSTRUCTOR ev_telephone_actualisation_sms_kit(sms_tel)

#define ev_telephone_bluetooth_desactive_SERIALIZE OM_NO_OP

#define ev_telephone_bluetooth_desactive_UNSERIALIZE OM_NO_OP

#define ev_telephone_bluetooth_desactive_CONSTRUCTOR ev_telephone_bluetooth_desactive()
//#]

//## package _MonPkg


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(_MonPkg, _MonPkg)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

//## event Push_Carburant()
Push_Carburant::Push_Carburant() {
    NOTIFY_EVENT_CONSTRUCTOR(Push_Carburant)
    setId(Push_Carburant__MonPkg_id);
}

bool Push_Carburant::isTypeOf(const short id) const {
    return (Push_Carburant__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(Push_Carburant, _MonPkg, _MonPkg, Push_Carburant())

//## event cablage()
cablage::cablage() {
    NOTIFY_EVENT_CONSTRUCTOR(cablage)
    setId(cablage__MonPkg_id);
}

bool cablage::isTypeOf(const short id) const {
    return (cablage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(cablage, _MonPkg, _MonPkg, cablage())

//## event f()
f::f() {
    NOTIFY_EVENT_CONSTRUCTOR(f)
    setId(f__MonPkg_id);
}

bool f::isTypeOf(const short id) const {
    return (f__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(f, _MonPkg, _MonPkg, f())

//## event Operation_108()
Operation_108::Operation_108() {
    NOTIFY_EVENT_CONSTRUCTOR(Operation_108)
    setId(Operation_108__MonPkg_id);
}

bool Operation_108::isTypeOf(const short id) const {
    return (Operation_108__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(Operation_108, _MonPkg, _MonPkg, Operation_108())

//## event decr_vitesseConsigne()
decr_vitesseConsigne::decr_vitesseConsigne() {
    NOTIFY_EVENT_CONSTRUCTOR(decr_vitesseConsigne)
    setId(decr_vitesseConsigne__MonPkg_id);
}

bool decr_vitesseConsigne::isTypeOf(const short id) const {
    return (decr_vitesseConsigne__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(decr_vitesseConsigne, _MonPkg, _MonPkg, decr_vitesseConsigne())

//## event incr_vitesseConsigne()
incr_vitesseConsigne::incr_vitesseConsigne() {
    NOTIFY_EVENT_CONSTRUCTOR(incr_vitesseConsigne)
    setId(incr_vitesseConsigne__MonPkg_id);
}

bool incr_vitesseConsigne::isTypeOf(const short id) const {
    return (incr_vitesseConsigne__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(incr_vitesseConsigne, _MonPkg, _MonPkg, incr_vitesseConsigne())

//## event ev_Demarrer()
ev_Demarrer::ev_Demarrer() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_Demarrer)
    setId(ev_Demarrer__MonPkg_id);
}

bool ev_Demarrer::isTypeOf(const short id) const {
    return (ev_Demarrer__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_Demarrer, _MonPkg, _MonPkg, ev_Demarrer())

//## event evDemarrer()
evDemarrer::evDemarrer() {
    NOTIFY_EVENT_CONSTRUCTOR(evDemarrer)
    setId(evDemarrer__MonPkg_id);
}

bool evDemarrer::isTypeOf(const short id) const {
    return (evDemarrer__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(evDemarrer, _MonPkg, _MonPkg, evDemarrer())

//## event ev_demarrer()
ev_demarrer::ev_demarrer() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demarrer)
    setId(ev_demarrer__MonPkg_id);
}

bool ev_demarrer::isTypeOf(const short id) const {
    return (ev_demarrer__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demarrer, _MonPkg, _MonPkg, ev_demarrer())

//## event ev_depanner_batterie()
ev_depanner_batterie::ev_depanner_batterie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_depanner_batterie)
    setId(ev_depanner_batterie__MonPkg_id);
}

bool ev_depanner_batterie::isTypeOf(const short id) const {
    return (ev_depanner_batterie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_depanner_batterie, _MonPkg, _MonPkg, ev_depanner_batterie())

//## event ev_remplir_carburant()
ev_remplir_carburant::ev_remplir_carburant() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_remplir_carburant)
    setId(ev_remplir_carburant__MonPkg_id);
}

bool ev_remplir_carburant::isTypeOf(const short id) const {
    return (ev_remplir_carburant__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_remplir_carburant, _MonPkg, _MonPkg, ev_remplir_carburant())

//## event ev_vitesseConsigne_moins()
ev_vitesseConsigne_moins::ev_vitesseConsigne_moins() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_vitesseConsigne_moins)
    setId(ev_vitesseConsigne_moins__MonPkg_id);
}

bool ev_vitesseConsigne_moins::isTypeOf(const short id) const {
    return (ev_vitesseConsigne_moins__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_vitesseConsigne_moins, _MonPkg, _MonPkg, ev_vitesseConsigne_moins())

//## event ev_vitesseConsigne_plus()
ev_vitesseConsigne_plus::ev_vitesseConsigne_plus() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_vitesseConsigne_plus)
    setId(ev_vitesseConsigne_plus__MonPkg_id);
}

bool ev_vitesseConsigne_plus::isTypeOf(const short id) const {
    return (ev_vitesseConsigne_plus__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_vitesseConsigne_plus, _MonPkg, _MonPkg, ev_vitesseConsigne_plus())

//## event moteur()
moteur::moteur() {
    NOTIFY_EVENT_CONSTRUCTOR(moteur)
    setId(moteur__MonPkg_id);
}

bool moteur::isTypeOf(const short id) const {
    return (moteur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(moteur, _MonPkg, _MonPkg, moteur())

//## event t()
t::t() {
    NOTIFY_EVENT_CONSTRUCTOR(t)
    setId(t__MonPkg_id);
}

bool t::isTypeOf(const short id) const {
    return (t__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(t, _MonPkg, _MonPkg, t())

//## event EVAL()
EVAL::EVAL() {
    NOTIFY_EVENT_CONSTRUCTOR(EVAL)
    setId(EVAL__MonPkg_id);
}

bool EVAL::isTypeOf(const short id) const {
    return (EVAL__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(EVAL, _MonPkg, _MonPkg, EVAL())

//## event ev_limiteur()
ev_limiteur::ev_limiteur() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_limiteur)
    setId(ev_limiteur__MonPkg_id);
}

bool ev_limiteur::isTypeOf(const short id) const {
    return (ev_limiteur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_limiteur, _MonPkg, _MonPkg, ev_limiteur())

//## event ev_regulateur()
ev_regulateur::ev_regulateur() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_regulateur)
    setId(ev_regulateur__MonPkg_id);
}

bool ev_regulateur::isTypeOf(const short id) const {
    return (ev_regulateur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_regulateur, _MonPkg, _MonPkg, ev_regulateur())

//## event ev_ok()
ev_ok::ev_ok() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_ok)
    setId(ev_ok__MonPkg_id);
}

bool ev_ok::isTypeOf(const short id) const {
    return (ev_ok__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_ok, _MonPkg, _MonPkg, ev_ok())

//## event ev_jumeler()
ev_jumeler::ev_jumeler() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_jumeler)
    setId(ev_jumeler__MonPkg_id);
}

bool ev_jumeler::isTypeOf(const short id) const {
    return (ev_jumeler__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_jumeler, _MonPkg, _MonPkg, ev_jumeler())

//## event ev_kit_vehicule_pret()
ev_kit_vehicule_pret::ev_kit_vehicule_pret() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_vehicule_pret)
    setId(ev_kit_vehicule_pret__MonPkg_id);
}

bool ev_kit_vehicule_pret::isTypeOf(const short id) const {
    return (ev_kit_vehicule_pret__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_vehicule_pret, _MonPkg, _MonPkg, ev_kit_vehicule_pret())

//## event ev_OK()
ev_OK::ev_OK() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_OK)
    setId(ev_OK__MonPkg_id);
}

bool ev_OK::isTypeOf(const short id) const {
    return (ev_OK__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_OK, _MonPkg, _MonPkg, ev_OK())

//## event kit_connecte()
kit_connecte::kit_connecte() {
    NOTIFY_EVENT_CONSTRUCTOR(kit_connecte)
    setId(kit_connecte__MonPkg_id);
}

bool kit_connecte::isTypeOf(const short id) const {
    return (kit_connecte__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(kit_connecte, _MonPkg, _MonPkg, kit_connecte())

//## event connexion_demandee()
connexion_demandee::connexion_demandee() {
    NOTIFY_EVENT_CONSTRUCTOR(connexion_demandee)
    setId(connexion_demandee__MonPkg_id);
}

bool connexion_demandee::isTypeOf(const short id) const {
    return (connexion_demandee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(connexion_demandee, _MonPkg, _MonPkg, connexion_demandee())

//## event ev_connexion_demandee()
ev_connexion_demandee::ev_connexion_demandee() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_connexion_demandee)
    setId(ev_connexion_demandee__MonPkg_id);
}

bool ev_connexion_demandee::isTypeOf(const short id) const {
    return (ev_connexion_demandee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_connexion_demandee, _MonPkg, _MonPkg, ev_connexion_demandee())

//## event connexion_acceptee()
connexion_acceptee::connexion_acceptee() {
    NOTIFY_EVENT_CONSTRUCTOR(connexion_acceptee)
    setId(connexion_acceptee__MonPkg_id);
}

bool connexion_acceptee::isTypeOf(const short id) const {
    return (connexion_acceptee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(connexion_acceptee, _MonPkg, _MonPkg, connexion_acceptee())

//## event bluetooth_vehicule_desactive()
bluetooth_vehicule_desactive::bluetooth_vehicule_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(bluetooth_vehicule_desactive)
    setId(bluetooth_vehicule_desactive__MonPkg_id);
}

bool bluetooth_vehicule_desactive::isTypeOf(const short id) const {
    return (bluetooth_vehicule_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(bluetooth_vehicule_desactive, _MonPkg, _MonPkg, bluetooth_vehicule_desactive())

//## event bluetooth_kit_desactive()
bluetooth_kit_desactive::bluetooth_kit_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(bluetooth_kit_desactive)
    setId(bluetooth_kit_desactive__MonPkg_id);
}

bool bluetooth_kit_desactive::isTypeOf(const short id) const {
    return (bluetooth_kit_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(bluetooth_kit_desactive, _MonPkg, _MonPkg, bluetooth_kit_desactive())

//## event ev_bluetooth_telephone_desactive()
ev_bluetooth_telephone_desactive::ev_bluetooth_telephone_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_bluetooth_telephone_desactive)
    setId(ev_bluetooth_telephone_desactive__MonPkg_id);
}

bool ev_bluetooth_telephone_desactive::isTypeOf(const short id) const {
    return (ev_bluetooth_telephone_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_bluetooth_telephone_desactive, _MonPkg, _MonPkg, ev_bluetooth_telephone_desactive())

//## event ev_bluetooth_kit_desactive()
ev_bluetooth_kit_desactive::ev_bluetooth_kit_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_bluetooth_kit_desactive)
    setId(ev_bluetooth_kit_desactive__MonPkg_id);
}

bool ev_bluetooth_kit_desactive::isTypeOf(const short id) const {
    return (ev_bluetooth_kit_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_bluetooth_kit_desactive, _MonPkg, _MonPkg, ev_bluetooth_kit_desactive())

//## event evJumelage_demandee()
evJumelage_demandee::evJumelage_demandee() {
    NOTIFY_EVENT_CONSTRUCTOR(evJumelage_demandee)
    setId(evJumelage_demandee__MonPkg_id);
}

bool evJumelage_demandee::isTypeOf(const short id) const {
    return (evJumelage_demandee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(evJumelage_demandee, _MonPkg, _MonPkg, evJumelage_demandee())

//## event ev_jumelage_demande(OMString)
ev_jumelage_demande::ev_jumelage_demande() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_jumelage_demande)
    setId(ev_jumelage_demande__MonPkg_id);
}

ev_jumelage_demande::ev_jumelage_demande(OMString p_mot_de_passe) : mot_de_passe(p_mot_de_passe) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_jumelage_demande)
    setId(ev_jumelage_demande__MonPkg_id);
}

bool ev_jumelage_demande::isTypeOf(const short id) const {
    return (ev_jumelage_demande__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_jumelage_demande, _MonPkg, _MonPkg, ev_jumelage_demande(OMString))

//## event ev_mdp_incorrect()
ev_mdp_incorrect::ev_mdp_incorrect() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_mdp_incorrect)
    setId(ev_mdp_incorrect__MonPkg_id);
}

bool ev_mdp_incorrect::isTypeOf(const short id) const {
    return (ev_mdp_incorrect__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_mdp_incorrect, _MonPkg, _MonPkg, ev_mdp_incorrect())

//## event ev_mdp_correct()
ev_mdp_correct::ev_mdp_correct() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_mdp_correct)
    setId(ev_mdp_correct__MonPkg_id);
}

bool ev_mdp_correct::isTypeOf(const short id) const {
    return (ev_mdp_correct__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_mdp_correct, _MonPkg, _MonPkg, ev_mdp_correct())

//## event ev_jumelage_demandee()
ev_jumelage_demandee::ev_jumelage_demandee() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_jumelage_demandee)
    setId(ev_jumelage_demandee__MonPkg_id);
}

bool ev_jumelage_demandee::isTypeOf(const short id) const {
    return (ev_jumelage_demandee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_jumelage_demandee, _MonPkg, _MonPkg, ev_jumelage_demandee())

//## event ev_jumelage_reussit()
ev_jumelage_reussit::ev_jumelage_reussit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_jumelage_reussit)
    setId(ev_jumelage_reussit__MonPkg_id);
}

bool ev_jumelage_reussit::isTypeOf(const short id) const {
    return (ev_jumelage_reussit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_jumelage_reussit, _MonPkg, _MonPkg, ev_jumelage_reussit())

//## event ev_tentative_jumelage()
ev_tentative_jumelage::ev_tentative_jumelage() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_jumelage)
    setId(ev_tentative_jumelage__MonPkg_id);
}

bool ev_tentative_jumelage::isTypeOf(const short id) const {
    return (ev_tentative_jumelage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_tentative_jumelage, _MonPkg, _MonPkg, ev_tentative_jumelage())

//## event ev_demande_jumelage()
ev_demande_jumelage::ev_demande_jumelage() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demande_jumelage)
    setId(ev_demande_jumelage__MonPkg_id);
}

bool ev_demande_jumelage::isTypeOf(const short id) const {
    return (ev_demande_jumelage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demande_jumelage, _MonPkg, _MonPkg, ev_demande_jumelage())

//## event ev_demande_mot_de_passe()
ev_demande_mot_de_passe::ev_demande_mot_de_passe() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demande_mot_de_passe)
    setId(ev_demande_mot_de_passe__MonPkg_id);
}

bool ev_demande_mot_de_passe::isTypeOf(const short id) const {
    return (ev_demande_mot_de_passe__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demande_mot_de_passe, _MonPkg, _MonPkg, ev_demande_mot_de_passe())

//## event ev_tentative_password()
ev_tentative_password::ev_tentative_password() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_password)
    setId(ev_tentative_password__MonPkg_id);
}

bool ev_tentative_password::isTypeOf(const short id) const {
    return (ev_tentative_password__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_tentative_password, _MonPkg, _MonPkg, ev_tentative_password())

//## event ev_tentative_code_pin(OMString)
ev_tentative_code_pin::ev_tentative_code_pin() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_code_pin)
    setId(ev_tentative_code_pin__MonPkg_id);
}

ev_tentative_code_pin::ev_tentative_code_pin(OMString p_code_pin) : code_pin(p_code_pin) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_code_pin)
    setId(ev_tentative_code_pin__MonPkg_id);
}

bool ev_tentative_code_pin::isTypeOf(const short id) const {
    return (ev_tentative_code_pin__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_tentative_code_pin, _MonPkg, _MonPkg, ev_tentative_code_pin(OMString))

//## event ev_demande_code_pin()
ev_demande_code_pin::ev_demande_code_pin() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demande_code_pin)
    setId(ev_demande_code_pin__MonPkg_id);
}

bool ev_demande_code_pin::isTypeOf(const short id) const {
    return (ev_demande_code_pin__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demande_code_pin, _MonPkg, _MonPkg, ev_demande_code_pin())

//## event ev_code_pin_incorrect()
ev_code_pin_incorrect::ev_code_pin_incorrect() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_code_pin_incorrect)
    setId(ev_code_pin_incorrect__MonPkg_id);
}

bool ev_code_pin_incorrect::isTypeOf(const short id) const {
    return (ev_code_pin_incorrect__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_code_pin_incorrect, _MonPkg, _MonPkg, ev_code_pin_incorrect())

//## event ev_demande_mdp()
ev_demande_mdp::ev_demande_mdp() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demande_mdp)
    setId(ev_demande_mdp__MonPkg_id);
}

bool ev_demande_mdp::isTypeOf(const short id) const {
    return (ev_demande_mdp__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demande_mdp, _MonPkg, _MonPkg, ev_demande_mdp())

//## event ev_demande_connexion()
ev_demande_connexion::ev_demande_connexion() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_demande_connexion)
    setId(ev_demande_connexion__MonPkg_id);
}

bool ev_demande_connexion::isTypeOf(const short id) const {
    return (ev_demande_connexion__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_demande_connexion, _MonPkg, _MonPkg, ev_demande_connexion())

//## event ev_tentative_mdp(OMString)
ev_tentative_mdp::ev_tentative_mdp() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_mdp)
    setId(ev_tentative_mdp__MonPkg_id);
}

ev_tentative_mdp::ev_tentative_mdp(OMString p_mdp) : mdp(p_mdp) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_mdp)
    setId(ev_tentative_mdp__MonPkg_id);
}

bool ev_tentative_mdp::isTypeOf(const short id) const {
    return (ev_tentative_mdp__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_tentative_mdp, _MonPkg, _MonPkg, ev_tentative_mdp(OMString))

//## event ev_actualisation_telephone()
ev_actualisation_telephone::ev_actualisation_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_actualisation_telephone)
    setId(ev_actualisation_telephone__MonPkg_id);
}

bool ev_actualisation_telephone::isTypeOf(const short id) const {
    return (ev_actualisation_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_actualisation_telephone, _MonPkg, _MonPkg, ev_actualisation_telephone())

//## event ev_actualisation_batterie_telephone_vehicule(int)
ev_actualisation_batterie_telephone_vehicule::ev_actualisation_batterie_telephone_vehicule() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_actualisation_batterie_telephone_vehicule)
    setId(ev_actualisation_batterie_telephone_vehicule__MonPkg_id);
}

ev_actualisation_batterie_telephone_vehicule::ev_actualisation_batterie_telephone_vehicule(int p_pourcentage) : pourcentage(p_pourcentage) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_actualisation_batterie_telephone_vehicule)
    setId(ev_actualisation_batterie_telephone_vehicule__MonPkg_id);
}

bool ev_actualisation_batterie_telephone_vehicule::isTypeOf(const short id) const {
    return (ev_actualisation_batterie_telephone_vehicule__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_actualisation_batterie_telephone_vehicule, _MonPkg, _MonPkg, ev_actualisation_batterie_telephone_vehicule(int))

//## event ev_appel()
ev_appel::ev_appel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel)
    setId(ev_appel__MonPkg_id);
}

bool ev_appel::isTypeOf(const short id) const {
    return (ev_appel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel, _MonPkg, _MonPkg, ev_appel())

//## event ev_sms()
ev_sms::ev_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_sms)
    setId(ev_sms__MonPkg_id);
}

bool ev_sms::isTypeOf(const short id) const {
    return (ev_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_sms, _MonPkg, _MonPkg, ev_sms())

//## event ev_appel_recu()
ev_appel_recu::ev_appel_recu() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_recu)
    setId(ev_appel_recu__MonPkg_id);
}

bool ev_appel_recu::isTypeOf(const short id) const {
    return (ev_appel_recu__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_recu, _MonPkg, _MonPkg, ev_appel_recu())

//## event ev_appel_fin()
ev_appel_fin::ev_appel_fin() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_fin)
    setId(ev_appel_fin__MonPkg_id);
}

bool ev_appel_fin::isTypeOf(const short id) const {
    return (ev_appel_fin__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_fin, _MonPkg, _MonPkg, ev_appel_fin())

//## event ev_raccrocher()
ev_raccrocher::ev_raccrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_raccrocher)
    setId(ev_raccrocher__MonPkg_id);
}

bool ev_raccrocher::isTypeOf(const short id) const {
    return (ev_raccrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_raccrocher, _MonPkg, _MonPkg, ev_raccrocher())

//## event ev_connexion_acceptee()
ev_connexion_acceptee::ev_connexion_acceptee() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_connexion_acceptee)
    setId(ev_connexion_acceptee__MonPkg_id);
}

bool ev_connexion_acceptee::isTypeOf(const short id) const {
    return (ev_connexion_acceptee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_connexion_acceptee, _MonPkg, _MonPkg, ev_connexion_acceptee())

//## event ev_blue_telephone_desactive()
ev_blue_telephone_desactive::ev_blue_telephone_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_blue_telephone_desactive)
    setId(ev_blue_telephone_desactive__MonPkg_id);
}

bool ev_blue_telephone_desactive::isTypeOf(const short id) const {
    return (ev_blue_telephone_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_blue_telephone_desactive, _MonPkg, _MonPkg, ev_blue_telephone_desactive())

//## event ev_appel_recu_kit()
ev_appel_recu_kit::ev_appel_recu_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_recu_kit)
    setId(ev_appel_recu_kit__MonPkg_id);
}

bool ev_appel_recu_kit::isTypeOf(const short id) const {
    return (ev_appel_recu_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_recu_kit, _MonPkg, _MonPkg, ev_appel_recu_kit())

//## event ev_appel_demande()
ev_appel_demande::ev_appel_demande() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_demande)
    setId(ev_appel_demande__MonPkg_id);
}

bool ev_appel_demande::isTypeOf(const short id) const {
    return (ev_appel_demande__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_demande, _MonPkg, _MonPkg, ev_appel_demande())

//## event ev_bouton_appel()
ev_bouton_appel::ev_bouton_appel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_bouton_appel)
    setId(ev_bouton_appel__MonPkg_id);
}

bool ev_bouton_appel::isTypeOf(const short id) const {
    return (ev_bouton_appel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_bouton_appel, _MonPkg, _MonPkg, ev_bouton_appel())

//## event ev_appel_exterieur()
ev_appel_exterieur::ev_appel_exterieur() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_exterieur)
    setId(ev_appel_exterieur__MonPkg_id);
}

bool ev_appel_exterieur::isTypeOf(const short id) const {
    return (ev_appel_exterieur__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_exterieur, _MonPkg, _MonPkg, ev_appel_exterieur())

//## event ev_refuser_appel()
ev_refuser_appel::ev_refuser_appel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_refuser_appel)
    setId(ev_refuser_appel__MonPkg_id);
}

bool ev_refuser_appel::isTypeOf(const short id) const {
    return (ev_refuser_appel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_refuser_appel, _MonPkg, _MonPkg, ev_refuser_appel())

//## event ev_appel_externe()
ev_appel_externe::ev_appel_externe() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_externe)
    setId(ev_appel_externe__MonPkg_id);
}

bool ev_appel_externe::isTypeOf(const short id) const {
    return (ev_appel_externe__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_externe, _MonPkg, _MonPkg, ev_appel_externe())

//## event ev_decrocher_telephone()
ev_decrocher_telephone::ev_decrocher_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_decrocher_telephone)
    setId(ev_decrocher_telephone__MonPkg_id);
}

bool ev_decrocher_telephone::isTypeOf(const short id) const {
    return (ev_decrocher_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_decrocher_telephone, _MonPkg, _MonPkg, ev_decrocher_telephone())

//## event ev_racrocher_telephone()
ev_racrocher_telephone::ev_racrocher_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_racrocher_telephone)
    setId(ev_racrocher_telephone__MonPkg_id);
}

bool ev_racrocher_telephone::isTypeOf(const short id) const {
    return (ev_racrocher_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_racrocher_telephone, _MonPkg, _MonPkg, ev_racrocher_telephone())

//## event ev_raccrocher_telephone()
ev_raccrocher_telephone::ev_raccrocher_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_raccrocher_telephone)
    setId(ev_raccrocher_telephone__MonPkg_id);
}

bool ev_raccrocher_telephone::isTypeOf(const short id) const {
    return (ev_raccrocher_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_raccrocher_telephone, _MonPkg, _MonPkg, ev_raccrocher_telephone())

//## event ev_decrocher_kit_()
ev_decrocher_kit_::ev_decrocher_kit_() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_decrocher_kit_)
    setId(ev_decrocher_kit___MonPkg_id);
}

bool ev_decrocher_kit_::isTypeOf(const short id) const {
    return (ev_decrocher_kit___MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_decrocher_kit_, _MonPkg, _MonPkg, ev_decrocher_kit_())

//## event ev_raccrocher_kit()
ev_raccrocher_kit::ev_raccrocher_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_raccrocher_kit)
    setId(ev_raccrocher_kit__MonPkg_id);
}

bool ev_raccrocher_kit::isTypeOf(const short id) const {
    return (ev_raccrocher_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_raccrocher_kit, _MonPkg, _MonPkg, ev_raccrocher_kit())

//## event ev_decrocher_kit()
ev_decrocher_kit::ev_decrocher_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_decrocher_kit)
    setId(ev_decrocher_kit__MonPkg_id);
}

bool ev_decrocher_kit::isTypeOf(const short id) const {
    return (ev_decrocher_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_decrocher_kit, _MonPkg, _MonPkg, ev_decrocher_kit())

//## event ev_btn_decrocher_kit()
ev_btn_decrocher_kit::ev_btn_decrocher_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_decrocher_kit)
    setId(ev_btn_decrocher_kit__MonPkg_id);
}

bool ev_btn_decrocher_kit::isTypeOf(const short id) const {
    return (ev_btn_decrocher_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_decrocher_kit, _MonPkg, _MonPkg, ev_btn_decrocher_kit())

//## event ev_btn_raccrocher_kit()
ev_btn_raccrocher_kit::ev_btn_raccrocher_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_raccrocher_kit)
    setId(ev_btn_raccrocher_kit__MonPkg_id);
}

bool ev_btn_raccrocher_kit::isTypeOf(const short id) const {
    return (ev_btn_raccrocher_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_raccrocher_kit, _MonPkg, _MonPkg, ev_btn_raccrocher_kit())

//## event ev_appel_entrant_kit()
ev_appel_entrant_kit::ev_appel_entrant_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_entrant_kit)
    setId(ev_appel_entrant_kit__MonPkg_id);
}

bool ev_appel_entrant_kit::isTypeOf(const short id) const {
    return (ev_appel_entrant_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_entrant_kit, _MonPkg, _MonPkg, ev_appel_entrant_kit())

//## event ev_appel_transfere()
ev_appel_transfere::ev_appel_transfere() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_transfere)
    setId(ev_appel_transfere__MonPkg_id);
}

bool ev_appel_transfere::isTypeOf(const short id) const {
    return (ev_appel_transfere__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_transfere, _MonPkg, _MonPkg, ev_appel_transfere())

//## event ev_appel_transfere_kit()
ev_appel_transfere_kit::ev_appel_transfere_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_transfere_kit)
    setId(ev_appel_transfere_kit__MonPkg_id);
}

bool ev_appel_transfere_kit::isTypeOf(const short id) const {
    return (ev_appel_transfere_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_transfere_kit, _MonPkg, _MonPkg, ev_appel_transfere_kit())

//## event ev_eppel_termine_kit()
ev_eppel_termine_kit::ev_eppel_termine_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_eppel_termine_kit)
    setId(ev_eppel_termine_kit__MonPkg_id);
}

bool ev_eppel_termine_kit::isTypeOf(const short id) const {
    return (ev_eppel_termine_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_eppel_termine_kit, _MonPkg, _MonPkg, ev_eppel_termine_kit())

//## event ev_appel_termine_kit()
ev_appel_termine_kit::ev_appel_termine_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_termine_kit)
    setId(ev_appel_termine_kit__MonPkg_id);
}

bool ev_appel_termine_kit::isTypeOf(const short id) const {
    return (ev_appel_termine_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_termine_kit, _MonPkg, _MonPkg, ev_appel_termine_kit())

//## event ev_appel_en_cours()
ev_appel_en_cours::ev_appel_en_cours() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_appel_en_cours)
    setId(ev_appel_en_cours__MonPkg_id);
}

bool ev_appel_en_cours::isTypeOf(const short id) const {
    return (ev_appel_en_cours__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_appel_en_cours, _MonPkg, _MonPkg, ev_appel_en_cours())

//## event ev_raccroher_telephone()
ev_raccroher_telephone::ev_raccroher_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_raccroher_telephone)
    setId(ev_raccroher_telephone__MonPkg_id);
}

bool ev_raccroher_telephone::isTypeOf(const short id) const {
    return (ev_raccroher_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_raccroher_telephone, _MonPkg, _MonPkg, ev_raccroher_telephone())

//## event ev_rraccrocher_telephonel()
ev_rraccrocher_telephonel::ev_rraccrocher_telephonel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_rraccrocher_telephonel)
    setId(ev_rraccrocher_telephonel__MonPkg_id);
}

bool ev_rraccrocher_telephonel::isTypeOf(const short id) const {
    return (ev_rraccrocher_telephonel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_rraccrocher_telephonel, _MonPkg, _MonPkg, ev_rraccrocher_telephonel())

//## event ev_raccrocher_telephonel()
ev_raccrocher_telephonel::ev_raccrocher_telephonel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_raccrocher_telephonel)
    setId(ev_raccrocher_telephonel__MonPkg_id);
}

bool ev_raccrocher_telephonel::isTypeOf(const short id) const {
    return (ev_raccrocher_telephonel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_raccrocher_telephonel, _MonPkg, _MonPkg, ev_raccrocher_telephonel())

//## event ev_envoi_sms()
ev_envoi_sms::ev_envoi_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_envoi_sms)
    setId(ev_envoi_sms__MonPkg_id);
}

bool ev_envoi_sms::isTypeOf(const short id) const {
    return (ev_envoi_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_envoi_sms, _MonPkg, _MonPkg, ev_envoi_sms())

//## event ev_btn_telephone_sms()
ev_btn_telephone_sms::ev_btn_telephone_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_telephone_sms)
    setId(ev_btn_telephone_sms__MonPkg_id);
}

bool ev_btn_telephone_sms::isTypeOf(const short id) const {
    return (ev_btn_telephone_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_telephone_sms, _MonPkg, _MonPkg, ev_btn_telephone_sms())

//## event ev_lire_sms_kit()
ev_lire_sms_kit::ev_lire_sms_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_lire_sms_kit)
    setId(ev_lire_sms_kit__MonPkg_id);
}

bool ev_lire_sms_kit::isTypeOf(const short id) const {
    return (ev_lire_sms_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_lire_sms_kit, _MonPkg, _MonPkg, ev_lire_sms_kit())

//## event ev_nv_message_kit()
ev_nv_message_kit::ev_nv_message_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_nv_message_kit)
    setId(ev_nv_message_kit__MonPkg_id);
}

bool ev_nv_message_kit::isTypeOf(const short id) const {
    return (ev_nv_message_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_nv_message_kit, _MonPkg, _MonPkg, ev_nv_message_kit())

//## event ev_messagerie_vide_kit()
ev_messagerie_vide_kit::ev_messagerie_vide_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_messagerie_vide_kit)
    setId(ev_messagerie_vide_kit__MonPkg_id);
}

bool ev_messagerie_vide_kit::isTypeOf(const short id) const {
    return (ev_messagerie_vide_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_messagerie_vide_kit, _MonPkg, _MonPkg, ev_messagerie_vide_kit())

//## event ev_btn_lire_sms_kit()
ev_btn_lire_sms_kit::ev_btn_lire_sms_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_lire_sms_kit)
    setId(ev_btn_lire_sms_kit__MonPkg_id);
}

bool ev_btn_lire_sms_kit::isTypeOf(const short id) const {
    return (ev_btn_lire_sms_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_lire_sms_kit, _MonPkg, _MonPkg, ev_btn_lire_sms_kit())

//## event ev_transfert_sms_telephone_to_kit()
ev_transfert_sms_telephone_to_kit::ev_transfert_sms_telephone_to_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_transfert_sms_telephone_to_kit)
    setId(ev_transfert_sms_telephone_to_kit__MonPkg_id);
}

bool ev_transfert_sms_telephone_to_kit::isTypeOf(const short id) const {
    return (ev_transfert_sms_telephone_to_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_transfert_sms_telephone_to_kit, _MonPkg, _MonPkg, ev_transfert_sms_telephone_to_kit())

//## event ev_transfert_sms_to_kit(int)
ev_transfert_sms_to_kit::ev_transfert_sms_to_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_transfert_sms_to_kit)
    setId(ev_transfert_sms_to_kit__MonPkg_id);
}

ev_transfert_sms_to_kit::ev_transfert_sms_to_kit(int p_historique) : historique(p_historique) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_transfert_sms_to_kit)
    setId(ev_transfert_sms_to_kit__MonPkg_id);
}

bool ev_transfert_sms_to_kit::isTypeOf(const short id) const {
    return (ev_transfert_sms_to_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_transfert_sms_to_kit, _MonPkg, _MonPkg, ev_transfert_sms_to_kit(int))

//## event ev_transfert_sms_to_telephone(int)
ev_transfert_sms_to_telephone::ev_transfert_sms_to_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_transfert_sms_to_telephone)
    setId(ev_transfert_sms_to_telephone__MonPkg_id);
}

ev_transfert_sms_to_telephone::ev_transfert_sms_to_telephone(int p_historique) : historique(p_historique) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_transfert_sms_to_telephone)
    setId(ev_transfert_sms_to_telephone__MonPkg_id);
}

bool ev_transfert_sms_to_telephone::isTypeOf(const short id) const {
    return (ev_transfert_sms_to_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_transfert_sms_to_telephone, _MonPkg, _MonPkg, ev_transfert_sms_to_telephone(int))

//## event ev_tentative_lire_sms_kit()
ev_tentative_lire_sms_kit::ev_tentative_lire_sms_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tentative_lire_sms_kit)
    setId(ev_tentative_lire_sms_kit__MonPkg_id);
}

bool ev_tentative_lire_sms_kit::isTypeOf(const short id) const {
    return (ev_tentative_lire_sms_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_tentative_lire_sms_kit, _MonPkg, _MonPkg, ev_tentative_lire_sms_kit())

//## event ev_nv_sms_kit(int)
ev_nv_sms_kit::ev_nv_sms_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_nv_sms_kit)
    setId(ev_nv_sms_kit__MonPkg_id);
}

ev_nv_sms_kit::ev_nv_sms_kit(int p_sms_telephone) : sms_telephone(p_sms_telephone) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_nv_sms_kit)
    setId(ev_nv_sms_kit__MonPkg_id);
}

bool ev_nv_sms_kit::isTypeOf(const short id) const {
    return (ev_nv_sms_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_nv_sms_kit, _MonPkg, _MonPkg, ev_nv_sms_kit(int))

//## event ev_actualisation_sms_kit(int)
ev_actualisation_sms_kit::ev_actualisation_sms_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_actualisation_sms_kit)
    setId(ev_actualisation_sms_kit__MonPkg_id);
}

ev_actualisation_sms_kit::ev_actualisation_sms_kit(int p_sms_tel) : sms_tel(p_sms_tel) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_actualisation_sms_kit)
    setId(ev_actualisation_sms_kit__MonPkg_id);
}

bool ev_actualisation_sms_kit::isTypeOf(const short id) const {
    return (ev_actualisation_sms_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_actualisation_sms_kit, _MonPkg, _MonPkg, ev_actualisation_sms_kit(int))

//## event ev_btn_radio_on()
ev_btn_radio_on::ev_btn_radio_on() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_radio_on)
    setId(ev_btn_radio_on__MonPkg_id);
}

bool ev_btn_radio_on::isTypeOf(const short id) const {
    return (ev_btn_radio_on__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_radio_on, _MonPkg, _MonPkg, ev_btn_radio_on())

//## event ev_btn_radio_off()
ev_btn_radio_off::ev_btn_radio_off() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_radio_off)
    setId(ev_btn_radio_off__MonPkg_id);
}

bool ev_btn_radio_off::isTypeOf(const short id) const {
    return (ev_btn_radio_off__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_radio_off, _MonPkg, _MonPkg, ev_btn_radio_off())

//## event ev_transition_musique_1()
ev_transition_musique_1::ev_transition_musique_1() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_transition_musique_1)
    setId(ev_transition_musique_1__MonPkg_id);
}

bool ev_transition_musique_1::isTypeOf(const short id) const {
    return (ev_transition_musique_1__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_transition_musique_1, _MonPkg, _MonPkg, ev_transition_musique_1())

//## event ev_skip_musique()
ev_skip_musique::ev_skip_musique() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_skip_musique)
    setId(ev_skip_musique__MonPkg_id);
}

bool ev_skip_musique::isTypeOf(const short id) const {
    return (ev_skip_musique__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_skip_musique, _MonPkg, _MonPkg, ev_skip_musique())

//## event ev_btn_radio_skip()
ev_btn_radio_skip::ev_btn_radio_skip() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_radio_skip)
    setId(ev_btn_radio_skip__MonPkg_id);
}

bool ev_btn_radio_skip::isTypeOf(const short id) const {
    return (ev_btn_radio_skip__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_radio_skip, _MonPkg, _MonPkg, ev_btn_radio_skip())

//## event ev_btn_start_radio()
ev_btn_start_radio::ev_btn_start_radio() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_start_radio)
    setId(ev_btn_start_radio__MonPkg_id);
}

bool ev_btn_start_radio::isTypeOf(const short id) const {
    return (ev_btn_start_radio__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_start_radio, _MonPkg, _MonPkg, ev_btn_start_radio())

//## event ev_sonnerie_kit()
ev_sonnerie_kit::ev_sonnerie_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_sonnerie_kit)
    setId(ev_sonnerie_kit__MonPkg_id);
}

bool ev_sonnerie_kit::isTypeOf(const short id) const {
    return (ev_sonnerie_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_sonnerie_kit, _MonPkg, _MonPkg, ev_sonnerie_kit())

//## event eval()
eval::eval() {
    NOTIFY_EVENT_CONSTRUCTOR(eval)
    setId(eval__MonPkg_id);
}

bool eval::isTypeOf(const short id) const {
    return (eval__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(eval, _MonPkg, _MonPkg, eval())

//## event ev_fin_sonnerie()
ev_fin_sonnerie::ev_fin_sonnerie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_fin_sonnerie)
    setId(ev_fin_sonnerie__MonPkg_id);
}

bool ev_fin_sonnerie::isTypeOf(const short id) const {
    return (ev_fin_sonnerie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_fin_sonnerie, _MonPkg, _MonPkg, ev_fin_sonnerie())

//## event ev_bnt_appel_externe()
ev_bnt_appel_externe::ev_bnt_appel_externe() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_bnt_appel_externe)
    setId(ev_bnt_appel_externe__MonPkg_id);
}

bool ev_bnt_appel_externe::isTypeOf(const short id) const {
    return (ev_bnt_appel_externe__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_bnt_appel_externe, _MonPkg, _MonPkg, ev_bnt_appel_externe())

//## event ev_btn_appel_externe()
ev_btn_appel_externe::ev_btn_appel_externe() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_appel_externe)
    setId(ev_btn_appel_externe__MonPkg_id);
}

bool ev_btn_appel_externe::isTypeOf(const short id) const {
    return (ev_btn_appel_externe__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_appel_externe, _MonPkg, _MonPkg, ev_btn_appel_externe())

//## event ev_btn_appel_SIM()
ev_btn_appel_SIM::ev_btn_appel_SIM() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_appel_SIM)
    setId(ev_btn_appel_SIM__MonPkg_id);
}

bool ev_btn_appel_SIM::isTypeOf(const short id) const {
    return (ev_btn_appel_SIM__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_appel_SIM, _MonPkg, _MonPkg, ev_btn_appel_SIM())

//## event ev_btn_SIM_appel()
ev_btn_SIM_appel::ev_btn_SIM_appel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_SIM_appel)
    setId(ev_btn_SIM_appel__MonPkg_id);
}

bool ev_btn_SIM_appel::isTypeOf(const short id) const {
    return (ev_btn_SIM_appel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_SIM_appel, _MonPkg, _MonPkg, ev_btn_SIM_appel())

//## event ev_SIM_appel()
ev_SIM_appel::ev_SIM_appel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_SIM_appel)
    setId(ev_SIM_appel__MonPkg_id);
}

bool ev_SIM_appel::isTypeOf(const short id) const {
    return (ev_SIM_appel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_SIM_appel, _MonPkg, _MonPkg, ev_SIM_appel())

//## event ev_SIM_raccrocher()
ev_SIM_raccrocher::ev_SIM_raccrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_SIM_raccrocher)
    setId(ev_SIM_raccrocher__MonPkg_id);
}

bool ev_SIM_raccrocher::isTypeOf(const short id) const {
    return (ev_SIM_raccrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_SIM_raccrocher, _MonPkg, _MonPkg, ev_SIM_raccrocher())

//## event ev_btn_raccrocher_telephone()
ev_btn_raccrocher_telephone::ev_btn_raccrocher_telephone() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_raccrocher_telephone)
    setId(ev_btn_raccrocher_telephone__MonPkg_id);
}

bool ev_btn_raccrocher_telephone::isTypeOf(const short id) const {
    return (ev_btn_raccrocher_telephone__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_raccrocher_telephone, _MonPkg, _MonPkg, ev_btn_raccrocher_telephone())

//## event ev_SIM_refuser_appel()
ev_SIM_refuser_appel::ev_SIM_refuser_appel() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_SIM_refuser_appel)
    setId(ev_SIM_refuser_appel__MonPkg_id);
}

bool ev_SIM_refuser_appel::isTypeOf(const short id) const {
    return (ev_SIM_refuser_appel__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_SIM_refuser_appel, _MonPkg, _MonPkg, ev_SIM_refuser_appel())

//## event ev_telephone_decrocher()
ev_telephone_decrocher::ev_telephone_decrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_decrocher)
    setId(ev_telephone_decrocher__MonPkg_id);
}

bool ev_telephone_decrocher::isTypeOf(const short id) const {
    return (ev_telephone_decrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_decrocher, _MonPkg, _MonPkg, ev_telephone_decrocher())

//## event ev_telephone_raccrocher()
ev_telephone_raccrocher::ev_telephone_raccrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_raccrocher)
    setId(ev_telephone_raccrocher__MonPkg_id);
}

bool ev_telephone_raccrocher::isTypeOf(const short id) const {
    return (ev_telephone_raccrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_raccrocher, _MonPkg, _MonPkg, ev_telephone_raccrocher())

//## event ev_btn_telephone_raccrocher_()
ev_btn_telephone_raccrocher_::ev_btn_telephone_raccrocher_() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_telephone_raccrocher_)
    setId(ev_btn_telephone_raccrocher___MonPkg_id);
}

bool ev_btn_telephone_raccrocher_::isTypeOf(const short id) const {
    return (ev_btn_telephone_raccrocher___MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_telephone_raccrocher_, _MonPkg, _MonPkg, ev_btn_telephone_raccrocher_())

//## event ev_kit_decrocher()
ev_kit_decrocher::ev_kit_decrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_decrocher)
    setId(ev_kit_decrocher__MonPkg_id);
}

bool ev_kit_decrocher::isTypeOf(const short id) const {
    return (ev_kit_decrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_decrocher, _MonPkg, _MonPkg, ev_kit_decrocher())

//## event ev_kit_raccrocher()
ev_kit_raccrocher::ev_kit_raccrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_raccrocher)
    setId(ev_kit_raccrocher__MonPkg_id);
}

bool ev_kit_raccrocher::isTypeOf(const short id) const {
    return (ev_kit_raccrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_raccrocher, _MonPkg, _MonPkg, ev_kit_raccrocher())

//## event ev_kit_appel_entrant()
ev_kit_appel_entrant::ev_kit_appel_entrant() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_appel_entrant)
    setId(ev_kit_appel_entrant__MonPkg_id);
}

bool ev_kit_appel_entrant::isTypeOf(const short id) const {
    return (ev_kit_appel_entrant__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_appel_entrant, _MonPkg, _MonPkg, ev_kit_appel_entrant())

//## event ev_kit_sonnerie()
ev_kit_sonnerie::ev_kit_sonnerie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_sonnerie)
    setId(ev_kit_sonnerie__MonPkg_id);
}

bool ev_kit_sonnerie::isTypeOf(const short id) const {
    return (ev_kit_sonnerie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_sonnerie, _MonPkg, _MonPkg, ev_kit_sonnerie())

//## event ev_kit_appel_transfere()
ev_kit_appel_transfere::ev_kit_appel_transfere() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_appel_transfere)
    setId(ev_kit_appel_transfere__MonPkg_id);
}

bool ev_kit_appel_transfere::isTypeOf(const short id) const {
    return (ev_kit_appel_transfere__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_appel_transfere, _MonPkg, _MonPkg, ev_kit_appel_transfere())

//## event ev_kit_appel_termine()
ev_kit_appel_termine::ev_kit_appel_termine() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_appel_termine)
    setId(ev_kit_appel_termine__MonPkg_id);
}

bool ev_kit_appel_termine::isTypeOf(const short id) const {
    return (ev_kit_appel_termine__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_appel_termine, _MonPkg, _MonPkg, ev_kit_appel_termine())

//## event ev_btn_kit_raccrocher()
ev_btn_kit_raccrocher::ev_btn_kit_raccrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_kit_raccrocher)
    setId(ev_btn_kit_raccrocher__MonPkg_id);
}

bool ev_btn_kit_raccrocher::isTypeOf(const short id) const {
    return (ev_btn_kit_raccrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_kit_raccrocher, _MonPkg, _MonPkg, ev_btn_kit_raccrocher())

//## event ev_btn_kit_decrocher()
ev_btn_kit_decrocher::ev_btn_kit_decrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_kit_decrocher)
    setId(ev_btn_kit_decrocher__MonPkg_id);
}

bool ev_btn_kit_decrocher::isTypeOf(const short id) const {
    return (ev_btn_kit_decrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_kit_decrocher, _MonPkg, _MonPkg, ev_btn_kit_decrocher())

//## event ev_btn_SIM_sms()
ev_btn_SIM_sms::ev_btn_SIM_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_SIM_sms)
    setId(ev_btn_SIM_sms__MonPkg_id);
}

bool ev_btn_SIM_sms::isTypeOf(const short id) const {
    return (ev_btn_SIM_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_SIM_sms, _MonPkg, _MonPkg, ev_btn_SIM_sms())

//## event ev_SIM_envoi_sms()
ev_SIM_envoi_sms::ev_SIM_envoi_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_SIM_envoi_sms)
    setId(ev_SIM_envoi_sms__MonPkg_id);
}

bool ev_SIM_envoi_sms::isTypeOf(const short id) const {
    return (ev_SIM_envoi_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_SIM_envoi_sms, _MonPkg, _MonPkg, ev_SIM_envoi_sms())

//## event ev_lire_sms()
ev_lire_sms::ev_lire_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_lire_sms)
    setId(ev_lire_sms__MonPkg_id);
}

bool ev_lire_sms::isTypeOf(const short id) const {
    return (ev_lire_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_lire_sms, _MonPkg, _MonPkg, ev_lire_sms())

//## event ev_kit_lire_sms()
ev_kit_lire_sms::ev_kit_lire_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_lire_sms)
    setId(ev_kit_lire_sms__MonPkg_id);
}

bool ev_kit_lire_sms::isTypeOf(const short id) const {
    return (ev_kit_lire_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_lire_sms, _MonPkg, _MonPkg, ev_kit_lire_sms())

//## event ev_btn_telephone_lire_sms()
ev_btn_telephone_lire_sms::ev_btn_telephone_lire_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_telephone_lire_sms)
    setId(ev_btn_telephone_lire_sms__MonPkg_id);
}

bool ev_btn_telephone_lire_sms::isTypeOf(const short id) const {
    return (ev_btn_telephone_lire_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_telephone_lire_sms, _MonPkg, _MonPkg, ev_btn_telephone_lire_sms())

//## event ev_btn_kit_lire_sms()
ev_btn_kit_lire_sms::ev_btn_kit_lire_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_kit_lire_sms)
    setId(ev_btn_kit_lire_sms__MonPkg_id);
}

bool ev_btn_kit_lire_sms::isTypeOf(const short id) const {
    return (ev_btn_kit_lire_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_kit_lire_sms, _MonPkg, _MonPkg, ev_btn_kit_lire_sms())

//## event ev_SIM_appel_en_cours()
ev_SIM_appel_en_cours::ev_SIM_appel_en_cours() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_SIM_appel_en_cours)
    setId(ev_SIM_appel_en_cours__MonPkg_id);
}

bool ev_SIM_appel_en_cours::isTypeOf(const short id) const {
    return (ev_SIM_appel_en_cours__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_SIM_appel_en_cours, _MonPkg, _MonPkg, ev_SIM_appel_en_cours())

//## event ev_btn_telephone_decrocher()
ev_btn_telephone_decrocher::ev_btn_telephone_decrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_telephone_decrocher)
    setId(ev_btn_telephone_decrocher__MonPkg_id);
}

bool ev_btn_telephone_decrocher::isTypeOf(const short id) const {
    return (ev_btn_telephone_decrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_telephone_decrocher, _MonPkg, _MonPkg, ev_btn_telephone_decrocher())

//## event ev_btn_telephone_raccrocher()
ev_btn_telephone_raccrocher::ev_btn_telephone_raccrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_telephone_raccrocher)
    setId(ev_btn_telephone_raccrocher__MonPkg_id);
}

bool ev_btn_telephone_raccrocher::isTypeOf(const short id) const {
    return (ev_btn_telephone_raccrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_telephone_raccrocher, _MonPkg, _MonPkg, ev_btn_telephone_raccrocher())

//## event ev_bnt_telephone_decrocher()
ev_bnt_telephone_decrocher::ev_bnt_telephone_decrocher() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_bnt_telephone_decrocher)
    setId(ev_bnt_telephone_decrocher__MonPkg_id);
}

bool ev_bnt_telephone_decrocher::isTypeOf(const short id) const {
    return (ev_bnt_telephone_decrocher__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_bnt_telephone_decrocher, _MonPkg, _MonPkg, ev_bnt_telephone_decrocher())

//## event ev_kit_fin_sonnerie()
ev_kit_fin_sonnerie::ev_kit_fin_sonnerie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_fin_sonnerie)
    setId(ev_kit_fin_sonnerie__MonPkg_id);
}

bool ev_kit_fin_sonnerie::isTypeOf(const short id) const {
    return (ev_kit_fin_sonnerie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_fin_sonnerie, _MonPkg, _MonPkg, ev_kit_fin_sonnerie())

//## event ev_btn_ok()
ev_btn_ok::ev_btn_ok() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_ok)
    setId(ev_btn_ok__MonPkg_id);
}

bool ev_btn_ok::isTypeOf(const short id) const {
    return (ev_btn_ok__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_ok, _MonPkg, _MonPkg, ev_btn_ok())

//## event ev_kit_bluetooth_desactive()
ev_kit_bluetooth_desactive::ev_kit_bluetooth_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_bluetooth_desactive)
    setId(ev_kit_bluetooth_desactive__MonPkg_id);
}

bool ev_kit_bluetooth_desactive::isTypeOf(const short id) const {
    return (ev_kit_bluetooth_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_bluetooth_desactive, _MonPkg, _MonPkg, ev_kit_bluetooth_desactive())

//## event ev()
ev::ev() {
    NOTIFY_EVENT_CONSTRUCTOR(ev)
    setId(ev__MonPkg_id);
}

bool ev::isTypeOf(const short id) const {
    return (ev__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev, _MonPkg, _MonPkg, ev())

//## event ev_tel_demande_jumelage()
ev_tel_demande_jumelage::ev_tel_demande_jumelage() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_tel_demande_jumelage)
    setId(ev_tel_demande_jumelage__MonPkg_id);
}

bool ev_tel_demande_jumelage::isTypeOf(const short id) const {
    return (ev_tel_demande_jumelage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_tel_demande_jumelage, _MonPkg, _MonPkg, ev_tel_demande_jumelage())

//## event ev_telephone_demande_jumelage(OMString)
ev_telephone_demande_jumelage::ev_telephone_demande_jumelage() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_demande_jumelage)
    setId(ev_telephone_demande_jumelage__MonPkg_id);
}

ev_telephone_demande_jumelage::ev_telephone_demande_jumelage(OMString p_mot_de_passe) : mot_de_passe(p_mot_de_passe) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_demande_jumelage)
    setId(ev_telephone_demande_jumelage__MonPkg_id);
}

bool ev_telephone_demande_jumelage::isTypeOf(const short id) const {
    return (ev_telephone_demande_jumelage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_demande_jumelage, _MonPkg, _MonPkg, ev_telephone_demande_jumelage(OMString))

//## event ev_kit_demande_mdp()
ev_kit_demande_mdp::ev_kit_demande_mdp() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_demande_mdp)
    setId(ev_kit_demande_mdp__MonPkg_id);
}

bool ev_kit_demande_mdp::isTypeOf(const short id) const {
    return (ev_kit_demande_mdp__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_demande_mdp, _MonPkg, _MonPkg, ev_kit_demande_mdp())

//## event ev_telephone_tentative_mdp(OMString)
ev_telephone_tentative_mdp::ev_telephone_tentative_mdp() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_tentative_mdp)
    setId(ev_telephone_tentative_mdp__MonPkg_id);
}

ev_telephone_tentative_mdp::ev_telephone_tentative_mdp(OMString p_mdp) : mdp(p_mdp) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_tentative_mdp)
    setId(ev_telephone_tentative_mdp__MonPkg_id);
}

bool ev_telephone_tentative_mdp::isTypeOf(const short id) const {
    return (ev_telephone_tentative_mdp__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_tentative_mdp, _MonPkg, _MonPkg, ev_telephone_tentative_mdp(OMString))

//## event ev_kit_mdp_correct()
ev_kit_mdp_correct::ev_kit_mdp_correct() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_mdp_correct)
    setId(ev_kit_mdp_correct__MonPkg_id);
}

bool ev_kit_mdp_correct::isTypeOf(const short id) const {
    return (ev_kit_mdp_correct__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_mdp_correct, _MonPkg, _MonPkg, ev_kit_mdp_correct())

//## event ev_kit_mdp_incorrect()
ev_kit_mdp_incorrect::ev_kit_mdp_incorrect() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_mdp_incorrect)
    setId(ev_kit_mdp_incorrect__MonPkg_id);
}

bool ev_kit_mdp_incorrect::isTypeOf(const short id) const {
    return (ev_kit_mdp_incorrect__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_mdp_incorrect, _MonPkg, _MonPkg, ev_kit_mdp_incorrect())

//## event ev_telephone_demande_connexion()
ev_telephone_demande_connexion::ev_telephone_demande_connexion() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_demande_connexion)
    setId(ev_telephone_demande_connexion__MonPkg_id);
}

bool ev_telephone_demande_connexion::isTypeOf(const short id) const {
    return (ev_telephone_demande_connexion__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_demande_connexion, _MonPkg, _MonPkg, ev_telephone_demande_connexion())

//## event ev_kit_connexion_acceptee()
ev_kit_connexion_acceptee::ev_kit_connexion_acceptee() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_connexion_acceptee)
    setId(ev_kit_connexion_acceptee__MonPkg_id);
}

bool ev_kit_connexion_acceptee::isTypeOf(const short id) const {
    return (ev_kit_connexion_acceptee__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_connexion_acceptee, _MonPkg, _MonPkg, ev_kit_connexion_acceptee())

//## event ev_btn_appairage()
ev_btn_appairage::ev_btn_appairage() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_appairage)
    setId(ev_btn_appairage__MonPkg_id);
}

bool ev_btn_appairage::isTypeOf(const short id) const {
    return (ev_btn_appairage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_appairage, _MonPkg, _MonPkg, ev_btn_appairage())

//## event ev_btn_telephone_appairage()
ev_btn_telephone_appairage::ev_btn_telephone_appairage() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_btn_telephone_appairage)
    setId(ev_btn_telephone_appairage__MonPkg_id);
}

bool ev_btn_telephone_appairage::isTypeOf(const short id) const {
    return (ev_btn_telephone_appairage__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_btn_telephone_appairage, _MonPkg, _MonPkg, ev_btn_telephone_appairage())

//## event ev_telephone_kit_appel_entrant()
ev_telephone_kit_appel_entrant::ev_telephone_kit_appel_entrant() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_kit_appel_entrant)
    setId(ev_telephone_kit_appel_entrant__MonPkg_id);
}

bool ev_telephone_kit_appel_entrant::isTypeOf(const short id) const {
    return (ev_telephone_kit_appel_entrant__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_kit_appel_entrant, _MonPkg, _MonPkg, ev_telephone_kit_appel_entrant())

//## event ev_telephone_kit_sonnerie()
ev_telephone_kit_sonnerie::ev_telephone_kit_sonnerie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_kit_sonnerie)
    setId(ev_telephone_kit_sonnerie__MonPkg_id);
}

bool ev_telephone_kit_sonnerie::isTypeOf(const short id) const {
    return (ev_telephone_kit_sonnerie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_kit_sonnerie, _MonPkg, _MonPkg, ev_telephone_kit_sonnerie())

//## event ev_telephone_kit_fin_sonnerie()
ev_telephone_kit_fin_sonnerie::ev_telephone_kit_fin_sonnerie() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_kit_fin_sonnerie)
    setId(ev_telephone_kit_fin_sonnerie__MonPkg_id);
}

bool ev_telephone_kit_fin_sonnerie::isTypeOf(const short id) const {
    return (ev_telephone_kit_fin_sonnerie__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_kit_fin_sonnerie, _MonPkg, _MonPkg, ev_telephone_kit_fin_sonnerie())

//## event ev_telephone_kit_appel_transfere()
ev_telephone_kit_appel_transfere::ev_telephone_kit_appel_transfere() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_kit_appel_transfere)
    setId(ev_telephone_kit_appel_transfere__MonPkg_id);
}

bool ev_telephone_kit_appel_transfere::isTypeOf(const short id) const {
    return (ev_telephone_kit_appel_transfere__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_kit_appel_transfere, _MonPkg, _MonPkg, ev_telephone_kit_appel_transfere())

//## event ev_telephone_kit_appel_termine()
ev_telephone_kit_appel_termine::ev_telephone_kit_appel_termine() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_kit_appel_termine)
    setId(ev_telephone_kit_appel_termine__MonPkg_id);
}

bool ev_telephone_kit_appel_termine::isTypeOf(const short id) const {
    return (ev_telephone_kit_appel_termine__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_kit_appel_termine, _MonPkg, _MonPkg, ev_telephone_kit_appel_termine())

//## event ev_telephone_appel_entrant_kit()
ev_telephone_appel_entrant_kit::ev_telephone_appel_entrant_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_appel_entrant_kit)
    setId(ev_telephone_appel_entrant_kit__MonPkg_id);
}

bool ev_telephone_appel_entrant_kit::isTypeOf(const short id) const {
    return (ev_telephone_appel_entrant_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_appel_entrant_kit, _MonPkg, _MonPkg, ev_telephone_appel_entrant_kit())

//## event ev_telephone_sonnerie_kit()
ev_telephone_sonnerie_kit::ev_telephone_sonnerie_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_sonnerie_kit)
    setId(ev_telephone_sonnerie_kit__MonPkg_id);
}

bool ev_telephone_sonnerie_kit::isTypeOf(const short id) const {
    return (ev_telephone_sonnerie_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_sonnerie_kit, _MonPkg, _MonPkg, ev_telephone_sonnerie_kit())

//## event ev_telephone_appel_transfere_kit()
ev_telephone_appel_transfere_kit::ev_telephone_appel_transfere_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_appel_transfere_kit)
    setId(ev_telephone_appel_transfere_kit__MonPkg_id);
}

bool ev_telephone_appel_transfere_kit::isTypeOf(const short id) const {
    return (ev_telephone_appel_transfere_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_appel_transfere_kit, _MonPkg, _MonPkg, ev_telephone_appel_transfere_kit())

//## event ev_telephone_appel_kit_termine()
ev_telephone_appel_kit_termine::ev_telephone_appel_kit_termine() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_appel_kit_termine)
    setId(ev_telephone_appel_kit_termine__MonPkg_id);
}

bool ev_telephone_appel_kit_termine::isTypeOf(const short id) const {
    return (ev_telephone_appel_kit_termine__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_appel_kit_termine, _MonPkg, _MonPkg, ev_telephone_appel_kit_termine())

//## event ev_telephone_appel_termine_kit()
ev_telephone_appel_termine_kit::ev_telephone_appel_termine_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_appel_termine_kit)
    setId(ev_telephone_appel_termine_kit__MonPkg_id);
}

bool ev_telephone_appel_termine_kit::isTypeOf(const short id) const {
    return (ev_telephone_appel_termine_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_appel_termine_kit, _MonPkg, _MonPkg, ev_telephone_appel_termine_kit())

//## event ev_telephone_fin_sonnerie_kit()
ev_telephone_fin_sonnerie_kit::ev_telephone_fin_sonnerie_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_fin_sonnerie_kit)
    setId(ev_telephone_fin_sonnerie_kit__MonPkg_id);
}

bool ev_telephone_fin_sonnerie_kit::isTypeOf(const short id) const {
    return (ev_telephone_fin_sonnerie_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_fin_sonnerie_kit, _MonPkg, _MonPkg, ev_telephone_fin_sonnerie_kit())

//## event ev_kit_tentative_lire_sms()
ev_kit_tentative_lire_sms::ev_kit_tentative_lire_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_tentative_lire_sms)
    setId(ev_kit_tentative_lire_sms__MonPkg_id);
}

bool ev_kit_tentative_lire_sms::isTypeOf(const short id) const {
    return (ev_kit_tentative_lire_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_tentative_lire_sms, _MonPkg, _MonPkg, ev_kit_tentative_lire_sms())

//## event ev_telephone_sms_historique_kit(int)
ev_telephone_sms_historique_kit::ev_telephone_sms_historique_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_sms_historique_kit)
    setId(ev_telephone_sms_historique_kit__MonPkg_id);
}

ev_telephone_sms_historique_kit::ev_telephone_sms_historique_kit(int p_historique) : historique(p_historique) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_sms_historique_kit)
    setId(ev_telephone_sms_historique_kit__MonPkg_id);
}

bool ev_telephone_sms_historique_kit::isTypeOf(const short id) const {
    return (ev_telephone_sms_historique_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_sms_historique_kit, _MonPkg, _MonPkg, ev_telephone_sms_historique_kit(int))

//## event ev_telephone_sms_nouveau_kit(int)
ev_telephone_sms_nouveau_kit::ev_telephone_sms_nouveau_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_sms_nouveau_kit)
    setId(ev_telephone_sms_nouveau_kit__MonPkg_id);
}

ev_telephone_sms_nouveau_kit::ev_telephone_sms_nouveau_kit(int p_sms_telephone) : sms_telephone(p_sms_telephone) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_sms_nouveau_kit)
    setId(ev_telephone_sms_nouveau_kit__MonPkg_id);
}

bool ev_telephone_sms_nouveau_kit::isTypeOf(const short id) const {
    return (ev_telephone_sms_nouveau_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_sms_nouveau_kit, _MonPkg, _MonPkg, ev_telephone_sms_nouveau_kit(int))

//## event ev_telephone_appel_en_cours()
ev_telephone_appel_en_cours::ev_telephone_appel_en_cours() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_appel_en_cours)
    setId(ev_telephone_appel_en_cours__MonPkg_id);
}

bool ev_telephone_appel_en_cours::isTypeOf(const short id) const {
    return (ev_telephone_appel_en_cours__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_appel_en_cours, _MonPkg, _MonPkg, ev_telephone_appel_en_cours())

//## event ev_telephone_appel_en_cours_SIM()
ev_telephone_appel_en_cours_SIM::ev_telephone_appel_en_cours_SIM() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_appel_en_cours_SIM)
    setId(ev_telephone_appel_en_cours_SIM__MonPkg_id);
}

bool ev_telephone_appel_en_cours_SIM::isTypeOf(const short id) const {
    return (ev_telephone_appel_en_cours_SIM__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_appel_en_cours_SIM, _MonPkg, _MonPkg, ev_telephone_appel_en_cours_SIM())

//## event ev_telephone_raccrocher_SIM()
ev_telephone_raccrocher_SIM::ev_telephone_raccrocher_SIM() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_raccrocher_SIM)
    setId(ev_telephone_raccrocher_SIM__MonPkg_id);
}

bool ev_telephone_raccrocher_SIM::isTypeOf(const short id) const {
    return (ev_telephone_raccrocher_SIM__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_raccrocher_SIM, _MonPkg, _MonPkg, ev_telephone_raccrocher_SIM())

//## event ev_kit_actualisation_sms(int)
ev_kit_actualisation_sms::ev_kit_actualisation_sms() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_actualisation_sms)
    setId(ev_kit_actualisation_sms__MonPkg_id);
}

ev_kit_actualisation_sms::ev_kit_actualisation_sms(int p_sms_tel) : sms_tel(p_sms_tel) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_kit_actualisation_sms)
    setId(ev_kit_actualisation_sms__MonPkg_id);
}

bool ev_kit_actualisation_sms::isTypeOf(const short id) const {
    return (ev_kit_actualisation_sms__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_kit_actualisation_sms, _MonPkg, _MonPkg, ev_kit_actualisation_sms(int))

//## event ev_telephone_actualisation_batterie_kit(int)
ev_telephone_actualisation_batterie_kit::ev_telephone_actualisation_batterie_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_actualisation_batterie_kit)
    setId(ev_telephone_actualisation_batterie_kit__MonPkg_id);
}

ev_telephone_actualisation_batterie_kit::ev_telephone_actualisation_batterie_kit(int p_pourcentage) : pourcentage(p_pourcentage) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_actualisation_batterie_kit)
    setId(ev_telephone_actualisation_batterie_kit__MonPkg_id);
}

bool ev_telephone_actualisation_batterie_kit::isTypeOf(const short id) const {
    return (ev_telephone_actualisation_batterie_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_actualisation_batterie_kit, _MonPkg, _MonPkg, ev_telephone_actualisation_batterie_kit(int))

//## event ev_telephone_actualisation_sms_kit(int)
ev_telephone_actualisation_sms_kit::ev_telephone_actualisation_sms_kit() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_actualisation_sms_kit)
    setId(ev_telephone_actualisation_sms_kit__MonPkg_id);
}

ev_telephone_actualisation_sms_kit::ev_telephone_actualisation_sms_kit(int p_sms_tel) : sms_tel(p_sms_tel) {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_actualisation_sms_kit)
    setId(ev_telephone_actualisation_sms_kit__MonPkg_id);
}

bool ev_telephone_actualisation_sms_kit::isTypeOf(const short id) const {
    return (ev_telephone_actualisation_sms_kit__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_actualisation_sms_kit, _MonPkg, _MonPkg, ev_telephone_actualisation_sms_kit(int))

//## event ev_telephone_bluetooth_desactive()
ev_telephone_bluetooth_desactive::ev_telephone_bluetooth_desactive() {
    NOTIFY_EVENT_CONSTRUCTOR(ev_telephone_bluetooth_desactive)
    setId(ev_telephone_bluetooth_desactive__MonPkg_id);
}

bool ev_telephone_bluetooth_desactive::isTypeOf(const short id) const {
    return (ev_telephone_bluetooth_desactive__MonPkg_id==id);
}

IMPLEMENT_META_EVENT_P(ev_telephone_bluetooth_desactive, _MonPkg, _MonPkg, ev_telephone_bluetooth_desactive())

/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.cpp
*********************************************************************/
