#ifndef ODOMETRY_CPP
#define ODOMETRY_CPP

#include <nav_msgs/Odometry.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/Twist.h>
#include <ros/ros.h>
#include <tf/tf.h>
#include <cmath>

using namespace ros;
using namespace tf;
using geometry_msgs::Pose2D;

// Écoute /odom et garde la dernière position du robot dans "position" de type Pose2D
class Odometry {
public:
  Pose2D position;
  geometry_msgs::Twist vitesse;
  double distance_totale = 0.0;

  void init(NodeHandle &nh) {
    odom_sub = nh.subscribe("/odom", 100, &Odometry::odomCallback, this);
  }

private:
  Subscriber odom_sub;
  bool position_recue_ = false;

  void odomCallback(const nav_msgs::Odometry::ConstPtr &msg) {
    Quaternion quaternion_odom = Quaternion(
      msg->pose.pose.orientation.x,
      msg->pose.pose.orientation.y,
      msg->pose.pose.orientation.z,
      msg->pose.pose.orientation.w
    );
    const double x = msg->pose.pose.position.x;
    const double y = msg->pose.pose.position.y;
    if (position_recue_) {
      distance_totale += std::hypot(x - position.x, y - position.y);
    }
    position_recue_ = true;
    position.x = x;
    position.y = y;
    position.theta = getYaw(quaternion_odom);
    vitesse = msg->twist.twist;
  }
};

#endif
