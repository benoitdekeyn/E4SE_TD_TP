/********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _SysVehicule
//!	Generated Date	: Thu, 26, Nov 2026  
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX

#define _OMSTATECHART_ANIMATED
//#]

//## dependency _SysVehicule
#include "_SysVehicule.h"
//#[ ignore
#define _MonPkg__SysVehicule__SysVehicule_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_Operation_215_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_VOYANT_kit_SERIALIZE aomsmethod->addAttribute("etat", x2String(etat));

#define _MonPkg__SysVehicule_accelerer_SERIALIZE aomsmethod->addAttribute("accelPedal", x2String(accelPedal));

#define _MonPkg__SysVehicule_affichage_batterie_telephone_vehicule_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_alerte_depassement_SERIALIZE aomsmethod->addAttribute("actif", x2String(actif));

#define _MonPkg__SysVehicule_arreter_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_batterie_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_carburant_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_distance_voiture_devant_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_regulateur_distance_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_regulateur_vitesse_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_vitesse_distance_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_charge_telephone_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_decharge_telephone_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_envoi_batterie_kit_SERIALIZE aomsmethod->addAttribute("batterie_telephone", x2String(batterie_telephone));

#define _MonPkg__SysVehicule_eteindre_telephone_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_actualisation_sms_telephone_SERIALIZE aomsmethod->addAttribute("incrementation", x2String(incrementation));

#define _MonPkg__SysVehicule_ex_demarrer_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_depanner_batterie_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_jumeler_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_ok_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_remplir_carburant_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_vitesseConsigne_SERIALIZE aomsmethod->addAttribute("delta", x2String(delta));

#define _MonPkg__SysVehicule_freiner_injection_SERIALIZE aomsmethod->addAttribute("brakePedal", x2String(brakePedal));

#define _MonPkg__SysVehicule_init_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_play_sound_SERIALIZE aomsmethod->addAttribute("fichier", x2String(fichier));

#define _MonPkg__SysVehicule_regulateur_Prof_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_verifier_mdp_SERIALIZE aomsmethod->addAttribute("mdp", x2String(mdp));

#define OMAnim__MonPkg__SysVehicule_setAccelPedal_double_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_accelPedal)

#define OMAnim__MonPkg__SysVehicule_setAccelPedal_double_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setAffichage_liste_appareils_OMString_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_affichage_liste_appareils)

#define OMAnim__MonPkg__SysVehicule_setAffichage_liste_appareils_OMString_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setAlpha_int_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_alpha)

#define OMAnim__MonPkg__SysVehicule_setAlpha_int_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setBrakePedal_double_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_brakePedal)

#define OMAnim__MonPkg__SysVehicule_setBrakePedal_double_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setChamp_mdp_OMString_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_champ_mdp)

#define OMAnim__MonPkg__SysVehicule_setChamp_mdp_OMString_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_cmd_bluetooth_telephone_actif)

#define OMAnim__MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_cmd_charge_vehicule_telephone)

#define OMAnim__MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setCmd_contact_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_cmd_contact)

#define OMAnim__MonPkg__SysVehicule_setCmd_contact_bool_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setCmd_radio_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_cmd_radio)

#define OMAnim__MonPkg__SysVehicule_setCmd_radio_bool_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_cmd_simulation_voiture_devant)

#define OMAnim__MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setDistance_inter_voiture_double_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_distance_inter_voiture)

#define OMAnim__MonPkg__SysVehicule_setDistance_inter_voiture_double_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setTelephone_allume_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_telephone_allume)

#define OMAnim__MonPkg__SysVehicule_setTelephone_allume_bool_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setVitesse_voiture_devant_double_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_vitesse_voiture_devant)

#define OMAnim__MonPkg__SysVehicule_setVitesse_voiture_devant_double_SERIALIZE_RET_VAL
//#]

//## package _MonPkg

//## class _SysVehicule
void _SysVehicule::accelerer(double accelPedal) {
    NOTIFY_OPERATION(accelerer, accelerer(double), 1, _MonPkg__SysVehicule_accelerer_SERIALIZE);
    //#[ operation accelerer(double)
    // --- PARAMETRES EXTERNES ---
    const double MAX_THROTTLE = PARAM_SIMU_max_throttle;
    const double CST_RALENTI  = throttle_repos;
    const double MAX_ACCEL    = (double)PARAM_SIMU_max_accel;
    
    // --- LOGIQUE ---
    // Mise � l'�chelle : 0->10 sur la p�dale donne 1.0->10.0 sur le throttle
    double plage_utile = MAX_THROTTLE - CST_RALENTI;
    throttle = CST_RALENTI + (accelPedal / MAX_ACCEL) * plage_utile;
    //#]
}

void _SysVehicule::arreter() {
    NOTIFY_OPERATION(arreter, arreter(), 0, _MonPkg__SysVehicule_arreter_SERIALIZE);
    //#[ operation arreter()
    //stop engine
    ignition=false;
    //#]
}

void _SysVehicule::ex_demarrer() {
    NOTIFY_OPERATION(ex_demarrer, ex_demarrer(), 0, _MonPkg__SysVehicule_ex_demarrer_SERIALIZE);
    //#[ operation ex_demarrer()
    ignition = true;
    throttle = throttle_repos;
    niveau_batterie -= 10;
    //#]
}

void _SysVehicule::calcul_vitesse_distance() {
    NOTIFY_OPERATION(calcul_vitesse_distance, calcul_vitesse_distance(), 0, _MonPkg__SysVehicule_calcul_vitesse_distance_SERIALIZE);
    //#[ operation calcul_vitesse_distance()
    // --- PARAMETRES EXTERNES ---
    const double MAX_SPEED            = (double)PARAM_SIMU_max_speed;        // ex: 120 km/h
    const double MASSE                = (double)PARAM_SIMU_masse;            // ex: 1200 kg
    const double PUISSANCE            = (double)PARAM_SIMU_puissance_moteur; // ex: 600 N par unit� de throttle
    const double FORCE_FREINS         = (double)PARAM_SIMU_puissance_frein;  // ex: 80 N
    const double CST_RALENTI          = throttle_repos;                      // ex: 1.0
    const double MAX_BRAKE            = (double)PARAM_SIMU_max_brake;        // ex: 10.0
    const double AIR_DRAG             = PARAM_SIMU_frottement_air;           // en kg/m (mettre ~0.4)
    const double DELTA_T_MS           = (double)(1000/PARAM_SIMU_freq_rafraichissement);
    
    // --- CONSTANTES PHYSIQUES ET MATHEMATIQUES ---
    const double CST_COEFF_ROULEMENT   = 0.05;
    const double CST_MULTIPLICATEUR_F  = 10.0;
    const double CST_GRAVITE           = 9.81;
    const double CST_PI_SUR_180        = 3.14159 / 180.0;
    const double CST_CONVERSION_KMH_MS = 3.6;
    const double CST_CONVERSION_MS_S   = 1000.0;
    const double ZERO                  = 0.0;
    
    // --- LOGIQUE ---
    const double dt = DELTA_T_MS / CST_CONVERSION_MS_S; // 0.05 s
    
    if (ignition == false) {
        throttle = ZERO;
    }
    
    // 1. Force motrice / Frein moteur
    double forceMoteur = ZERO;
    
    if (throttle <= CST_RALENTI || ignition == false) {
        if (float_speed > 10.0) {
            // Au-dessus de 10 km/h pied lev� : couple r�sistant m�canique (frein moteur ~300 N)
            forceMoteur = -300.0;
        } else {
            // En dessous de 10 km/h : traction douce du ralenti pour ne pas caler
            forceMoteur = throttle * PUISSANCE;
        }
    } else {
        // Phase d'acc�l�ration active (p�dale ou r�gulateur)
        forceMoteur = throttle * PUISSANCE;
    }
    
    // 2. Calcul des forces r�sistantes (Unit�s SI : Newtons)
    const double vitesse_ms = float_speed / CST_CONVERSION_KMH_MS;
    
    // Tra�n�e a�rodynamique pure : F = (1/2 * rho * S * Cx) * v^2
    const double forceAir = AIR_DRAG * vitesse_ms * vitesse_ms;
    
    // Frottement au sol (roulement des pneumatiques)
    const double forceRoulement = CST_COEFF_ROULEMENT * MASSE * CST_GRAVITE * cos(alpha * CST_PI_SUR_180);
    
    // Gravit� le long de la pente
    const double forceGravite = MASSE * CST_GRAVITE * sin(alpha * CST_PI_SUR_180);
    
    // Frein m�canique progressif
    double pedale_frein = brakePedal;
    if (pedale_frein > MAX_BRAKE) pedale_frein = MAX_BRAKE;
    if (pedale_frein < ZERO) pedale_frein = ZERO;
    const double forceFrein = (pedale_frein / MAX_BRAKE) * (FORCE_FREINS * CST_MULTIPLICATEUR_F * MASSE / 100.0);
    
    // 3. Somme des forces et acc�l�ration Newtonienne (m/s�)
    const double forceTotale = forceMoteur - forceFrein - forceAir - forceRoulement - forceGravite;
    const double acceleration = forceTotale / MASSE;
    
    // 4. Int�gration temporelle et bridage
    float_speed += (acceleration * dt) * CST_CONVERSION_KMH_MS;
    
    if (float_speed > MAX_SPEED) float_speed = MAX_SPEED;
    if (float_speed < ZERO) float_speed = ZERO;
    
    float_distance += (float_speed / CST_CONVERSION_KMH_MS) * dt;
    
    speed = (int)float_speed;
    distance = (int)float_distance;
    //#]
}

void _SysVehicule::freiner_injection(double brakePedal) {
    NOTIFY_OPERATION(freiner_injection, freiner_injection(double), 1, _MonPkg__SysVehicule_freiner_injection_SERIALIZE);
    //#[ operation freiner_injection(double)
    if (throttle > throttle_repos) {
    	throttle = throttle_repos;
    }
    //#]
}

void _SysVehicule::init() {
    NOTIFY_OPERATION(init, init(), 0, _MonPkg__SysVehicule_init_SERIALIZE);
    //#[ operation init()
    speed=0;
    brakePedal=0;   
    accelPedal=0;
    float_speed=(double)speed;
    float_distance=(double)distance;
    
    const double MASSE                = (double)PARAM_SIMU_masse;
    const double PUISSANCE            = (double)PARAM_SIMU_puissance_moteur;
    const double AIR_DRAG             = PARAM_SIMU_frottement_air;
    const double VITESSE_REPOS        = (double)PARAM_SIMU_vitesse_repos;
    
    // Calcul du throttle de repos
    const double vit_repos_ms         = VITESSE_REPOS / 3.6;
    const double forceAir_repos       = AIR_DRAG * vit_repos_ms * vit_repos_ms;
    const double forceRoulement_repos = 0.015 * MASSE * 9.81;
    
    throttle_repos = (forceAir_repos + forceRoulement_repos) / PUISSANCE;
    throttle = throttle_repos;
    
    
    // Calcul des parametres du regulateur
    const double RATIO_CORRECTION_P   = PARAM_SIMU_Kp_regulateur;
    const double RATIO_LENTEUR_I      = PARAM_SIMU_Ki_regulateur;
    const double FREQ_REG             = (double)PARAM_SIMU_freq_regulateur;
    const double delta_v_par_throttle = (PUISSANCE / MASSE) * (1.0 / FREQ_REG) * 3.6;
    
    Kp_regulateur = RATIO_CORRECTION_P / delta_v_par_throttle;
    Ki_regulateur = (Kp_regulateur / RATIO_LENTEUR_I);
    //#]
}

_SysVehicule::~_SysVehicule() {
    NOTIFY_DESTRUCTOR(~_SysVehicule, true);
    cancelTimeouts();
}

bool _SysVehicule::get_simu() {
    return _simu;
}

void _SysVehicule::set_simu(bool p__simu) {
    _simu = p__simu;
}

double _SysVehicule::getAccelPedal() {
    return accelPedal;
}

void _SysVehicule::setAccelPedal(double p_accelPedal) {
    accelPedal = p_accelPedal;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getAlpha() {
    return alpha;
}

void _SysVehicule::setAlpha(int p_alpha) {
    alpha = p_alpha;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getBrakePedal() {
    return brakePedal;
}

void _SysVehicule::setBrakePedal(double p_brakePedal) {
    brakePedal = p_brakePedal;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getDistance() {
    return distance;
}

void _SysVehicule::setDistance(int p_distance) {
    distance = p_distance;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getIgnition() {
    return ignition;
}

int _SysVehicule::getSpeed() {
    return speed;
}

double _SysVehicule::getSteady() {
    return steady;
}

void _SysVehicule::setSteady(double p_steady) {
    steady = p_steady;
}

double _SysVehicule::getThrottle() {
    return throttle;
}

int _SysVehicule::getVitesseConsigne() {
    return vitesseConsigne;
}

void _SysVehicule::setVitesseConsigne(int p_vitesseConsigne) {
    vitesseConsigne = p_vitesseConsigne;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::startBehavior() {
    bool done = false;
    done = OMReactive::startBehavior();
    if(done)
        {
            startDispatching();
        }
    return done;
}

_SysVehicule::_SysVehicule(IOxfActive* theActiveContext) : Ki_regulateur(0.0), Kp_regulateur(0.0), PARAM_SIMU_Ki_regulateur(1.0), PARAM_SIMU_Kp_regulateur(1), PARAM_SIMU_freq_rafraichissement(20), PARAM_SIMU_freq_regulateur(2), PARAM_SIMU_frottement_air(10), PARAM_SIMU_masse(1500), PARAM_SIMU_max_accel(10), PARAM_SIMU_max_brake(10), PARAM_SIMU_max_speed(120), PARAM_SIMU_max_throttle(10.0), PARAM_SIMU_periode_pedales(200), PARAM_SIMU_puissance_frein(100), PARAM_SIMU_puissance_moteur(1700), PARAM_SIMU_vitesse_repos(10), SEUIL_batterie(40.0), SEUIL_carburant(5.0), VOYANT_bluetooth_vehicule(false), VOYANT_kit_appel(false), VOYANT_kit_connecte(false), VOYANT_kit_sms(false), VOYANT_kit_sonnerie(false), VOYANT_telephone_appairage(false), VOYANT_telephone_appel(false), VOYANT_telephone_connecte(false), VOYANT_telephone_sms(false), VOYANT_telephone_sonnerie(false), _simu(true), accelPedal(0.0), affichage_appairage("undefined"), affichage_liste_appareils("undefined"), affichage_titre_musique("undefined"), alpha(0), appel_en_cours_telephone(false), batterie_faible(false), brakePedal(0.0), carburant_faible(false), champ_mdp(""), chemin_sons("..\\..\\sons\\"), cmd_bluetooth_telephone_actif(false), cmd_charge_vehicule_telephone(false), cmd_contact(false), cmd_simulation_voiture_devant(false), distance(200000), distance_entiere_voiture_devant(0), distance_inter_voiture(0.0), distance_securite(30.0), distance_voiture_devant(0.0), float_distance(0.0), float_speed(0.0), ignition(false), kit_jumele(false), limiteur_attente(false), limiteur_depasse(false), mot_de_passe("1234"), nbr_sauvegarde_sms_telephone(0), nbr_sms_kit(0), nbr_sms_telephone(0), niveau_batterie(80.0), niveau_batterie_kit(0), niveau_batterie_telephone(50), reservoir_carburant(40.0), sonnerie_en_cours(false), speed(0), steady(0.0), telephone_allume(false), throttle(0.0), throttle_repos(0.0), valeur_initiale_limiteur(50), vitesseConsigne(0), vitesse_voiture_devant(0.0), voyant_limiteur(false), voyant_regulateur(false) {
    NOTIFY_ACTIVE_CONSTRUCTOR(_SysVehicule, _SysVehicule(), 0, _MonPkg__SysVehicule__SysVehicule_SERIALIZE);
    setActiveContext(this, true);
    initStatechart();
    //#[ operation _SysVehicule()
    speed=0;
    brakePedal=0;   
    accelPedal=0;
    float_speed=(double)speed;
    float_distance=(double)distance;
    distance_voiture_devant = distance;
    
    const double MASSE                = (double)PARAM_SIMU_masse;
    const double PUISSANCE            = (double)PARAM_SIMU_puissance_moteur;
    const double AIR_DRAG             = PARAM_SIMU_frottement_air;
    const double VITESSE_REPOS        = (double)PARAM_SIMU_vitesse_repos;
    
    // Calcul du throttle de repos
    const double vit_repos_ms         = VITESSE_REPOS / 3.6;
    const double forceAir_repos       = AIR_DRAG * vit_repos_ms * vit_repos_ms;
    const double forceRoulement_repos = 0.015 * MASSE * 9.81;
    
    throttle_repos = (forceAir_repos + forceRoulement_repos) / PUISSANCE;
    throttle = throttle_repos;
    
    
    // Calcul des parametres du regulateur
    const double RATIO_CORRECTION_P   = PARAM_SIMU_Kp_regulateur;
    const double RATIO_LENTEUR_I      = PARAM_SIMU_Ki_regulateur;
    const double FREQ_REG             = (double)PARAM_SIMU_freq_regulateur;
    const double delta_v_par_throttle = (PUISSANCE / MASSE) * (1.0 / FREQ_REG) * 3.6;
    
    Kp_regulateur = RATIO_CORRECTION_P / delta_v_par_throttle;
    Ki_regulateur = (Kp_regulateur / RATIO_LENTEUR_I);
    
    liste_appareils_detectes[0] = "";
    liste_appareils_detectes[1] = "Kit Bluetooth Vehicule";
    
    messages_appairage[0] = "Aucun appareil d�tect�";
    messages_appairage[1] = "S�lectioner un appareil";
    messages_appairage[2] = "Entrez un mot de passe";
    messages_appairage[3] = "Mot de passe incorrect";
    messages_appairage[4] = "Appareil jumel�";
    messages_appairage[5] = "Jumelage Impossible";
    //#]
}

void _SysVehicule::Operation_215() {
    NOTIFY_OPERATION(Operation_215, Operation_215(), 0, _MonPkg__SysVehicule_Operation_215_SERIALIZE);
    //#[ operation Operation_215()
    //#]
}

void _SysVehicule::VOYANT_kit(bool etat) {
    NOTIFY_OPERATION(VOYANT_kit, VOYANT_kit(bool), 1, _MonPkg__SysVehicule_VOYANT_kit_SERIALIZE);
    //#[ operation VOYANT_kit(bool)
    VOYANT_kit_sms=false;
    VOYANT_kit_appel=false;
    VOYANT_kit_sonnerie=false;
    //#]
}

void _SysVehicule::affichage_batterie_telephone_vehicule() {
    NOTIFY_OPERATION(affichage_batterie_telephone_vehicule, affichage_batterie_telephone_vehicule(), 0, _MonPkg__SysVehicule_affichage_batterie_telephone_vehicule_SERIALIZE);
    //#[ operation affichage_batterie_telephone_vehicule()
    //#]
}

void _SysVehicule::alerte_depassement(int actif) {
    NOTIFY_OPERATION(alerte_depassement, alerte_depassement(int), 1, _MonPkg__SysVehicule_alerte_depassement_SERIALIZE);
    //#[ operation alerte_depassement(int)
    if (actif == 0) {
    	play_sound("stop");
    	limiteur_depasse = false;
    } else {
    	play_sound("alarme_depassement.wav");
    	limiteur_depasse = true;
    }
    //#]
}

void _SysVehicule::calcul_batterie() {
    NOTIFY_OPERATION(calcul_batterie, calcul_batterie(), 0, _MonPkg__SysVehicule_calcul_batterie_SERIALIZE);
    //#[ operation calcul_batterie()
    // --- PARAMETRES ET CONSTANTES ---
    const int deltaTms                    = 1000 / PARAM_SIMU_freq_rafraichissement; // Division enti�re en ms
    const double dt                       = (double)deltaTms / 1000.0;               // En secondes pour la physique
    
    // Seuils d'injection
    const double SEUIL_THROTTLE_MIN       = 1.5;
    const double SEUIL_THROTTLE_MAX       = 5.0;
    
    // Taux de charge et d�charge physiques (% par seconde)
    const double TAUX_CHARGE_PAR_THROTTLE = 0.5;
    const double TAUX_CHARGE_MAX_SEC      = TAUX_CHARGE_PAR_THROTTLE * SEUIL_THROTTLE_MAX;
    const double TAUX_DECHARGE_SEC        = 0.25;
    
    // --- LOGIQUE ---
    double new_niveau_batterie = niveau_batterie;
    
    if (throttle > SEUIL_THROTTLE_MIN) {
        const double taux_charge = (throttle < SEUIL_THROTTLE_MAX)
                                   ? (TAUX_CHARGE_PAR_THROTTLE * throttle)
                                   : TAUX_CHARGE_MAX_SEC;
    
        new_niveau_batterie += taux_charge * dt;
        if (new_niveau_batterie > 100.0) {
            new_niveau_batterie = 100.0;
        }
    } else {
        new_niveau_batterie -= TAUX_DECHARGE_SEC * dt;
        if (new_niveau_batterie < 0.0) {
            new_niveau_batterie = 0.0;
        }
    }
    
    niveau_batterie = new_niveau_batterie;
    //#]
}

void _SysVehicule::calcul_carburant() {
    NOTIFY_OPERATION(calcul_carburant, calcul_carburant(), 0, _MonPkg__SysVehicule_calcul_carburant_SERIALIZE);
    //#[ operation calcul_carburant()
    const double COEF_CONSO = 0.005;
    
    double new_reservoir_carburant = reservoir_carburant;
    
    new_reservoir_carburant -= throttle*COEF_CONSO;
    
    if (new_reservoir_carburant < 0.0) {
    	new_reservoir_carburant = 0;
    } 
    
    reservoir_carburant = new_reservoir_carburant;
    //#]
}

void _SysVehicule::calcul_distance_voiture_devant() {
    NOTIFY_OPERATION(calcul_distance_voiture_devant, calcul_distance_voiture_devant(), 0, _MonPkg__SysVehicule_calcul_distance_voiture_devant_SERIALIZE);
    //#[ operation calcul_distance_voiture_devant()
    const double DELTA_T_MS            = (double)(1000/PARAM_SIMU_freq_rafraichissement);
    const double CST_CONVERSION_KMH_MS = 3.6;
    const double CST_CONVERSION_MS_S   = 1000.0;
    const double dt                    = DELTA_T_MS / CST_CONVERSION_MS_S;
    
    distance_voiture_devant += (vitesse_voiture_devant / CST_CONVERSION_KMH_MS) * dt;
    distance_entiere_voiture_devant = (int)distance_voiture_devant;
    //#]
}

void _SysVehicule::calcul_regulateur_distance() {
    NOTIFY_OPERATION(calcul_regulateur_distance, calcul_regulateur_distance(), 0, _MonPkg__SysVehicule_calcul_regulateur_distance_SERIALIZE);
    //#[ operation calcul_regulateur_distance()
    // Calcul de l'erreur de distance � partir de
    // la distance inter voture
    // et de la distance de securite
    const double erreur = (double)distance_inter_voiture - (double)distance_securite;
    
    steady += Ki_regulateur * erreur;
    
    if (steady > PARAM_SIMU_max_throttle) steady = PARAM_SIMU_max_throttle;
    if (steady < throttle_repos)          steady = throttle_repos;
    
    double commande = steady + (Kp_regulateur * erreur);
    
    if (commande > PARAM_SIMU_max_throttle) commande = PARAM_SIMU_max_throttle;
    if (commande < throttle_repos)          commande = throttle_repos;
    
    throttle = commande;
    //#]
}

void _SysVehicule::calcul_regulateur_vitesse() {
    NOTIFY_OPERATION(calcul_regulateur_vitesse, calcul_regulateur_vitesse(), 0, _MonPkg__SysVehicule_calcul_regulateur_vitesse_SERIALIZE);
    //#[ operation calcul_regulateur_vitesse()
    const double erreur = (double)vitesseConsigne+0.5 - (double)float_speed;
    
    steady += Ki_regulateur * erreur;
    
    if (steady > PARAM_SIMU_max_throttle) steady = PARAM_SIMU_max_throttle;
    if (steady < throttle_repos)          steady = throttle_repos;
    
    double commande = steady + (Kp_regulateur * erreur);
    
    if (commande > PARAM_SIMU_max_throttle) commande = PARAM_SIMU_max_throttle;
    if (commande < throttle_repos)          commande = throttle_repos;
    
    throttle = commande;
    //#]
}

void _SysVehicule::charge_telephone() {
    NOTIFY_OPERATION(charge_telephone, charge_telephone(), 0, _MonPkg__SysVehicule_charge_telephone_SERIALIZE);
    //#[ operation charge_telephone()
    int new_niveau_batterie = niveau_batterie_telephone; 
    if (new_niveau_batterie < 96){
    	new_niveau_batterie += 5;
    	}
    else{
    	new_niveau_batterie= 100;
    	}
    niveau_batterie_telephone=new_niveau_batterie;
    //#]
}

void _SysVehicule::decharge_telephone() {
    NOTIFY_OPERATION(decharge_telephone, decharge_telephone(), 0, _MonPkg__SysVehicule_decharge_telephone_SERIALIZE);
    //#[ operation decharge_telephone()
    int new_niveau_batterie = niveau_batterie_telephone; 
    if (new_niveau_batterie > 0){
    	new_niveau_batterie -= 1;
    	}
    else{
    	new_niveau_batterie=0;
    	}
    niveau_batterie_telephone=new_niveau_batterie;
    //#]
}

const void _SysVehicule::envoi_batterie_kit(int batterie_telephone) {
    NOTIFY_OPERATION(envoi_batterie_kit, envoi_batterie_kit(int), 1, _MonPkg__SysVehicule_envoi_batterie_kit_SERIALIZE);
    //#[ operation envoi_batterie_kit(int)
    niveau_batterie_kit = batterie_telephone;
    //#]
}

void _SysVehicule::eteindre_telephone() {
    NOTIFY_OPERATION(eteindre_telephone, eteindre_telephone(), 0, _MonPkg__SysVehicule_eteindre_telephone_SERIALIZE);
    //#[ operation eteindre_telephone()
    nbr_sms_telephone = 0;
    VOYANT_telephone_sms = false;
    VOYANT_telephone_appel = false;
    VOYANT_telephone_sonnerie=false;
    appel_en_cours_telephone=false;
    //#]
}

void _SysVehicule::ex_actualisation_sms_telephone(int incrementation) {
    NOTIFY_OPERATION(ex_actualisation_sms_telephone, ex_actualisation_sms_telephone(int), 1, _MonPkg__SysVehicule_ex_actualisation_sms_telephone_SERIALIZE);
    //#[ operation ex_actualisation_sms_telephone(int)
    int historique_sms=nbr_sms_telephone;
    historique_sms+=incrementation;
    if (historique_sms < 0){
    	historique_sms=0;
    	}
    nbr_sms_telephone=historique_sms;
    //#]
}

void _SysVehicule::ex_depanner_batterie() {
    NOTIFY_OPERATION(ex_depanner_batterie, ex_depanner_batterie(), 0, _MonPkg__SysVehicule_ex_depanner_batterie_SERIALIZE);
    //#[ operation ex_depanner_batterie()
    if (niveau_batterie < SEUIL_batterie) {
    	niveau_batterie = SEUIL_batterie+15;
    }
    if (niveau_batterie > 100) {
    	niveau_batterie = 100;
    }
    //#]
}

void _SysVehicule::ex_jumeler() {
    NOTIFY_OPERATION(ex_jumeler, ex_jumeler(), 0, _MonPkg__SysVehicule_ex_jumeler_SERIALIZE);
    //#[ operation ex_jumeler()
    //#]
}

void _SysVehicule::ex_ok() {
    NOTIFY_OPERATION(ex_ok, ex_ok(), 0, _MonPkg__SysVehicule_ex_ok_SERIALIZE);
    //#[ operation ex_ok()
    //#]
}

void _SysVehicule::ex_remplir_carburant() {
    NOTIFY_OPERATION(ex_remplir_carburant, ex_remplir_carburant(), 0, _MonPkg__SysVehicule_ex_remplir_carburant_SERIALIZE);
    //#[ operation ex_remplir_carburant()
    double new_reservoir_carburant = reservoir_carburant;
    
    new_reservoir_carburant += 5;
    
    if (new_reservoir_carburant > 50.0) {
    	new_reservoir_carburant = 50;
    } 
    
    reservoir_carburant = new_reservoir_carburant;
    //#]
}

void _SysVehicule::ex_vitesseConsigne(int delta) {
    NOTIFY_OPERATION(ex_vitesseConsigne, ex_vitesseConsigne(int), 1, _MonPkg__SysVehicule_ex_vitesseConsigne_SERIALIZE);
    //#[ operation ex_vitesseConsigne(int)
    vitesseConsigne += delta;
    
    if (vitesseConsigne > PARAM_SIMU_max_speed) {
    	vitesseConsigne = PARAM_SIMU_max_speed;
    }
    if (vitesseConsigne < 0) {
    	vitesseConsigne = 0;
    }
    //#]
}

void _SysVehicule::play_sound(const OMString& fichier) {
    NOTIFY_OPERATION(play_sound, play_sound(const OMString&), 1, _MonPkg__SysVehicule_play_sound_SERIALIZE);
    //#[ operation play_sound(OMString)
    if (fichier =="stop")
    {
    	PlaySound(NULL, NULL, 0);
    	}
    else
    {
    OMString chemin = chemin_sons;
    chemin += fichier;
    
    PlaySound(TEXT(chemin.GetBuffer(0)), NULL, SND_LOOP | SND_ASYNC);
    }
    //#]
}

void _SysVehicule::regulateur_Prof() {
    NOTIFY_OPERATION(regulateur_Prof, regulateur_Prof(), 0, _MonPkg__SysVehicule_regulateur_Prof_SERIALIZE);
    //#[ operation regulateur_Prof()
    const double erreur = (double)(vitesseConsigne)+0.5 - float_speed;
    
    const double K_cube = PARAM_SIMU_Kp_regulateur;
    throttle += K_cube * erreur;
    
    if (throttle > PARAM_SIMU_max_throttle) throttle = PARAM_SIMU_max_throttle;
    if (throttle < throttle_repos)          throttle = throttle_repos;
    //#]
}

boolean _SysVehicule::verifier_mdp(const OMString& mdp) {
    NOTIFY_OPERATION(verifier_mdp, verifier_mdp(const OMString&), 1, _MonPkg__SysVehicule_verifier_mdp_SERIALIZE);
    //#[ operation verifier_mdp(OMString)
    bool mot_de_passe_correct = (mdp == mot_de_passe);
    champ_mdp = "";
    if (mot_de_passe_correct)
    {
    	return true;
    }
    else 
    {
    	return false;
    } 
    //#]
}

double _SysVehicule::getKi_regulateur() {
    return Ki_regulateur;
}

void _SysVehicule::setKi_regulateur(double p_Ki_regulateur) {
    Ki_regulateur = p_Ki_regulateur;
}

double _SysVehicule::getKp_regulateur() {
    return Kp_regulateur;
}

void _SysVehicule::setKp_regulateur(double p_Kp_regulateur) {
    Kp_regulateur = p_Kp_regulateur;
}

double _SysVehicule::getPARAM_SIMU_Ki_regulateur() {
    return PARAM_SIMU_Ki_regulateur;
}

void _SysVehicule::setPARAM_SIMU_Ki_regulateur(double p_PARAM_SIMU_Ki_regulateur) {
    PARAM_SIMU_Ki_regulateur = p_PARAM_SIMU_Ki_regulateur;
}

double _SysVehicule::getPARAM_SIMU_Kp_regulateur() {
    return PARAM_SIMU_Kp_regulateur;
}

void _SysVehicule::setPARAM_SIMU_Kp_regulateur(double p_PARAM_SIMU_Kp_regulateur) {
    PARAM_SIMU_Kp_regulateur = p_PARAM_SIMU_Kp_regulateur;
}

int _SysVehicule::getPARAM_SIMU_freq_rafraichissement() {
    return PARAM_SIMU_freq_rafraichissement;
}

void _SysVehicule::setPARAM_SIMU_freq_rafraichissement(int p_PARAM_SIMU_freq_rafraichissement) {
    PARAM_SIMU_freq_rafraichissement = p_PARAM_SIMU_freq_rafraichissement;
}

int _SysVehicule::getPARAM_SIMU_freq_regulateur() {
    return PARAM_SIMU_freq_regulateur;
}

void _SysVehicule::setPARAM_SIMU_freq_regulateur(int p_PARAM_SIMU_freq_regulateur) {
    PARAM_SIMU_freq_regulateur = p_PARAM_SIMU_freq_regulateur;
}

double _SysVehicule::getPARAM_SIMU_frottement_air() {
    return PARAM_SIMU_frottement_air;
}

void _SysVehicule::setPARAM_SIMU_frottement_air(double p_PARAM_SIMU_frottement_air) {
    PARAM_SIMU_frottement_air = p_PARAM_SIMU_frottement_air;
}

int _SysVehicule::getPARAM_SIMU_masse() {
    return PARAM_SIMU_masse;
}

void _SysVehicule::setPARAM_SIMU_masse(int p_PARAM_SIMU_masse) {
    PARAM_SIMU_masse = p_PARAM_SIMU_masse;
}

int _SysVehicule::getPARAM_SIMU_max_accel() {
    return PARAM_SIMU_max_accel;
}

void _SysVehicule::setPARAM_SIMU_max_accel(int p_PARAM_SIMU_max_accel) {
    PARAM_SIMU_max_accel = p_PARAM_SIMU_max_accel;
}

int _SysVehicule::getPARAM_SIMU_max_brake() {
    return PARAM_SIMU_max_brake;
}

void _SysVehicule::setPARAM_SIMU_max_brake(int p_PARAM_SIMU_max_brake) {
    PARAM_SIMU_max_brake = p_PARAM_SIMU_max_brake;
}

int _SysVehicule::getPARAM_SIMU_max_speed() {
    return PARAM_SIMU_max_speed;
}

void _SysVehicule::setPARAM_SIMU_max_speed(int p_PARAM_SIMU_max_speed) {
    PARAM_SIMU_max_speed = p_PARAM_SIMU_max_speed;
}

double _SysVehicule::getPARAM_SIMU_max_throttle() {
    return PARAM_SIMU_max_throttle;
}

void _SysVehicule::setPARAM_SIMU_max_throttle(double p_PARAM_SIMU_max_throttle) {
    PARAM_SIMU_max_throttle = p_PARAM_SIMU_max_throttle;
}

int _SysVehicule::getPARAM_SIMU_periode_pedales() {
    return PARAM_SIMU_periode_pedales;
}

void _SysVehicule::setPARAM_SIMU_periode_pedales(int p_PARAM_SIMU_periode_pedales) {
    PARAM_SIMU_periode_pedales = p_PARAM_SIMU_periode_pedales;
}

int _SysVehicule::getPARAM_SIMU_puissance_frein() {
    return PARAM_SIMU_puissance_frein;
}

void _SysVehicule::setPARAM_SIMU_puissance_frein(int p_PARAM_SIMU_puissance_frein) {
    PARAM_SIMU_puissance_frein = p_PARAM_SIMU_puissance_frein;
}

int _SysVehicule::getPARAM_SIMU_puissance_moteur() {
    return PARAM_SIMU_puissance_moteur;
}

void _SysVehicule::setPARAM_SIMU_puissance_moteur(int p_PARAM_SIMU_puissance_moteur) {
    PARAM_SIMU_puissance_moteur = p_PARAM_SIMU_puissance_moteur;
}

int _SysVehicule::getPARAM_SIMU_vitesse_repos() {
    return PARAM_SIMU_vitesse_repos;
}

void _SysVehicule::setPARAM_SIMU_vitesse_repos(int p_PARAM_SIMU_vitesse_repos) {
    PARAM_SIMU_vitesse_repos = p_PARAM_SIMU_vitesse_repos;
}

double _SysVehicule::getSEUIL_batterie() {
    return SEUIL_batterie;
}

void _SysVehicule::setSEUIL_batterie(double p_SEUIL_batterie) {
    SEUIL_batterie = p_SEUIL_batterie;
}

double _SysVehicule::getSEUIL_carburant() {
    return SEUIL_carburant;
}

void _SysVehicule::setSEUIL_carburant(double p_SEUIL_carburant) {
    SEUIL_carburant = p_SEUIL_carburant;
}

bool _SysVehicule::getVOYANT_bluetooth_vehicule() {
    return VOYANT_bluetooth_vehicule;
}

void _SysVehicule::setVOYANT_bluetooth_vehicule(bool p_VOYANT_bluetooth_vehicule) {
    VOYANT_bluetooth_vehicule = p_VOYANT_bluetooth_vehicule;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_kit_appel() {
    return VOYANT_kit_appel;
}

void _SysVehicule::setVOYANT_kit_appel(bool p_VOYANT_kit_appel) {
    VOYANT_kit_appel = p_VOYANT_kit_appel;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_kit_connecte() {
    return VOYANT_kit_connecte;
}

void _SysVehicule::setVOYANT_kit_connecte(bool p_VOYANT_kit_connecte) {
    VOYANT_kit_connecte = p_VOYANT_kit_connecte;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_kit_sms() {
    return VOYANT_kit_sms;
}

void _SysVehicule::setVOYANT_kit_sms(bool p_VOYANT_kit_sms) {
    VOYANT_kit_sms = p_VOYANT_kit_sms;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_kit_sonnerie() {
    return VOYANT_kit_sonnerie;
}

void _SysVehicule::setVOYANT_kit_sonnerie(bool p_VOYANT_kit_sonnerie) {
    VOYANT_kit_sonnerie = p_VOYANT_kit_sonnerie;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_radio() {
    return VOYANT_radio;
}

void _SysVehicule::setVOYANT_radio(bool p_VOYANT_radio) {
    VOYANT_radio = p_VOYANT_radio;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_appairage() {
    return VOYANT_telephone_appairage;
}

void _SysVehicule::setVOYANT_telephone_appairage(bool p_VOYANT_telephone_appairage) {
    VOYANT_telephone_appairage = p_VOYANT_telephone_appairage;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_appel() {
    return VOYANT_telephone_appel;
}

void _SysVehicule::setVOYANT_telephone_appel(bool p_VOYANT_telephone_appel) {
    VOYANT_telephone_appel = p_VOYANT_telephone_appel;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_connecte() {
    return VOYANT_telephone_connecte;
}

void _SysVehicule::setVOYANT_telephone_connecte(bool p_VOYANT_telephone_connecte) {
    VOYANT_telephone_connecte = p_VOYANT_telephone_connecte;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_sms() {
    return VOYANT_telephone_sms;
}

void _SysVehicule::setVOYANT_telephone_sms(bool p_VOYANT_telephone_sms) {
    VOYANT_telephone_sms = p_VOYANT_telephone_sms;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_sonnerie() {
    return VOYANT_telephone_sonnerie;
}

void _SysVehicule::setVOYANT_telephone_sonnerie(bool p_VOYANT_telephone_sonnerie) {
    VOYANT_telephone_sonnerie = p_VOYANT_telephone_sonnerie;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getAffichage_appairage() {
    return affichage_appairage;
}

void _SysVehicule::setAffichage_appairage(OMString p_affichage_appairage) {
    affichage_appairage = p_affichage_appairage;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getAffichage_liste_appareils() {
    return affichage_liste_appareils;
}

void _SysVehicule::setAffichage_liste_appareils(OMString p_affichage_liste_appareils) {
    affichage_liste_appareils = p_affichage_liste_appareils;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getAffichage_titre_musique() {
    return affichage_titre_musique;
}

void _SysVehicule::setAffichage_titre_musique(OMString p_affichage_titre_musique) {
    affichage_titre_musique = p_affichage_titre_musique;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getAppel_en_cours_telephone() {
    return appel_en_cours_telephone;
}

void _SysVehicule::setAppel_en_cours_telephone(bool p_appel_en_cours_telephone) {
    appel_en_cours_telephone = p_appel_en_cours_telephone;
}

bool _SysVehicule::getBatterie_faible() {
    return batterie_faible;
}

void _SysVehicule::setBatterie_faible(bool p_batterie_faible) {
    batterie_faible = p_batterie_faible;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCarburant_faible() {
    return carburant_faible;
}

void _SysVehicule::setCarburant_faible(bool p_carburant_faible) {
    carburant_faible = p_carburant_faible;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getChamp_mdp() {
    return champ_mdp;
}

void _SysVehicule::setChamp_mdp(OMString p_champ_mdp) {
    champ_mdp = p_champ_mdp;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getChemin_sons() {
    return chemin_sons;
}

void _SysVehicule::setChemin_sons(OMString p_chemin_sons) {
    chemin_sons = p_chemin_sons;
}

bool _SysVehicule::getCmd_bluetooth_telephone_actif() {
    return cmd_bluetooth_telephone_actif;
}

void _SysVehicule::setCmd_bluetooth_telephone_actif(bool p_cmd_bluetooth_telephone_actif) {
    cmd_bluetooth_telephone_actif = p_cmd_bluetooth_telephone_actif;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCmd_charge_vehicule_telephone() {
    return cmd_charge_vehicule_telephone;
}

void _SysVehicule::setCmd_charge_vehicule_telephone(bool p_cmd_charge_vehicule_telephone) {
    cmd_charge_vehicule_telephone = p_cmd_charge_vehicule_telephone;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCmd_contact() {
    return cmd_contact;
}

void _SysVehicule::setCmd_contact(bool p_cmd_contact) {
    cmd_contact = p_cmd_contact;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCmd_radio() {
    return cmd_radio;
}

void _SysVehicule::setCmd_radio(bool p_cmd_radio) {
    cmd_radio = p_cmd_radio;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCmd_simulation_voiture_devant() {
    return cmd_simulation_voiture_devant;
}

void _SysVehicule::setCmd_simulation_voiture_devant(bool p_cmd_simulation_voiture_devant) {
    cmd_simulation_voiture_devant = p_cmd_simulation_voiture_devant;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getDistance_entiere_voiture_devant() {
    return distance_entiere_voiture_devant;
}

void _SysVehicule::setDistance_entiere_voiture_devant(int p_distance_entiere_voiture_devant) {
    distance_entiere_voiture_devant = p_distance_entiere_voiture_devant;
}

double _SysVehicule::getDistance_inter_voiture() {
    return distance_inter_voiture;
}

void _SysVehicule::setDistance_inter_voiture(double p_distance_inter_voiture) {
    distance_inter_voiture = p_distance_inter_voiture;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getDistance_securite() {
    return distance_securite;
}

void _SysVehicule::setDistance_securite(double p_distance_securite) {
    distance_securite = p_distance_securite;
}

double _SysVehicule::getDistance_voiture_devant() {
    return distance_voiture_devant;
}

void _SysVehicule::setDistance_voiture_devant(double p_distance_voiture_devant) {
    distance_voiture_devant = p_distance_voiture_devant;
}

double _SysVehicule::getFloat_distance() {
    return float_distance;
}

void _SysVehicule::setFloat_distance(double p_float_distance) {
    float_distance = p_float_distance;
}

double _SysVehicule::getFloat_speed() {
    return float_speed;
}

void _SysVehicule::setFloat_speed(double p_float_speed) {
    float_speed = p_float_speed;
}

void _SysVehicule::setIgnition(bool p_ignition) {
    ignition = p_ignition;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getKit_jumele() {
    return kit_jumele;
}

void _SysVehicule::setKit_jumele(bool p_kit_jumele) {
    kit_jumele = p_kit_jumele;
}

bool _SysVehicule::getLimiteur_attente() {
    return limiteur_attente;
}

void _SysVehicule::setLimiteur_attente(bool p_limiteur_attente) {
    limiteur_attente = p_limiteur_attente;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getLimiteur_depasse() {
    return limiteur_depasse;
}

void _SysVehicule::setLimiteur_depasse(bool p_limiteur_depasse) {
    limiteur_depasse = p_limiteur_depasse;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getListe_appareils_detectes(int i1) {
    return liste_appareils_detectes[i1];
}

void _SysVehicule::setListe_appareils_detectes(int i1, OMString p_liste_appareils_detectes) {
    liste_appareils_detectes[i1] = p_liste_appareils_detectes;
}

OMString _SysVehicule::getMessages_appairage(int i1) {
    return messages_appairage[i1];
}

void _SysVehicule::setMessages_appairage(int i1, OMString p_messages_appairage) {
    messages_appairage[i1] = p_messages_appairage;
}

OMString _SysVehicule::getMot_de_passe() {
    return mot_de_passe;
}

void _SysVehicule::setMot_de_passe(OMString p_mot_de_passe) {
    mot_de_passe = p_mot_de_passe;
}

int _SysVehicule::getNbr_sauvegarde_sms_telephone() {
    return nbr_sauvegarde_sms_telephone;
}

void _SysVehicule::setNbr_sauvegarde_sms_telephone(int p_nbr_sauvegarde_sms_telephone) {
    nbr_sauvegarde_sms_telephone = p_nbr_sauvegarde_sms_telephone;
}

int _SysVehicule::getNbr_sms_kit() {
    return nbr_sms_kit;
}

void _SysVehicule::setNbr_sms_kit(int p_nbr_sms_kit) {
    nbr_sms_kit = p_nbr_sms_kit;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getNbr_sms_telephone() {
    return nbr_sms_telephone;
}

void _SysVehicule::setNbr_sms_telephone(int p_nbr_sms_telephone) {
    nbr_sms_telephone = p_nbr_sms_telephone;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getNiveau_batterie() {
    return niveau_batterie;
}

void _SysVehicule::setNiveau_batterie(double p_niveau_batterie) {
    niveau_batterie = p_niveau_batterie;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getNiveau_batterie_kit() {
    return niveau_batterie_kit;
}

void _SysVehicule::setNiveau_batterie_kit(int p_niveau_batterie_kit) {
    niveau_batterie_kit = p_niveau_batterie_kit;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getNiveau_batterie_telephone() {
    return niveau_batterie_telephone;
}

void _SysVehicule::setNiveau_batterie_telephone(int p_niveau_batterie_telephone) {
    niveau_batterie_telephone = p_niveau_batterie_telephone;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getReservoir_carburant() {
    return reservoir_carburant;
}

void _SysVehicule::setReservoir_carburant(double p_reservoir_carburant) {
    reservoir_carburant = p_reservoir_carburant;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getSonnerie_en_cours() {
    return sonnerie_en_cours;
}

void _SysVehicule::setSonnerie_en_cours(bool p_sonnerie_en_cours) {
    sonnerie_en_cours = p_sonnerie_en_cours;
}

void _SysVehicule::setSpeed(int p_speed) {
    speed = p_speed;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getTelephone_allume() {
    return telephone_allume;
}

void _SysVehicule::setTelephone_allume(bool p_telephone_allume) {
    telephone_allume = p_telephone_allume;
    NOTIFY_SET_OPERATION;
}

void _SysVehicule::setThrottle(double p_throttle) {
    throttle = p_throttle;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getThrottle_repos() {
    return throttle_repos;
}

void _SysVehicule::setThrottle_repos(double p_throttle_repos) {
    throttle_repos = p_throttle_repos;
}

int _SysVehicule::getValeur_initiale_limiteur() {
    return valeur_initiale_limiteur;
}

void _SysVehicule::setValeur_initiale_limiteur(int p_valeur_initiale_limiteur) {
    valeur_initiale_limiteur = p_valeur_initiale_limiteur;
}

double _SysVehicule::getVitesse_voiture_devant() {
    return vitesse_voiture_devant;
}

void _SysVehicule::setVitesse_voiture_devant(double p_vitesse_voiture_devant) {
    vitesse_voiture_devant = p_vitesse_voiture_devant;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVoyant_limiteur() {
    return voyant_limiteur;
}

void _SysVehicule::setVoyant_limiteur(bool p_voyant_limiteur) {
    voyant_limiteur = p_voyant_limiteur;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVoyant_regulateur() {
    return voyant_regulateur;
}

void _SysVehicule::setVoyant_regulateur(bool p_voyant_regulateur) {
    voyant_regulateur = p_voyant_regulateur;
    NOTIFY_SET_OPERATION;
}

void _SysVehicule::initStatechart() {
    rootState_subState = OMNonState;
    rootState_active = OMNonState;
    state_96_subState = OMNonState;
    state_96_active = OMNonState;
    telephone_actif_subState = OMNonState;
    bluetooth_telephone_active_subState = OMNonState;
    jumelage_subState = OMNonState;
    jumelage_timeout = NULL;
    bluetooth_telephone_active_timeout = NULL;
    state_87_subState = OMNonState;
    state_87_active = OMNonState;
    state_87_timeout = NULL;
    bluetooth_active_subState = OMNonState;
    bluetooth_active_timeout = NULL;
    operation_jumelage_subState = OMNonState;
    state_76_subState = OMNonState;
    state_76_active = OMNonState;
    limiteur_on_subState = OMNonState;
    limiteur_on_timeout = NULL;
    consigne_fixe_subState = OMNonState;
    limiteur_effectif_subState = OMNonState;
    state_72_subState = OMNonState;
    state_72_active = OMNonState;
    state_71_subState = OMNonState;
    state_71_active = OMNonState;
    mode_regulateur_subState = OMNonState;
    state_62_subState = OMNonState;
    state_62_active = OMNonState;
    state_62_timeout = NULL;
    state_61_subState = OMNonState;
    state_61_active = OMNonState;
    state_267_subState = OMNonState;
    state_267_active = OMNonState;
    state_267_timeout = NULL;
    state_266_subState = OMNonState;
    state_266_active = OMNonState;
    state_60_subState = OMNonState;
    state_60_active = OMNonState;
    regulateur_subState = OMNonState;
    state_60_timeout = NULL;
    pedales_subState = OMNonState;
    pedales_timeout = NULL;
    state_278_subState = OMNonState;
    state_278_active = OMNonState;
    contact_radio_actif_subState = OMNonState;
    state_260_subState = OMNonState;
    state_260_active = OMNonState;
    state_260_timeout = NULL;
    state_233_subState = OMNonState;
    state_233_active = OMNonState;
    radio_active_subState = OMNonState;
    radio_active_lastState = OMNonState;
    radio_active_timeout = NULL;
    state_275_subState = OMNonState;
    state_275_active = OMNonState;
    simulation_voiture_devant_subState = OMNonState;
    state_252_subState = OMNonState;
    state_252_active = OMNonState;
    state_206_subState = OMNonState;
    state_206_active = OMNonState;
    state_166_subState = OMNonState;
    state_166_active = OMNonState;
    state_204_subState = OMNonState;
    state_204_active = OMNonState;
    state_199_subState = OMNonState;
    state_199_active = OMNonState;
    state_198_subState = OMNonState;
    state_198_active = OMNonState;
    state_174_subState = OMNonState;
    state_174_active = OMNonState;
    state_173_subState = OMNonState;
    state_173_active = OMNonState;
    state_131_subState = OMNonState;
    state_131_active = OMNonState;
    gestion_sonnerie_kit_state_240_subState = OMNonState;
    gestion_sonnerie_kit_state_240_active = OMNonState;
    gestion_sonnerie_kit_gestion_sonnerie_kit_subState = OMNonState;
    gestion_sonnerie_kit_gestion_sonnerie_kit_active = OMNonState;
    state_130_subState = OMNonState;
    state_130_active = OMNonState;
    state_146_subState = OMNonState;
    state_146_active = OMNonState;
    tentative_appel_subState = OMNonState;
    state_146_timeout = NULL;
    tentative_appel_timeout = NULL;
    state_139_subState = OMNonState;
    state_139_active = OMNonState;
    gestion_communication_subState = OMNonState;
    state_262_subState = OMNonState;
    state_262_active = OMNonState;
    state_189_subState = OMNonState;
    state_189_active = OMNonState;
    state_189_timeout = NULL;
    state_188_subState = OMNonState;
    state_188_active = OMNonState;
    state_243_subState = OMNonState;
    state_243_active = OMNonState;
    state_243_timeout = NULL;
    state_242_subState = OMNonState;
    state_242_active = OMNonState;
    state_242_timeout = NULL;
    state_184_subState = OMNonState;
    state_184_active = OMNonState;
    state_184_timeout = NULL;
    state_183_subState = OMNonState;
    state_183_active = OMNonState;
    state_240_subState = OMNonState;
    state_240_active = OMNonState;
    state_240_timeout = NULL;
    state_239_subState = OMNonState;
    state_239_active = OMNonState;
    state_239_timeout = NULL;
    arret_de_communication_subState = OMNonState;
    state_126_subState = OMNonState;
    state_126_active = OMNonState;
    state_126_timeout = NULL;
}

void _SysVehicule::cancelTimeouts() {
    cancel(jumelage_timeout);
    cancel(bluetooth_telephone_active_timeout);
    cancel(state_87_timeout);
    cancel(bluetooth_active_timeout);
    cancel(limiteur_on_timeout);
    cancel(state_62_timeout);
    cancel(state_267_timeout);
    cancel(state_60_timeout);
    cancel(pedales_timeout);
    cancel(state_260_timeout);
    cancel(radio_active_timeout);
    cancel(state_146_timeout);
    cancel(tentative_appel_timeout);
    cancel(state_189_timeout);
    cancel(state_243_timeout);
    cancel(state_242_timeout);
    cancel(state_184_timeout);
    cancel(state_240_timeout);
    cancel(state_239_timeout);
    cancel(state_126_timeout);
}

bool _SysVehicule::cancelTimeout(const IOxfTimeout* arg) {
    bool res = false;
    if(jumelage_timeout == arg)
        {
            jumelage_timeout = NULL;
            res = true;
        }
    if(bluetooth_telephone_active_timeout == arg)
        {
            bluetooth_telephone_active_timeout = NULL;
            res = true;
        }
    if(state_87_timeout == arg)
        {
            state_87_timeout = NULL;
            res = true;
        }
    if(bluetooth_active_timeout == arg)
        {
            bluetooth_active_timeout = NULL;
            res = true;
        }
    if(limiteur_on_timeout == arg)
        {
            limiteur_on_timeout = NULL;
            res = true;
        }
    if(state_62_timeout == arg)
        {
            state_62_timeout = NULL;
            res = true;
        }
    if(state_267_timeout == arg)
        {
            state_267_timeout = NULL;
            res = true;
        }
    if(state_60_timeout == arg)
        {
            state_60_timeout = NULL;
            res = true;
        }
    if(pedales_timeout == arg)
        {
            pedales_timeout = NULL;
            res = true;
        }
    if(state_260_timeout == arg)
        {
            state_260_timeout = NULL;
            res = true;
        }
    if(radio_active_timeout == arg)
        {
            radio_active_timeout = NULL;
            res = true;
        }
    if(state_146_timeout == arg)
        {
            state_146_timeout = NULL;
            res = true;
        }
    if(tentative_appel_timeout == arg)
        {
            tentative_appel_timeout = NULL;
            res = true;
        }
    if(state_189_timeout == arg)
        {
            state_189_timeout = NULL;
            res = true;
        }
    if(state_243_timeout == arg)
        {
            state_243_timeout = NULL;
            res = true;
        }
    if(state_242_timeout == arg)
        {
            state_242_timeout = NULL;
            res = true;
        }
    if(state_184_timeout == arg)
        {
            state_184_timeout = NULL;
            res = true;
        }
    if(state_240_timeout == arg)
        {
            state_240_timeout = NULL;
            res = true;
        }
    if(state_239_timeout == arg)
        {
            state_239_timeout = NULL;
            res = true;
        }
    if(state_126_timeout == arg)
        {
            state_126_timeout = NULL;
            res = true;
        }
    return res;
}

void _SysVehicule::rootState_entDef() {
    {
        NOTIFY_STATE_ENTERED("ROOT");
        rootStateEntDef();
    }
}

void _SysVehicule::rootStateEntDef() {
    Systeme_entDef();
}

void _SysVehicule::rootState_exit() {
    // State Systeme
    if(rootState_subState == Systeme)
        {
            Systeme_exit();
        }
    rootState_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT");
}

IOxfReactive::TakeEventStatus _SysVehicule::rootState_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State Systeme
    if(rootState_active == Systeme)
        {
            res = Systeme_processEvent();
        }
    return res;
}

void _SysVehicule::Systeme_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme");
    rootState_subState = Systeme;
    rootState_active = Systeme;
    state_60_entDef();
    state_61_entDef();
    state_62_entDef();
    state_71_entDef();
    state_72_entDef();
    state_76_entDef();
    state_87_entDef();
    state_96_entDef();
    state_126_entDef();
    state_139_entDef();
    state_146_entDef();
    state_166_entDef();
    state_206_entDef();
    state_252_entDef();
    state_275_entDef();
    state_278_entDef();
}

void _SysVehicule::Systeme_exit() {
    switch (state_60_subState) {
        // State pedales
        case pedales:
        {
            switch (pedales_subState) {
                // State freinage_injection
                case freinage_injection:
                {
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                }
                break;
                // State acceleration
                case acceleration:
                {
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                }
                break;
                default:
                    break;
            }
            pedales_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales");
        }
        break;
        // State regulateur
        case regulateur:
        {
            regulateur_exit();
        }
        break;
        default:
            break;
    }
    state_60_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60");
    switch (state_61_subState) {
        // State contact_off
        case contact_off:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_off");
        }
        break;
        // State contact_on
        case contact_on:
        {
            contact_on_exit();
        }
        break;
        default:
            break;
    }
    state_61_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61");
    state_62_exit();
    switch (state_71_subState) {
        // State mode_manuel
        case mode_manuel:
        {
            //#[ state Systeme.state_71.mode_manuel.(Exit) 
            voyant_regulateur = true;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_manuel");
        }
        break;
        // State mode_regulateur
        case mode_regulateur:
        {
            switch (mode_regulateur_subState) {
                // State maintien
                case maintien:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                }
                break;
                // State plus
                case plus:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                }
                break;
                // State moins
                case moins:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                }
                break;
                default:
                    break;
            }
            mode_regulateur_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
        }
        break;
        default:
            break;
    }
    state_71_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71");
    state_72_exit();
    switch (state_76_subState) {
        // State limiteur_on
        case limiteur_on:
        {
            switch (limiteur_on_subState) {
                // State consigne_fixe
                case consigne_fixe:
                {
                    switch (consigne_fixe_subState) {
                        // State limiteur_inhibe
                        case limiteur_inhibe:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                        }
                        break;
                        // State limiteur_effectif
                        case limiteur_effectif:
                        {
                            switch (limiteur_effectif_subState) {
                                // State limite_tenue
                                case limite_tenue:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                                }
                                break;
                                // State depassement
                                case depassement:
                                {
                                    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                                    alerte_depassement(0);
                                    //#]
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                                }
                                break;
                                default:
                                    break;
                            }
                            limiteur_effectif_subState = OMNonState;
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
                        }
                        break;
                        default:
                            break;
                    }
                    consigne_fixe_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
                }
                break;
                // State plus
                case limiteur_on_plus:
                {
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.plus");
                }
                break;
                // State moins
                case limiteur_on_moins:
                {
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.moins");
                }
                break;
                default:
                    break;
            }
            limiteur_on_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on");
        }
        break;
        // State limiteur_off
        case limiteur_off:
        {
            //#[ state Systeme.state_76.limiteur_off.(Exit) 
            voyant_limiteur = true;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_off");
        }
        break;
        default:
            break;
    }
    state_76_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76");
    switch (state_87_subState) {
        // State bluetooth_desactive
        case bluetooth_desactive:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_desactive");
        }
        break;
        // State bluetooth_active
        case bluetooth_active:
        {
            switch (bluetooth_active_subState) {
                // State recherche_telephone
                case recherche_telephone:
                {
                    cancel(bluetooth_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                }
                break;
                // State telephone_connecte
                case telephone_connecte:
                {
                    //#[ state Systeme.state_87.bluetooth_active.telephone_connecte.(Exit) 
                    VOYANT_telephone_connecte = false;
                    
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
                }
                break;
                // State operation_jumelage
                case operation_jumelage:
                {
                    switch (operation_jumelage_subState) {
                        // State jumelage_kit
                        case jumelage_kit:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                        }
                        break;
                        // State attente_connexion
                        case attente_connexion:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.attente_connexion");
                        }
                        break;
                        default:
                            break;
                    }
                    operation_jumelage_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage");
                }
                break;
                default:
                    break;
            }
            bluetooth_active_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active");
        }
        break;
        // State demarrage_bluetooth
        case demarrage_bluetooth:
        {
            cancel(state_87_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.demarrage_bluetooth");
        }
        break;
        default:
            break;
    }
    state_87_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87");
    switch (state_96_subState) {
        // State telephone_actif
        case telephone_actif:
        {
            switch (telephone_actif_subState) {
                // State bluetooth_telephone_active
                case bluetooth_telephone_active:
                {
                    bluetooth_telephone_active_exit();
                }
                break;
                // State bluetooth_telephone_desactive
                case bluetooth_telephone_desactive:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_desactive");
                }
                break;
                default:
                    break;
            }
            telephone_actif_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif");
        }
        break;
        // State telephone_eteint
        case telephone_eteint:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_eteint");
        }
        break;
        default:
            break;
    }
    state_96_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96");
    switch (state_126_subState) {
        // State batterie_telephone
        case batterie_telephone:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.batterie_telephone");
        }
        break;
        // State charge_batterie_telephone
        case charge_batterie_telephone:
        {
            popNullTransition();
            cancel(state_126_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.charge_batterie_telephone");
        }
        break;
        // State verifiaction_telephone_allume
        case verifiaction_telephone_allume:
        {
            cancel(state_126_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.verifiaction_telephone_allume");
        }
        break;
        default:
            break;
    }
    state_126_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_126");
    switch (state_139_subState) {
        // State gestion_communication
        case gestion_communication:
        {
            gestion_communication_exit();
        }
        break;
        // State arret_de_communication
        case arret_de_communication:
        {
            arret_de_communication_exit();
        }
        break;
        default:
            break;
    }
    state_139_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139");
    switch (state_146_subState) {
        // State telephone_SIM
        case telephone_SIM:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.telephone_SIM");
        }
        break;
        // State tentative_appel
        case tentative_appel:
        {
            tentative_appel_exit();
        }
        break;
        // State discussion_telephonique
        case discussion_telephonique:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.discussion_telephonique");
        }
        break;
        default:
            break;
    }
    state_146_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_146");
    switch (state_166_subState) {
        // State controle_telephone_connecte
        case controle_telephone_connecte:
        {
            controle_telephone_connecte_exit();
        }
        break;
        // State telephone_deconnecte
        case telephone_deconnecte:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.telephone_deconnecte");
        }
        break;
        default:
            break;
    }
    state_166_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166");
    state_206_exit();
    state_252_exit();
    switch (state_275_subState) {
        // State simulation_voiture_devant
        case simulation_voiture_devant:
        {
            simulation_voiture_devant_exit();
        }
        break;
        // State reglage_voiture_devant
        case reglage_voiture_devant:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_275.reglage_voiture_devant");
        }
        break;
        default:
            break;
    }
    state_275_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_275");
    switch (state_278_subState) {
        // State contact_radio_actif
        case contact_radio_actif:
        {
            switch (contact_radio_actif_subState) {
                // State priorite_radio
                case priorite_radio:
                {
                    priorite_radio_exit();
                }
                break;
                // State priorite_appel
                case priorite_appel:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
                }
                break;
                // State priorite_sonnerie
                case priorite_sonnerie:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
                }
                break;
                default:
                    break;
            }
            contact_radio_actif_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif");
        }
        break;
        // State radio_eteinte
        case radio_eteinte:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.radio_eteinte");
        }
        break;
        // State radio_prete
        case radio_prete:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.radio_prete");
        }
        break;
        default:
            break;
    }
    state_278_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme");
}

IOxfReactive::TakeEventStatus _SysVehicule::Systeme_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_60
    if(state_60_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_61
    if(state_61_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_62
    if(state_62_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_71
    if(state_71_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_72
    if(state_72_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_76
    if(state_76_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_87
    if(state_87_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_96
    if(state_96_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_126
    if(state_126_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_139
    if(state_139_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_146
    if(state_146_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_166
    if(state_166_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_206
    if(state_206_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_252
    if(state_252_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_275
    if(state_275_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_278
    if(state_278_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    
    return res;
}

void _SysVehicule::state_96_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96");
    NOTIFY_TRANSITION_STARTED("142");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_eteint");
    state_96_subState = telephone_eteint;
    state_96_active = telephone_eteint;
    //#[ state Systeme.state_96.telephone_eteint.(Entry) 
    GEN(ev_telephone_bluetooth_desactive);
    affichage_liste_appareils = "";
    affichage_appairage = "";
    cmd_bluetooth_telephone_actif=false;
    telephone_allume = false;
    affichage_appairage = "Standby";
    //#]
    NOTIFY_TRANSITION_TERMINATED("142");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_96_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_96_active) {
        // State recherche_bluetooth
        case recherche_bluetooth:
        {
            res = recherche_bluetooth_handleEvent();
        }
        break;
        // State attente_jumelage
        case attente_jumelage:
        {
            res = attente_jumelage_handleEvent();
        }
        break;
        // State attente_reponse
        case attente_reponse:
        {
            res = attente_reponse_handleEvent();
        }
        break;
        // State jumelage_effectif
        case jumelage_effectif:
        {
            res = jumelage_effectif_handleEvent();
        }
        break;
        // State connexion
        case connexion:
        {
            res = connexion_handleEvent();
        }
        break;
        // State kit_connecte
        case kit_connecte:
        {
            res = kit_connecte_handleEvent();
        }
        break;
        // State kit_detecte
        case kit_detecte:
        {
            res = kit_detecte_handleEvent();
        }
        break;
        // State interruption_bluetooth_kit
        case interruption_bluetooth_kit:
        {
            res = interruption_bluetooth_kit_handleEvent();
        }
        break;
        // State bluetooth_telephone_desactive
        case bluetooth_telephone_desactive:
        {
            res = bluetooth_telephone_desactive_handleEvent();
        }
        break;
        // State telephone_eteint
        case telephone_eteint:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 141 
                    if(niveau_batterie_telephone > 0 && telephone_allume)
                        {
                            NOTIFY_TRANSITION_STARTED("141");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_eteint");
                            telephone_actif_entDef();
                            NOTIFY_TRANSITION_TERMINATED("141");
                            res = eventConsumed;
                        }
                    else
                        {
                            NOTIFY_TRANSITION_STARTED("147");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_eteint");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_eteint");
                            state_96_subState = telephone_eteint;
                            state_96_active = telephone_eteint;
                            //#[ state Systeme.state_96.telephone_eteint.(Entry) 
                            GEN(ev_telephone_bluetooth_desactive);
                            affichage_liste_appareils = "";
                            affichage_appairage = "";
                            cmd_bluetooth_telephone_actif=false;
                            telephone_allume = false;
                            affichage_appairage = "Standby";
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("147");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::telephone_actif_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif");
    state_96_subState = telephone_actif;
    NOTIFY_TRANSITION_STARTED("67");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_desactive");
    telephone_actif_subState = bluetooth_telephone_desactive;
    state_96_active = bluetooth_telephone_desactive;
    //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_desactive.(Entry) 
    GEN(ev_telephone_bluetooth_desactive);
    affichage_liste_appareils = "";
    affichage_appairage = "Standby";
    cmd_bluetooth_telephone_actif=false;
    //#]
    NOTIFY_TRANSITION_TERMINATED("67");
}

IOxfReactive::TakeEventStatus _SysVehicule::telephone_actif_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 140 
            if(niveau_batterie_telephone <=0 || !(telephone_allume))
                {
                    NOTIFY_TRANSITION_STARTED("140");
                    switch (telephone_actif_subState) {
                        // State bluetooth_telephone_active
                        case bluetooth_telephone_active:
                        {
                            bluetooth_telephone_active_exit();
                        }
                        break;
                        // State bluetooth_telephone_desactive
                        case bluetooth_telephone_desactive:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_desactive");
                        }
                        break;
                        default:
                            break;
                    }
                    telephone_actif_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_eteint");
                    state_96_subState = telephone_eteint;
                    state_96_active = telephone_eteint;
                    //#[ state Systeme.state_96.telephone_eteint.(Entry) 
                    GEN(ev_telephone_bluetooth_desactive);
                    affichage_liste_appareils = "";
                    affichage_appairage = "";
                    cmd_bluetooth_telephone_actif=false;
                    telephone_allume = false;
                    affichage_appairage = "Standby";
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("140");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::bluetooth_telephone_desactive_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 65 
            if(cmd_bluetooth_telephone_actif == true )
                {
                    NOTIFY_TRANSITION_STARTED("65");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_desactive");
                    bluetooth_telephone_active_entDef();
                    NOTIFY_TRANSITION_TERMINATED("65");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = telephone_actif_handleEvent();
        }
    return res;
}

void _SysVehicule::bluetooth_telephone_active_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active");
    telephone_actif_subState = bluetooth_telephone_active;
    NOTIFY_TRANSITION_STARTED("57");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth");
    bluetooth_telephone_active_subState = recherche_bluetooth;
    state_96_active = recherche_bluetooth;
    //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth.(Entry) 
    affichage_liste_appareils = liste_appareils_detectes[0];
    affichage_appairage = messages_appairage[0];
    //#]
    NOTIFY_TRANSITION_TERMINATED("57");
}

void _SysVehicule::bluetooth_telephone_active_exit() {
    switch (bluetooth_telephone_active_subState) {
        // State recherche_bluetooth
        case recherche_bluetooth:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth");
        }
        break;
        // State jumelage
        case jumelage:
        {
            switch (jumelage_subState) {
                // State attente_jumelage
                case attente_jumelage:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
                }
                break;
                // State attente_reponse
                case attente_reponse:
                {
                    cancel(jumelage_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
                }
                break;
                // State jumelage_effectif
                case jumelage_effectif:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
                }
                break;
                default:
                    break;
            }
            jumelage_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage");
        }
        break;
        // State connexion
        case connexion:
        {
            cancel(bluetooth_telephone_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
        }
        break;
        // State kit_connecte
        case kit_connecte:
        {
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte.(Exit) 
            VOYANT_kit_connecte = false;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte");
        }
        break;
        // State kit_detecte
        case kit_detecte:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_detecte");
        }
        break;
        // State interruption_bluetooth_kit
        case interruption_bluetooth_kit:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.interruption_bluetooth_kit");
        }
        break;
        default:
            break;
    }
    bluetooth_telephone_active_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active");
}

IOxfReactive::TakeEventStatus _SysVehicule::bluetooth_telephone_active_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 66 
            if(cmd_bluetooth_telephone_actif == false)
                {
                    NOTIFY_TRANSITION_STARTED("66");
                    bluetooth_telephone_active_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_desactive");
                    telephone_actif_subState = bluetooth_telephone_desactive;
                    state_96_active = bluetooth_telephone_desactive;
                    //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_desactive.(Entry) 
                    GEN(ev_telephone_bluetooth_desactive);
                    affichage_liste_appareils = "";
                    affichage_appairage = "Standby";
                    cmd_bluetooth_telephone_actif=false;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("66");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = telephone_actif_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::recherche_bluetooth_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_kit_vehicule_pret__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("58");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_detecte");
            pushNullTransition();
            bluetooth_telephone_active_subState = kit_detecte;
            state_96_active = kit_detecte;
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_detecte.(Entry) 
            affichage_liste_appareils = liste_appareils_detectes[1];
            affichage_appairage = messages_appairage[1];
            //#]
            NOTIFY_TRANSITION_TERMINATED("58");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_telephone_active_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::kit_detecte_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            //## transition 59 
            if(kit_jumele)
                {
                    NOTIFY_TRANSITION_STARTED("59");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_detecte");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
                    bluetooth_telephone_active_subState = connexion;
                    state_96_active = connexion;
                    //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion.(Entry) 
                    affichage_appairage = messages_appairage[4];
                    //#]
                    bluetooth_telephone_active_timeout = scheduleTimeout(100, "ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
                    NOTIFY_TRANSITION_TERMINATED("59");
                    res = eventConsumed;
                }
            else
                {
                    NOTIFY_TRANSITION_STARTED("71");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_detecte");
                    jumelage_entDef();
                    NOTIFY_TRANSITION_TERMINATED("71");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_telephone_active_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::kit_connecte_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_kit_bluetooth_desactive__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("63");
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte.(Exit) 
            VOYANT_kit_connecte = false;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth");
            bluetooth_telephone_active_subState = recherche_bluetooth;
            state_96_active = recherche_bluetooth;
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth.(Entry) 
            affichage_liste_appareils = liste_appareils_detectes[0];
            affichage_appairage = messages_appairage[0];
            //#]
            NOTIFY_TRANSITION_TERMINATED("63");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_telephone_active_handleEvent();
        }
    return res;
}

void _SysVehicule::jumelage_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage");
    bluetooth_telephone_active_subState = jumelage;
    NOTIFY_TRANSITION_STARTED("72");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
    jumelage_subState = attente_jumelage;
    state_96_active = attente_jumelage;
    NOTIFY_TRANSITION_TERMINATED("72");
}

IOxfReactive::TakeEventStatus _SysVehicule::jumelage_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_kit_bluetooth_desactive__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("204");
            switch (jumelage_subState) {
                // State attente_jumelage
                case attente_jumelage:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
                }
                break;
                // State attente_reponse
                case attente_reponse:
                {
                    cancel(jumelage_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
                }
                break;
                // State jumelage_effectif
                case jumelage_effectif:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
                }
                break;
                default:
                    break;
            }
            jumelage_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.interruption_bluetooth_kit");
            pushNullTransition();
            bluetooth_telephone_active_subState = interruption_bluetooth_kit;
            state_96_active = interruption_bluetooth_kit;
            NOTIFY_TRANSITION_TERMINATED("204");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_telephone_active_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::jumelage_effectif_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_btn_telephone_appairage__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("77");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
            //#[ transition 77 
            GEN(ev_telephone_tentative_mdp(champ_mdp));
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
            jumelage_subState = jumelage_effectif;
            state_96_active = jumelage_effectif;
            NOTIFY_TRANSITION_TERMINATED("77");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_kit_mdp_incorrect__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("76");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
            //#[ transition 76 
            affichage_appairage = messages_appairage[3]; champ_mdp="";
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
            jumelage_subState = jumelage_effectif;
            state_96_active = jumelage_effectif;
            NOTIFY_TRANSITION_TERMINATED("76");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_kit_mdp_correct__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("74");
            switch (jumelage_subState) {
                // State attente_jumelage
                case attente_jumelage:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
                }
                break;
                // State attente_reponse
                case attente_reponse:
                {
                    cancel(jumelage_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
                }
                break;
                // State jumelage_effectif
                case jumelage_effectif:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
                }
                break;
                default:
                    break;
            }
            jumelage_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
            bluetooth_telephone_active_subState = connexion;
            state_96_active = connexion;
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion.(Entry) 
            affichage_appairage = messages_appairage[4];
            //#]
            bluetooth_telephone_active_timeout = scheduleTimeout(100, "ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
            NOTIFY_TRANSITION_TERMINATED("74");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = jumelage_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::attente_reponse_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == jumelage_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("73");
                    cancel(jumelage_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
                    //#[ transition 73 
                    affichage_appairage = messages_appairage[5];
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
                    jumelage_subState = attente_jumelage;
                    state_96_active = attente_jumelage;
                    NOTIFY_TRANSITION_TERMINATED("73");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_kit_demande_mdp__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("78");
            cancel(jumelage_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
            //#[ transition 78 
            affichage_appairage = messages_appairage[2];
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
            jumelage_subState = jumelage_effectif;
            state_96_active = jumelage_effectif;
            NOTIFY_TRANSITION_TERMINATED("78");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = jumelage_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::attente_jumelage_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_btn_ok__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("75");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
            //#[ transition 75 
            GEN(ev_telephone_demande_jumelage);
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
            jumelage_subState = attente_reponse;
            state_96_active = attente_reponse;
            jumelage_timeout = scheduleTimeout(500, "ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
            NOTIFY_TRANSITION_TERMINATED("75");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = jumelage_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::interruption_bluetooth_kit_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            NOTIFY_TRANSITION_STARTED("203");
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.interruption_bluetooth_kit");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth");
            bluetooth_telephone_active_subState = recherche_bluetooth;
            state_96_active = recherche_bluetooth;
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth.(Entry) 
            affichage_liste_appareils = liste_appareils_detectes[0];
            affichage_appairage = messages_appairage[0];
            //#]
            NOTIFY_TRANSITION_TERMINATED("203");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_telephone_active_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::connexion_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == bluetooth_telephone_active_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("62");
                    cancel(bluetooth_telephone_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
                    //#[ transition 62 
                    GEN(ev_telephone_demande_connexion);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
                    bluetooth_telephone_active_subState = connexion;
                    state_96_active = connexion;
                    //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion.(Entry) 
                    affichage_appairage = messages_appairage[4];
                    //#]
                    bluetooth_telephone_active_timeout = scheduleTimeout(100, "ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
                    NOTIFY_TRANSITION_TERMINATED("62");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_kit_bluetooth_desactive__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("205");
            cancel(bluetooth_telephone_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.interruption_bluetooth_kit");
            pushNullTransition();
            bluetooth_telephone_active_subState = interruption_bluetooth_kit;
            state_96_active = interruption_bluetooth_kit;
            NOTIFY_TRANSITION_TERMINATED("205");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_kit_connexion_acceptee__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("60");
            cancel(bluetooth_telephone_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte");
            bluetooth_telephone_active_subState = kit_connecte;
            state_96_active = kit_connecte;
            //#[ state Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte.(Entry) 
            VOYANT_kit_connecte = true;
            kit_jumele=true;
            //#]
            NOTIFY_TRANSITION_TERMINATED("60");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_telephone_active_handleEvent();
        }
    return res;
}

void _SysVehicule::state_87_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87");
    NOTIFY_TRANSITION_STARTED("51");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_desactive");
    state_87_subState = bluetooth_desactive;
    state_87_active = bluetooth_desactive;
    //#[ state Systeme.state_87.bluetooth_desactive.(Entry) 
    VOYANT_bluetooth_vehicule = false;
    GEN(ev_kit_bluetooth_desactive);
    //#]
    NOTIFY_TRANSITION_TERMINATED("51");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_87_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_87_active) {
        // State bluetooth_desactive
        case bluetooth_desactive:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 52 
                    if(IS_IN(contact_on))
                        {
                            NOTIFY_TRANSITION_STARTED("52");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_desactive");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.demarrage_bluetooth");
                            state_87_subState = demarrage_bluetooth;
                            state_87_active = demarrage_bluetooth;
                            state_87_timeout = scheduleTimeout(300, "ROOT.Systeme.state_87.demarrage_bluetooth");
                            NOTIFY_TRANSITION_TERMINATED("52");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State recherche_telephone
        case recherche_telephone:
        {
            res = recherche_telephone_handleEvent();
        }
        break;
        // State telephone_connecte
        case telephone_connecte:
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_bluetooth_desactive__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("64");
                    //#[ state Systeme.state_87.bluetooth_active.telephone_connecte.(Exit) 
                    VOYANT_telephone_connecte = false;
                    
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                    bluetooth_active_subState = recherche_telephone;
                    state_87_active = recherche_telephone;
                    //#[ state Systeme.state_87.bluetooth_active.recherche_telephone.(Entry) 
                    GEN(ev_kit_vehicule_pret);
                    envoi_batterie_kit(0);
                    //#]
                    bluetooth_active_timeout = scheduleTimeout(500, "ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                    NOTIFY_TRANSITION_TERMINATED("64");
                    res = eventConsumed;
                }
            
            if(res == eventNotConsumed)
                {
                    res = bluetooth_active_handleEvent();
                }
        }
        break;
        // State jumelage_kit
        case jumelage_kit:
        {
            res = jumelage_kit_handleEvent();
        }
        break;
        // State attente_connexion
        case attente_connexion:
        {
            res = attente_connexion_handleEvent();
        }
        break;
        // State demarrage_bluetooth
        case demarrage_bluetooth:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_87_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("54");
                            cancel(state_87_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.demarrage_bluetooth");
                            bluetooth_active_entDef();
                            NOTIFY_TRANSITION_TERMINATED("54");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::bluetooth_active_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active");
    state_87_subState = bluetooth_active;
    //#[ state Systeme.state_87.bluetooth_active.(Entry) 
    VOYANT_bluetooth_vehicule = true;
    //#]
    NOTIFY_TRANSITION_STARTED("55");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
    bluetooth_active_subState = recherche_telephone;
    state_87_active = recherche_telephone;
    //#[ state Systeme.state_87.bluetooth_active.recherche_telephone.(Entry) 
    GEN(ev_kit_vehicule_pret);
    envoi_batterie_kit(0);
    //#]
    bluetooth_active_timeout = scheduleTimeout(500, "ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
    NOTIFY_TRANSITION_TERMINATED("55");
}

IOxfReactive::TakeEventStatus _SysVehicule::bluetooth_active_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 53 
            if(IS_IN(contact_off))
                {
                    NOTIFY_TRANSITION_STARTED("53");
                    switch (bluetooth_active_subState) {
                        // State recherche_telephone
                        case recherche_telephone:
                        {
                            cancel(bluetooth_active_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                        }
                        break;
                        // State telephone_connecte
                        case telephone_connecte:
                        {
                            //#[ state Systeme.state_87.bluetooth_active.telephone_connecte.(Exit) 
                            VOYANT_telephone_connecte = false;
                            
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
                        }
                        break;
                        // State operation_jumelage
                        case operation_jumelage:
                        {
                            switch (operation_jumelage_subState) {
                                // State jumelage_kit
                                case jumelage_kit:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                                }
                                break;
                                // State attente_connexion
                                case attente_connexion:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.attente_connexion");
                                }
                                break;
                                default:
                                    break;
                            }
                            operation_jumelage_subState = OMNonState;
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage");
                        }
                        break;
                        default:
                            break;
                    }
                    bluetooth_active_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_desactive");
                    state_87_subState = bluetooth_desactive;
                    state_87_active = bluetooth_desactive;
                    //#[ state Systeme.state_87.bluetooth_desactive.(Entry) 
                    VOYANT_bluetooth_vehicule = false;
                    GEN(ev_kit_bluetooth_desactive);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("53");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::recherche_telephone_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_telephone_demande_jumelage__MonPkg_id))
        {
            OMSETPARAMS(ev_telephone_demande_jumelage);
            //## transition 68 
            if( IS_IN(moteur_off))
                {
                    NOTIFY_TRANSITION_STARTED("68");
                    cancel(bluetooth_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                    operation_jumelage_entDef();
                    NOTIFY_TRANSITION_TERMINATED("68");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == bluetooth_active_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("56");
                    cancel(bluetooth_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                    bluetooth_active_subState = recherche_telephone;
                    state_87_active = recherche_telephone;
                    //#[ state Systeme.state_87.bluetooth_active.recherche_telephone.(Entry) 
                    GEN(ev_kit_vehicule_pret);
                    envoi_batterie_kit(0);
                    //#]
                    bluetooth_active_timeout = scheduleTimeout(500, "ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                    NOTIFY_TRANSITION_TERMINATED("56");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_telephone_demande_connexion__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("61");
            cancel(bluetooth_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
            bluetooth_active_subState = telephone_connecte;
            state_87_active = telephone_connecte;
            //#[ state Systeme.state_87.bluetooth_active.telephone_connecte.(Entry) 
            GEN(ev_kit_connexion_acceptee);
            VOYANT_telephone_connecte = true;
            //#]
            NOTIFY_TRANSITION_TERMINATED("61");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_active_handleEvent();
        }
    return res;
}

void _SysVehicule::operation_jumelage_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage");
    bluetooth_active_subState = operation_jumelage;
    NOTIFY_TRANSITION_STARTED("207");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
    operation_jumelage_subState = jumelage_kit;
    state_87_active = jumelage_kit;
    //#[ state Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit.(Entry) 
    GEN(ev_kit_demande_mdp);
    //#]
    NOTIFY_TRANSITION_TERMINATED("207");
}

IOxfReactive::TakeEventStatus _SysVehicule::operation_jumelage_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_telephone_bluetooth_desactive__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("202");
            switch (operation_jumelage_subState) {
                // State jumelage_kit
                case jumelage_kit:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                }
                break;
                // State attente_connexion
                case attente_connexion:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.attente_connexion");
                }
                break;
                default:
                    break;
            }
            operation_jumelage_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
            bluetooth_active_subState = recherche_telephone;
            state_87_active = recherche_telephone;
            //#[ state Systeme.state_87.bluetooth_active.recherche_telephone.(Entry) 
            GEN(ev_kit_vehicule_pret);
            envoi_batterie_kit(0);
            //#]
            bluetooth_active_timeout = scheduleTimeout(500, "ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
            NOTIFY_TRANSITION_TERMINATED("202");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_telephone_demande_connexion__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("70");
            switch (operation_jumelage_subState) {
                // State jumelage_kit
                case jumelage_kit:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                }
                break;
                // State attente_connexion
                case attente_connexion:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.attente_connexion");
                }
                break;
                default:
                    break;
            }
            operation_jumelage_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
            bluetooth_active_subState = telephone_connecte;
            state_87_active = telephone_connecte;
            //#[ state Systeme.state_87.bluetooth_active.telephone_connecte.(Entry) 
            GEN(ev_kit_connexion_acceptee);
            VOYANT_telephone_connecte = true;
            //#]
            NOTIFY_TRANSITION_TERMINATED("70");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = bluetooth_active_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::jumelage_kit_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_telephone_tentative_mdp__MonPkg_id))
        {
            OMSETPARAMS(ev_telephone_tentative_mdp);
            //## transition 69 
            if( verifier_mdp(params->mdp) )
                {
                    NOTIFY_TRANSITION_STARTED("69");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                    //#[ transition 69 
                    GEN(ev_kit_mdp_correct);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.attente_connexion");
                    operation_jumelage_subState = attente_connexion;
                    state_87_active = attente_connexion;
                    NOTIFY_TRANSITION_TERMINATED("69");
                    res = eventConsumed;
                }
            else
                {
                    //## transition 79 
                    if( !(verifier_mdp(params->mdp)) )
                        {
                            NOTIFY_TRANSITION_STARTED("79");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                            //#[ transition 79 
                            GEN(ev_kit_mdp_incorrect);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
                            operation_jumelage_subState = jumelage_kit;
                            state_87_active = jumelage_kit;
                            //#[ state Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit.(Entry) 
                            GEN(ev_kit_demande_mdp);
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("79");
                            res = eventConsumed;
                        }
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = operation_jumelage_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::attente_connexion_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    res = operation_jumelage_handleEvent();
    return res;
}

void _SysVehicule::state_76_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76");
    NOTIFY_TRANSITION_STARTED("38");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
    state_76_subState = limiteur_off;
    state_76_active = limiteur_off;
    //#[ state Systeme.state_76.limiteur_off.(Entry) 
    voyant_limiteur = false;
    alerte_depassement(0);
    //#]
    NOTIFY_TRANSITION_TERMINATED("38");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_76_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_76_active) {
        // State limiteur_inhibe
        case limiteur_inhibe:
        {
            res = limiteur_inhibe_handleEvent();
        }
        break;
        // State limite_tenue
        case limite_tenue:
        {
            res = limite_tenue_handleEvent();
        }
        break;
        // State depassement
        case depassement:
        {
            res = depassement_handleEvent();
        }
        break;
        // State plus
        case limiteur_on_plus:
        {
            res = limiteur_on_plus_handleEvent();
        }
        break;
        // State moins
        case limiteur_on_moins:
        {
            res = limiteur_on_moins_handleEvent();
        }
        break;
        // State limiteur_off
        case limiteur_off:
        {
            if(IS_EVENT_TYPE_OF(ev_limiteur__MonPkg_id))
                {
                    //## transition 29 
                    if( IS_IN(moteur_on))
                        {
                            NOTIFY_TRANSITION_STARTED("29");
                            //#[ state Systeme.state_76.limiteur_off.(Exit) 
                            voyant_limiteur = true;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_off");
                            limiteur_on_entDef();
                            NOTIFY_TRANSITION_TERMINATED("29");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::limiteur_on_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on");
    state_76_subState = limiteur_on;
    NOTIFY_TRANSITION_STARTED("30");
    //#[ transition 30 
    vitesseConsigne = valeur_initiale_limiteur;
    //#]
    consigne_fixe_entDef();
    NOTIFY_TRANSITION_TERMINATED("30");
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_on_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_regulateur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("48");
            switch (limiteur_on_subState) {
                // State consigne_fixe
                case consigne_fixe:
                {
                    switch (consigne_fixe_subState) {
                        // State limiteur_inhibe
                        case limiteur_inhibe:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                        }
                        break;
                        // State limiteur_effectif
                        case limiteur_effectif:
                        {
                            switch (limiteur_effectif_subState) {
                                // State limite_tenue
                                case limite_tenue:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                                }
                                break;
                                // State depassement
                                case depassement:
                                {
                                    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                                    alerte_depassement(0);
                                    //#]
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                                }
                                break;
                                default:
                                    break;
                            }
                            limiteur_effectif_subState = OMNonState;
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
                        }
                        break;
                        default:
                            break;
                    }
                    consigne_fixe_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
                }
                break;
                // State plus
                case limiteur_on_plus:
                {
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.plus");
                }
                break;
                // State moins
                case limiteur_on_moins:
                {
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.moins");
                }
                break;
                default:
                    break;
            }
            limiteur_on_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
            state_76_subState = limiteur_off;
            state_76_active = limiteur_off;
            //#[ state Systeme.state_76.limiteur_off.(Entry) 
            voyant_limiteur = false;
            alerte_depassement(0);
            //#]
            NOTIFY_TRANSITION_TERMINATED("48");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_limiteur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("44");
            switch (limiteur_on_subState) {
                // State consigne_fixe
                case consigne_fixe:
                {
                    switch (consigne_fixe_subState) {
                        // State limiteur_inhibe
                        case limiteur_inhibe:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                        }
                        break;
                        // State limiteur_effectif
                        case limiteur_effectif:
                        {
                            switch (limiteur_effectif_subState) {
                                // State limite_tenue
                                case limite_tenue:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                                }
                                break;
                                // State depassement
                                case depassement:
                                {
                                    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                                    alerte_depassement(0);
                                    //#]
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                                }
                                break;
                                default:
                                    break;
                            }
                            limiteur_effectif_subState = OMNonState;
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
                        }
                        break;
                        default:
                            break;
                    }
                    consigne_fixe_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
                }
                break;
                // State plus
                case limiteur_on_plus:
                {
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.plus");
                }
                break;
                // State moins
                case limiteur_on_moins:
                {
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.moins");
                }
                break;
                default:
                    break;
            }
            limiteur_on_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
            state_76_subState = limiteur_off;
            state_76_active = limiteur_off;
            //#[ state Systeme.state_76.limiteur_off.(Entry) 
            voyant_limiteur = false;
            alerte_depassement(0);
            //#]
            NOTIFY_TRANSITION_TERMINATED("44");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 28 
            if( IS_IN(moteur_off) || ((vitesseConsigne-speed)    < 10 && accelPedal > 7))
                {
                    NOTIFY_TRANSITION_STARTED("28");
                    switch (limiteur_on_subState) {
                        // State consigne_fixe
                        case consigne_fixe:
                        {
                            switch (consigne_fixe_subState) {
                                // State limiteur_inhibe
                                case limiteur_inhibe:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                                }
                                break;
                                // State limiteur_effectif
                                case limiteur_effectif:
                                {
                                    switch (limiteur_effectif_subState) {
                                        // State limite_tenue
                                        case limite_tenue:
                                        {
                                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                                        }
                                        break;
                                        // State depassement
                                        case depassement:
                                        {
                                            //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                                            alerte_depassement(0);
                                            //#]
                                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                                        }
                                        break;
                                        default:
                                            break;
                                    }
                                    limiteur_effectif_subState = OMNonState;
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
                                }
                                break;
                                default:
                                    break;
                            }
                            consigne_fixe_subState = OMNonState;
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
                        }
                        break;
                        // State plus
                        case limiteur_on_plus:
                        {
                            cancel(limiteur_on_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.plus");
                        }
                        break;
                        // State moins
                        case limiteur_on_moins:
                        {
                            cancel(limiteur_on_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.moins");
                        }
                        break;
                        default:
                            break;
                    }
                    limiteur_on_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
                    state_76_subState = limiteur_off;
                    state_76_active = limiteur_off;
                    //#[ state Systeme.state_76.limiteur_off.(Entry) 
                    voyant_limiteur = false;
                    alerte_depassement(0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("28");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_on_plus_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == limiteur_on_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("35");
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.plus");
                    consigne_fixe_entDef();
                    NOTIFY_TRANSITION_TERMINATED("35");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_plus__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("32");
            cancel(limiteur_on_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.plus");
            //#[ transition 32 
            ex_vitesseConsigne(+9);
            //#]
            consigne_fixe_entDef();
            NOTIFY_TRANSITION_TERMINATED("32");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = limiteur_on_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_on_moins_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == limiteur_on_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("36");
                    cancel(limiteur_on_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.moins");
                    consigne_fixe_entDef();
                    NOTIFY_TRANSITION_TERMINATED("36");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_moins__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("34");
            cancel(limiteur_on_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.moins");
            //#[ transition 34 
            ex_vitesseConsigne(-9);
            //#]
            consigne_fixe_entDef();
            NOTIFY_TRANSITION_TERMINATED("34");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = limiteur_on_handleEvent();
        }
    return res;
}

void _SysVehicule::consigne_fixe_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
    limiteur_on_subState = consigne_fixe;
    NOTIFY_TRANSITION_STARTED("47");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
    consigne_fixe_subState = limiteur_inhibe;
    state_76_active = limiteur_inhibe;
    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe.(Entry) 
    limiteur_attente = true;
    //#]
    NOTIFY_TRANSITION_TERMINATED("47");
}

IOxfReactive::TakeEventStatus _SysVehicule::consigne_fixe_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_plus__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("31");
            switch (consigne_fixe_subState) {
                // State limiteur_inhibe
                case limiteur_inhibe:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                }
                break;
                // State limiteur_effectif
                case limiteur_effectif:
                {
                    switch (limiteur_effectif_subState) {
                        // State limite_tenue
                        case limite_tenue:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                        }
                        break;
                        // State depassement
                        case depassement:
                        {
                            //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                            alerte_depassement(0);
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                        }
                        break;
                        default:
                            break;
                    }
                    limiteur_effectif_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
                }
                break;
                default:
                    break;
            }
            consigne_fixe_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.plus");
            limiteur_on_subState = limiteur_on_plus;
            state_76_active = limiteur_on_plus;
            //#[ state Systeme.state_76.limiteur_on.plus.(Entry) 
            ex_vitesseConsigne(+1);
            //#]
            limiteur_on_timeout = scheduleTimeout(500, "ROOT.Systeme.state_76.limiteur_on.plus");
            NOTIFY_TRANSITION_TERMINATED("31");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_moins__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("33");
            switch (consigne_fixe_subState) {
                // State limiteur_inhibe
                case limiteur_inhibe:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                }
                break;
                // State limiteur_effectif
                case limiteur_effectif:
                {
                    switch (limiteur_effectif_subState) {
                        // State limite_tenue
                        case limite_tenue:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                        }
                        break;
                        // State depassement
                        case depassement:
                        {
                            //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                            alerte_depassement(0);
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                        }
                        break;
                        default:
                            break;
                    }
                    limiteur_effectif_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
                }
                break;
                default:
                    break;
            }
            consigne_fixe_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.moins");
            limiteur_on_subState = limiteur_on_moins;
            state_76_active = limiteur_on_moins;
            //#[ state Systeme.state_76.limiteur_on.moins.(Entry) 
            ex_vitesseConsigne(-1);
            //#]
            limiteur_on_timeout = scheduleTimeout(500, "ROOT.Systeme.state_76.limiteur_on.moins");
            NOTIFY_TRANSITION_TERMINATED("33");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = limiteur_on_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_inhibe_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 50 
            if(speed <= vitesseConsigne)
                {
                    NOTIFY_TRANSITION_STARTED("50");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
                    limiteur_effectif_entDef();
                    NOTIFY_TRANSITION_TERMINATED("50");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = consigne_fixe_handleEvent();
        }
    return res;
}

void _SysVehicule::limiteur_effectif_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
    consigne_fixe_subState = limiteur_effectif;
    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.(Entry) 
    limiteur_attente = false;
    //#]
    NOTIFY_TRANSITION_STARTED("148");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
    limiteur_effectif_subState = limite_tenue;
    state_76_active = limite_tenue;
    NOTIFY_TRANSITION_TERMINATED("148");
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_effectif_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    res = consigne_fixe_handleEvent();
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limite_tenue_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 45 
            if(speed > vitesseConsigne+2)
                {
                    NOTIFY_TRANSITION_STARTED("45");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                    limiteur_effectif_subState = depassement;
                    state_76_active = depassement;
                    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Entry) 
                    alerte_depassement(1);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("45");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = limiteur_effectif_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::depassement_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 46 
            if( speed <= vitesseConsigne)
                {
                    NOTIFY_TRANSITION_STARTED("46");
                    //#[ state Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement.(Exit) 
                    alerte_depassement(0);
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
                    limiteur_effectif_subState = limite_tenue;
                    state_76_active = limite_tenue;
                    NOTIFY_TRANSITION_TERMINATED("46");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = limiteur_effectif_handleEvent();
        }
    return res;
}

void _SysVehicule::state_72_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_72");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_72.simulation_du_vehicule");
    state_72_subState = simulation_du_vehicule;
    state_72_active = simulation_du_vehicule;
    //#[ state Systeme.state_72.simulation_du_vehicule.(Entry) 
    calcul_vitesse_distance();
    //#]
}

void _SysVehicule::state_72_exit() {
    // State simulation_du_vehicule
    if(state_72_subState == simulation_du_vehicule)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_72.simulation_du_vehicule");
        }
    state_72_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_72");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_72_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State simulation_du_vehicule
    if(state_72_active == simulation_du_vehicule)
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("7");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_72.simulation_du_vehicule");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_72.simulation_du_vehicule");
                    state_72_subState = simulation_du_vehicule;
                    state_72_active = simulation_du_vehicule;
                    //#[ state Systeme.state_72.simulation_du_vehicule.(Entry) 
                    calcul_vitesse_distance();
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("7");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_71_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71");
    NOTIFY_TRANSITION_STARTED("11");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
    state_71_subState = mode_manuel;
    state_71_active = mode_manuel;
    //#[ state Systeme.state_71.mode_manuel.(Entry) 
    voyant_regulateur = false;
    //#]
    NOTIFY_TRANSITION_TERMINATED("11");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_71_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_71_active) {
        // State mode_manuel
        case mode_manuel:
        {
            if(IS_EVENT_TYPE_OF(ev_regulateur__MonPkg_id))
                {
                    //## transition 43 
                    if( speed >= 30  && brakePedal < 0.5  && IS_IN(moteur_on))
                        {
                            NOTIFY_TRANSITION_STARTED("43");
                            //#[ state Systeme.state_71.mode_manuel.(Exit) 
                            voyant_regulateur = true;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_manuel");
                            mode_regulateur_entDef();
                            NOTIFY_TRANSITION_TERMINATED("43");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State maintien
        case maintien:
        {
            res = maintien_handleEvent();
        }
        break;
        // State plus
        case plus:
        {
            res = plus_handleEvent();
        }
        break;
        // State moins
        case moins:
        {
            res = moins_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::mode_regulateur_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur");
    state_71_subState = mode_regulateur;
    //#[ state Systeme.state_71.mode_regulateur.(Entry) 
    vitesseConsigne = speed;
    steady = throttle;
    //#]
    NOTIFY_TRANSITION_STARTED("16");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.maintien");
    mode_regulateur_subState = maintien;
    state_71_active = maintien;
    NOTIFY_TRANSITION_TERMINATED("16");
}

IOxfReactive::TakeEventStatus _SysVehicule::mode_regulateur_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_limiteur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("49");
            switch (mode_regulateur_subState) {
                // State maintien
                case maintien:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                }
                break;
                // State plus
                case plus:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                }
                break;
                // State moins
                case moins:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                }
                break;
                default:
                    break;
            }
            mode_regulateur_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
            state_71_subState = mode_manuel;
            state_71_active = mode_manuel;
            //#[ state Systeme.state_71.mode_manuel.(Entry) 
            voyant_regulateur = false;
            //#]
            NOTIFY_TRANSITION_TERMINATED("49");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_regulateur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("42");
            switch (mode_regulateur_subState) {
                // State maintien
                case maintien:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                }
                break;
                // State plus
                case plus:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                }
                break;
                // State moins
                case moins:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                }
                break;
                default:
                    break;
            }
            mode_regulateur_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
            state_71_subState = mode_manuel;
            state_71_active = mode_manuel;
            //#[ state Systeme.state_71.mode_manuel.(Entry) 
            voyant_regulateur = false;
            //#]
            NOTIFY_TRANSITION_TERMINATED("42");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 17 
            if( speed < 30  || brakePedal >= 0.5  || IS_IN(moteur_off))
                {
                    NOTIFY_TRANSITION_STARTED("17");
                    switch (mode_regulateur_subState) {
                        // State maintien
                        case maintien:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                        }
                        break;
                        // State plus
                        case plus:
                        {
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                        }
                        break;
                        // State moins
                        case moins:
                        {
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                        }
                        break;
                        default:
                            break;
                    }
                    mode_regulateur_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
                    state_71_subState = mode_manuel;
                    state_71_active = mode_manuel;
                    //#[ state Systeme.state_71.mode_manuel.(Entry) 
                    voyant_regulateur = false;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("17");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::plus_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            NOTIFY_TRANSITION_STARTED("14");
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            mode_regulateur_subState = maintien;
            state_71_active = maintien;
            NOTIFY_TRANSITION_TERMINATED("14");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = mode_regulateur_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::moins_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            NOTIFY_TRANSITION_STARTED("15");
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            mode_regulateur_subState = maintien;
            state_71_active = maintien;
            NOTIFY_TRANSITION_TERMINATED("15");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = mode_regulateur_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::maintien_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_plus__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("12");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.plus");
            pushNullTransition();
            mode_regulateur_subState = plus;
            state_71_active = plus;
            //#[ state Systeme.state_71.mode_regulateur.plus.(Entry) 
            ex_vitesseConsigne(+1);
            //#]
            NOTIFY_TRANSITION_TERMINATED("12");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_moins__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("13");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.moins");
            pushNullTransition();
            mode_regulateur_subState = moins;
            state_71_active = moins;
            //#[ state Systeme.state_71.mode_regulateur.moins.(Entry) 
            ex_vitesseConsigne(-1);
            //#]
            NOTIFY_TRANSITION_TERMINATED("13");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = mode_regulateur_handleEvent();
        }
    return res;
}

void _SysVehicule::state_62_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_62");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_62.horloge_rafraichissement");
    state_62_subState = horloge_rafraichissement;
    state_62_active = horloge_rafraichissement;
    //#[ state Systeme.state_62.horloge_rafraichissement.(Entry) 
    GEN(EVAL);
    //#]
    state_62_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_62.horloge_rafraichissement");
}

void _SysVehicule::state_62_exit() {
    // State horloge_rafraichissement
    if(state_62_subState == horloge_rafraichissement)
        {
            cancel(state_62_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_62.horloge_rafraichissement");
        }
    state_62_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_62");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_62_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State horloge_rafraichissement
    if(state_62_active == horloge_rafraichissement)
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_62_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("37");
                            cancel(state_62_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_62.horloge_rafraichissement");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_62.horloge_rafraichissement");
                            state_62_subState = horloge_rafraichissement;
                            state_62_active = horloge_rafraichissement;
                            //#[ state Systeme.state_62.horloge_rafraichissement.(Entry) 
                            GEN(EVAL);
                            //#]
                            state_62_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_62.horloge_rafraichissement");
                            NOTIFY_TRANSITION_TERMINATED("37");
                            res = eventConsumed;
                        }
                }
            
            
        }
    return res;
}

void _SysVehicule::state_61_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61");
    NOTIFY_TRANSITION_STARTED("3");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_off");
    state_61_subState = contact_off;
    state_61_active = contact_off;
    NOTIFY_TRANSITION_TERMINATED("3");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_61_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_61_active) {
        // State contact_off
        case contact_off:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 25 
                    if( cmd_contact==true)
                        {
                            NOTIFY_TRANSITION_STARTED("25");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_off");
                            contact_on_entDef();
                            NOTIFY_TRANSITION_TERMINATED("25");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State contact_on
        case contact_on:
        {
            res = contact_on_processEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::contact_on_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on");
    state_61_subState = contact_on;
    state_61_active = contact_on;
    state_266_entDef();
    state_267_entDef();
}

void _SysVehicule::contact_on_exit() {
    switch (state_266_subState) {
        // State moteur_off
        case moteur_off:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_266.moteur_off");
        }
        break;
        // State moteur_on
        case moteur_on:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_266.moteur_on");
        }
        break;
        default:
            break;
    }
    state_266_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_266");
    state_267_exit();
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on");
}

IOxfReactive::TakeEventStatus _SysVehicule::contact_on_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_266
    if(state_266_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(contact_on))
                {
                    return res;
                }
        }
    // State state_267
    if(state_267_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(contact_on))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = contact_on_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::contact_on_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 0 
            if( cmd_contact==false)
                {
                    NOTIFY_TRANSITION_STARTED("0");
                    contact_on_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_off");
                    state_61_subState = contact_off;
                    state_61_active = contact_off;
                    NOTIFY_TRANSITION_TERMINATED("0");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_267_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_267");
    NOTIFY_TRANSITION_STARTED("199");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
    state_267_subState = calcul_batterie_voiture;
    state_267_active = calcul_batterie_voiture;
    //#[ state Systeme.state_61.contact_on.state_267.calcul_batterie_voiture.(Entry) 
    calcul_batterie();
    //#]
    state_267_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
    NOTIFY_TRANSITION_TERMINATED("199");
}

void _SysVehicule::state_267_exit() {
    // State calcul_batterie_voiture
    if(state_267_subState == calcul_batterie_voiture)
        {
            cancel(state_267_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
        }
    state_267_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_267");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_267_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State calcul_batterie_voiture
    if(state_267_active == calcul_batterie_voiture)
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_267_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("200");
                            cancel(state_267_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
                            state_267_subState = calcul_batterie_voiture;
                            state_267_active = calcul_batterie_voiture;
                            //#[ state Systeme.state_61.contact_on.state_267.calcul_batterie_voiture.(Entry) 
                            calcul_batterie();
                            //#]
                            state_267_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
                            NOTIFY_TRANSITION_TERMINATED("200");
                            res = eventConsumed;
                        }
                }
            
            
        }
    return res;
}

void _SysVehicule::state_266_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_266");
    NOTIFY_TRANSITION_STARTED("4");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_266.moteur_off");
    state_266_subState = moteur_off;
    state_266_active = moteur_off;
    //#[ state Systeme.state_61.contact_on.state_266.moteur_off.(Entry) 
    arreter();
    //#]
    NOTIFY_TRANSITION_TERMINATED("4");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_266_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_266_active) {
        // State moteur_off
        case moteur_off:
        {
            if(IS_EVENT_TYPE_OF(ev_demarrer__MonPkg_id))
                {
                    //## transition 1 
                    if( IS_IN(fonctionelle) )
                        {
                            NOTIFY_TRANSITION_STARTED("1");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_266.moteur_off");
                            //#[ transition 1 
                            ex_demarrer();
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_266.moteur_on");
                            state_266_subState = moteur_on;
                            state_266_active = moteur_on;
                            //#[ state Systeme.state_61.contact_on.state_266.moteur_on.(Entry) 
                            calcul_carburant();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("1");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State moteur_on
        case moteur_on:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 2 
                    if( !IS_IN(fonctionelle) || cmd_contact==false)
                        {
                            NOTIFY_TRANSITION_STARTED("2");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.state_266.moteur_on");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.state_266.moteur_off");
                            state_266_subState = moteur_off;
                            state_266_active = moteur_off;
                            //#[ state Systeme.state_61.contact_on.state_266.moteur_off.(Entry) 
                            arreter();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("2");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_60_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60");
    NOTIFY_TRANSITION_STARTED("5");
    pedales_entDef();
    NOTIFY_TRANSITION_TERMINATED("5");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_60_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_60_active) {
        // State freinage_injection
        case freinage_injection:
        {
            res = freinage_injection_handleEvent();
        }
        break;
        // State acceleration
        case acceleration:
        {
            res = acceleration_handleEvent();
        }
        break;
        // State verification_distance_securite
        case verification_distance_securite:
        {
            res = verification_distance_securite_handleEvent();
        }
        break;
        // State suivi_distance_consigne
        case suivi_distance_consigne:
        {
            res = suivi_distance_consigne_handleEvent();
        }
        break;
        // State suivi_vitesse_consigne
        case suivi_vitesse_consigne:
        {
            res = suivi_vitesse_consigne_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::regulateur_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.regulateur");
    state_60_subState = regulateur;
    state_60_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_regulateur, "ROOT.Systeme.state_60.regulateur");
    NOTIFY_TRANSITION_STARTED("178");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.regulateur.verification_distance_securite");
    pushNullTransition();
    regulateur_subState = verification_distance_securite;
    state_60_active = verification_distance_securite;
    NOTIFY_TRANSITION_TERMINATED("178");
}

void _SysVehicule::regulateur_exit() {
    switch (regulateur_subState) {
        // State verification_distance_securite
        case verification_distance_securite:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur.verification_distance_securite");
        }
        break;
        // State suivi_distance_consigne
        case suivi_distance_consigne:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur.suivi_distance_consigne");
        }
        break;
        // State suivi_vitesse_consigne
        case suivi_vitesse_consigne:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur.suivi_vitesse_consigne");
        }
        break;
        default:
            break;
    }
    regulateur_subState = OMNonState;
    cancel(state_60_timeout);
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur");
}

IOxfReactive::TakeEventStatus _SysVehicule::regulateur_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == state_60_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("39");
                    regulateur_exit();
                    regulateur_entDef();
                    NOTIFY_TRANSITION_TERMINATED("39");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 10 
            if( IS_IN(mode_manuel)  ||  accelPedal >= 0.5)
                {
                    NOTIFY_TRANSITION_STARTED("10");
                    regulateur_exit();
                    pedales_entDef();
                    NOTIFY_TRANSITION_TERMINATED("10");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::verification_distance_securite_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            //## transition 179 
            if(distance_inter_voiture < distance_securite  &&  IS_IN(simulation_voiture_devant))
                {
                    NOTIFY_TRANSITION_STARTED("179");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur.verification_distance_securite");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.regulateur.suivi_distance_consigne");
                    regulateur_subState = suivi_distance_consigne;
                    state_60_active = suivi_distance_consigne;
                    //#[ state Systeme.state_60.regulateur.suivi_distance_consigne.(Entry) 
                    calcul_regulateur_distance();
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("179");
                    res = eventConsumed;
                }
            else
                {
                    //## transition 180 
                    if(distance_inter_voiture > distance_securite  ||  !IS_IN(simulation_voiture_devant))
                        {
                            NOTIFY_TRANSITION_STARTED("180");
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur.verification_distance_securite");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.regulateur.suivi_vitesse_consigne");
                            regulateur_subState = suivi_vitesse_consigne;
                            state_60_active = suivi_vitesse_consigne;
                            //#[ state Systeme.state_60.regulateur.suivi_vitesse_consigne.(Entry) 
                            calcul_regulateur_vitesse();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("180");
                            res = eventConsumed;
                        }
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = regulateur_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::suivi_vitesse_consigne_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    res = regulateur_handleEvent();
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::suivi_distance_consigne_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    res = regulateur_handleEvent();
    return res;
}

void _SysVehicule::pedales_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales");
    state_60_subState = pedales;
    NOTIFY_TRANSITION_STARTED("6");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.freinage_injection");
    pushNullTransition();
    pedales_subState = freinage_injection;
    state_60_active = freinage_injection;
    //#[ state Systeme.state_60.pedales.freinage_injection.(Entry) 
    freiner_injection(brakePedal);
    //#]
    pedales_timeout = scheduleTimeout(PARAM_SIMU_periode_pedales, "ROOT.Systeme.state_60.pedales.freinage_injection");
    NOTIFY_TRANSITION_TERMINATED("6");
}

IOxfReactive::TakeEventStatus _SysVehicule::pedales_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 9 
            if( IS_IN(mode_regulateur) &&  accelPedal < 0.5)
                {
                    NOTIFY_TRANSITION_STARTED("9");
                    switch (pedales_subState) {
                        // State freinage_injection
                        case freinage_injection:
                        {
                            popNullTransition();
                            cancel(pedales_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                        }
                        break;
                        // State acceleration
                        case acceleration:
                        {
                            popNullTransition();
                            cancel(pedales_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                        }
                        break;
                        default:
                            break;
                    }
                    pedales_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales");
                    regulateur_entDef();
                    NOTIFY_TRANSITION_TERMINATED("9");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::freinage_injection_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == pedales_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("41");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    pushNullTransition();
                    pedales_subState = freinage_injection;
                    state_60_active = freinage_injection;
                    //#[ state Systeme.state_60.pedales.freinage_injection.(Entry) 
                    freiner_injection(brakePedal);
                    //#]
                    pedales_timeout = scheduleTimeout(PARAM_SIMU_periode_pedales, "ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_TRANSITION_TERMINATED("41");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            //## transition 8 
            if(brakePedal < 0.5    && IS_IN(moteur_on)   && !(IS_IN(limiteur_effectif) && float_speed >=  vitesseConsigne + 0.5))
                {
                    NOTIFY_TRANSITION_STARTED("8");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.acceleration");
                    pushNullTransition();
                    pedales_subState = acceleration;
                    state_60_active = acceleration;
                    //#[ state Systeme.state_60.pedales.acceleration.(Entry) 
                    accelerer(accelPedal);
                    //#]
                    pedales_timeout = scheduleTimeout(PARAM_SIMU_periode_pedales, "ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_TRANSITION_TERMINATED("8");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = pedales_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::acceleration_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == pedales_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("40");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.acceleration");
                    pushNullTransition();
                    pedales_subState = acceleration;
                    state_60_active = acceleration;
                    //#[ state Systeme.state_60.pedales.acceleration.(Entry) 
                    accelerer(accelPedal);
                    //#]
                    pedales_timeout = scheduleTimeout(PARAM_SIMU_periode_pedales, "ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_TRANSITION_TERMINATED("40");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            //## transition 24 
            if(brakePedal >= 0.5 || IS_IN(moteur_off) || (IS_IN(limiteur_effectif) && float_speed >=  vitesseConsigne + 0.5))
                {
                    NOTIFY_TRANSITION_STARTED("24");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    pushNullTransition();
                    pedales_subState = freinage_injection;
                    state_60_active = freinage_injection;
                    //#[ state Systeme.state_60.pedales.freinage_injection.(Entry) 
                    freiner_injection(brakePedal);
                    //#]
                    pedales_timeout = scheduleTimeout(PARAM_SIMU_periode_pedales, "ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_TRANSITION_TERMINATED("24");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = pedales_handleEvent();
        }
    return res;
}

void _SysVehicule::state_278_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278");
    NOTIFY_TRANSITION_STARTED("177");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.radio_eteinte");
    state_278_subState = radio_eteinte;
    state_278_active = radio_eteinte;
    //#[ state Systeme.state_278.radio_eteinte.(Entry) 
    play_sound("stop");
    VOYANT_radio=false;
    cmd_radio=false;
    affichage_titre_musique = "";
    //#]
    NOTIFY_TRANSITION_TERMINATED("177");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_278_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_278_active) {
        // State priorite_radio
        case priorite_radio:
        {
            res = priorite_radio_processEvent();
        }
        break;
        // State priorite_appel
        case priorite_appel:
        {
            res = priorite_appel_handleEvent();
        }
        break;
        // State priorite_sonnerie
        case priorite_sonnerie:
        {
            res = priorite_sonnerie_handleEvent();
        }
        break;
        // State radio_eteinte
        case radio_eteinte:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 197 
                    if(IS_IN(contact_on) && niveau_batterie > 0)
                        {
                            NOTIFY_TRANSITION_STARTED("197");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.radio_eteinte");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.radio_prete");
                            state_278_subState = radio_prete;
                            state_278_active = radio_prete;
                            NOTIFY_TRANSITION_TERMINATED("197");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State radio_prete
        case radio_prete:
        {
            res = radio_prete_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::radio_prete_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 196 
            if(cmd_radio==true)
                {
                    NOTIFY_TRANSITION_STARTED("196");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.radio_prete");
                    contact_radio_actif_entDef();
                    NOTIFY_TRANSITION_TERMINATED("196");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::contact_radio_actif_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif");
    state_278_subState = contact_radio_actif;
    contact_radio_actifEntDef();
}

void _SysVehicule::contact_radio_actifEntDef() {
    NOTIFY_TRANSITION_STARTED("159");
    priorite_radio_entDef();
    NOTIFY_TRANSITION_TERMINATED("159");
}

IOxfReactive::TakeEventStatus _SysVehicule::contact_radio_actif_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 176 
            if(IS_IN(contact_off) || niveau_batterie <=0)
                {
                    NOTIFY_TRANSITION_STARTED("176");
                    switch (contact_radio_actif_subState) {
                        // State priorite_radio
                        case priorite_radio:
                        {
                            priorite_radio_exit();
                        }
                        break;
                        // State priorite_appel
                        case priorite_appel:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
                        }
                        break;
                        // State priorite_sonnerie
                        case priorite_sonnerie:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
                        }
                        break;
                        default:
                            break;
                    }
                    contact_radio_actif_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.radio_eteinte");
                    state_278_subState = radio_eteinte;
                    state_278_active = radio_eteinte;
                    //#[ state Systeme.state_278.radio_eteinte.(Entry) 
                    play_sound("stop");
                    VOYANT_radio=false;
                    cmd_radio=false;
                    affichage_titre_musique = "";
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("176");
                    res = eventConsumed;
                }
            else
                {
                    //## transition 195 
                    if(cmd_radio==false)
                        {
                            NOTIFY_TRANSITION_STARTED("195");
                            switch (contact_radio_actif_subState) {
                                // State priorite_radio
                                case priorite_radio:
                                {
                                    priorite_radio_exit();
                                }
                                break;
                                // State priorite_appel
                                case priorite_appel:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
                                }
                                break;
                                // State priorite_sonnerie
                                case priorite_sonnerie:
                                {
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
                                }
                                break;
                                default:
                                    break;
                            }
                            contact_radio_actif_subState = OMNonState;
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.radio_eteinte");
                            state_278_subState = radio_eteinte;
                            state_278_active = radio_eteinte;
                            //#[ state Systeme.state_278.radio_eteinte.(Entry) 
                            play_sound("stop");
                            VOYANT_radio=false;
                            cmd_radio=false;
                            affichage_titre_musique = "";
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("195");
                            res = eventConsumed;
                        }
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::priorite_sonnerie_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 150 
            if(IS_IN(appel_en_cours_kit))
                {
                    NOTIFY_TRANSITION_STARTED("150");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
                    contact_radio_actif_subState = priorite_appel;
                    state_278_active = priorite_appel;
                    //#[ state Systeme.state_278.contact_radio_actif.priorite_appel.(Entry) 
                    play_sound("stop");
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("150");
                    res = eventConsumed;
                }
            else
                {
                    //## transition 171 
                    if(!( sonnerie_en_cours))
                        {
                            NOTIFY_TRANSITION_STARTED("171");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio");
                            contact_radio_actif_subState = priorite_radio;
                            state_278_active = priorite_radio;
                            state_260_entDef();
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active");
                            state_233_subState = radio_active;
                            if(radio_active_lastState != OMNonState)
                                {
                                    radio_active_subState = radio_active_lastState;
                                    switch (radio_active_subState) {
                                        // State musique_1
                                        case musique_1:
                                        {
                                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                                            radio_active_subState = musique_1;
                                            state_233_active = musique_1;
                                            //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1.(Entry) 
                                            affichage_titre_musique = "musique_1";
                                            play_sound("musique_1.wav");
                                            //#]
                                            radio_active_timeout = scheduleTimeout(60*4+0-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                                        }
                                        break;
                                        // State musique_2
                                        case musique_2:
                                        {
                                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                                            radio_active_subState = musique_2;
                                            state_233_active = musique_2;
                                            //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2.(Entry) 
                                            affichage_titre_musique = "musique_2";
                                            play_sound("musique_2.wav");
                                            //#]
                                            radio_active_timeout = scheduleTimeout(60*2+20-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                                        }
                                        break;
                                        // State musique_3
                                        case musique_3:
                                        {
                                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                                            radio_active_subState = musique_3;
                                            state_233_active = musique_3;
                                            //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3.(Entry) 
                                            affichage_titre_musique = "musique_3";
                                            play_sound("musique_3.wav");
                                            //#]
                                            radio_active_timeout = scheduleTimeout(60*1+16-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                                        }
                                        break;
                                        default:
                                            break;
                                    }
                                }
                            NOTIFY_TRANSITION_TERMINATED("171");
                            res = eventConsumed;
                        }
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = contact_radio_actif_handleEvent();
        }
    return res;
}

void _SysVehicule::priorite_radio_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio");
    contact_radio_actif_subState = priorite_radio;
    state_278_active = priorite_radio;
    state_233_entDef();
    state_260_entDef();
}

void _SysVehicule::priorite_radio_exit() {
    switch (state_233_subState) {
        // State radio_active
        case radio_active:
        {
            radio_active_exit();
        }
        break;
        // State lancement_radio
        case lancement_radio:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.lancement_radio");
        }
        break;
        default:
            break;
    }
    state_233_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233");
    switch (state_260_subState) {
        // State attente_btn_radio
        case attente_btn_radio:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.attente_btn_radio");
        }
        break;
        // State appui_btn_radio
        case appui_btn_radio:
        {
            cancel(state_260_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.appui_btn_radio");
        }
        break;
        default:
            break;
    }
    state_260_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio");
}

IOxfReactive::TakeEventStatus _SysVehicule::priorite_radio_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_233
    if(state_233_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(priorite_radio))
                {
                    return res;
                }
        }
    // State state_260
    if(state_260_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(priorite_radio))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = priorite_radio_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::priorite_radio_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 185 
            if(sonnerie_en_cours)
                {
                    NOTIFY_TRANSITION_STARTED("185");
                    priorite_radio_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
                    contact_radio_actif_subState = priorite_sonnerie;
                    state_278_active = priorite_sonnerie;
                    NOTIFY_TRANSITION_TERMINATED("185");
                    res = eventConsumed;
                }
            else
                {
                    //## transition 198 
                    if(IS_IN(appel_en_cours_kit))
                        {
                            NOTIFY_TRANSITION_STARTED("198");
                            priorite_radio_exit();
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
                            contact_radio_actif_subState = priorite_appel;
                            state_278_active = priorite_appel;
                            //#[ state Systeme.state_278.contact_radio_actif.priorite_appel.(Entry) 
                            play_sound("stop");
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("198");
                            res = eventConsumed;
                        }
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = contact_radio_actif_handleEvent();
        }
    return res;
}

void _SysVehicule::state_260_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260");
    NOTIFY_TRANSITION_STARTED("156");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.attente_btn_radio");
    state_260_subState = attente_btn_radio;
    state_260_active = attente_btn_radio;
    NOTIFY_TRANSITION_TERMINATED("156");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_260_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_260_active) {
        // State attente_btn_radio
        case attente_btn_radio:
        {
            if(IS_EVENT_TYPE_OF(ev_btn_radio_skip__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("157");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.attente_btn_radio");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.appui_btn_radio");
                    state_260_subState = appui_btn_radio;
                    state_260_active = appui_btn_radio;
                    state_260_timeout = scheduleTimeout(500, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.appui_btn_radio");
                    NOTIFY_TRANSITION_TERMINATED("157");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State appui_btn_radio
        case appui_btn_radio:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_260_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("158");
                            cancel(state_260_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.appui_btn_radio");
                            //#[ transition 158 
                            GEN(ev_skip_musique);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.attente_btn_radio");
                            state_260_subState = attente_btn_radio;
                            state_260_active = attente_btn_radio;
                            NOTIFY_TRANSITION_TERMINATED("158");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_233_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233");
    NOTIFY_TRANSITION_STARTED("149");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.lancement_radio");
    state_233_subState = lancement_radio;
    state_233_active = lancement_radio;
    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.lancement_radio.(Entry) 
    affichage_titre_musique = "Press PLAY";
    VOYANT_radio=true;
    //#]
    NOTIFY_TRANSITION_TERMINATED("149");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_233_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_233_active) {
        // State musique_1
        case musique_1:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == radio_active_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("210");
                            cancel(radio_active_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                            radio_active_subState = musique_2;
                            state_233_active = musique_2;
                            //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2.(Entry) 
                            affichage_titre_musique = "musique_2";
                            play_sound("musique_2.wav");
                            //#]
                            radio_active_timeout = scheduleTimeout(60*2+20-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                            NOTIFY_TRANSITION_TERMINATED("210");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(ev_skip_musique__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("153");
                    cancel(radio_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                    radio_active_subState = musique_2;
                    state_233_active = musique_2;
                    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2.(Entry) 
                    affichage_titre_musique = "musique_2";
                    play_sound("musique_2.wav");
                    //#]
                    radio_active_timeout = scheduleTimeout(60*2+20-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                    NOTIFY_TRANSITION_TERMINATED("153");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State musique_2
        case musique_2:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == radio_active_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("211");
                            cancel(radio_active_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                            radio_active_subState = musique_3;
                            state_233_active = musique_3;
                            //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3.(Entry) 
                            affichage_titre_musique = "musique_3";
                            play_sound("musique_3.wav");
                            //#]
                            radio_active_timeout = scheduleTimeout(60*1+16-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                            NOTIFY_TRANSITION_TERMINATED("211");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(ev_skip_musique__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("154");
                    cancel(radio_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                    radio_active_subState = musique_3;
                    state_233_active = musique_3;
                    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3.(Entry) 
                    affichage_titre_musique = "musique_3";
                    play_sound("musique_3.wav");
                    //#]
                    radio_active_timeout = scheduleTimeout(60*1+16-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                    NOTIFY_TRANSITION_TERMINATED("154");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State musique_3
        case musique_3:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == radio_active_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("212");
                            cancel(radio_active_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                            radio_active_subState = musique_1;
                            state_233_active = musique_1;
                            //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1.(Entry) 
                            affichage_titre_musique = "musique_1";
                            play_sound("musique_1.wav");
                            //#]
                            radio_active_timeout = scheduleTimeout(60*4+0-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                            NOTIFY_TRANSITION_TERMINATED("212");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(ev_skip_musique__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("155");
                    cancel(radio_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                    radio_active_subState = musique_1;
                    state_233_active = musique_1;
                    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1.(Entry) 
                    affichage_titre_musique = "musique_1";
                    play_sound("musique_1.wav");
                    //#]
                    radio_active_timeout = scheduleTimeout(60*4+0-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                    NOTIFY_TRANSITION_TERMINATED("155");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State lancement_radio
        case lancement_radio:
        {
            if(IS_EVENT_TYPE_OF(ev_btn_start_radio__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("160");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.lancement_radio");
                    radio_active_entDef();
                    NOTIFY_TRANSITION_TERMINATED("160");
                    res = eventConsumed;
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::radio_active_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active");
    state_233_subState = radio_active;
    NOTIFY_TRANSITION_STARTED("152");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
    radio_active_subState = musique_1;
    state_233_active = musique_1;
    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1.(Entry) 
    affichage_titre_musique = "musique_1";
    play_sound("musique_1.wav");
    //#]
    radio_active_timeout = scheduleTimeout(60*4+0-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
    NOTIFY_TRANSITION_TERMINATED("152");
}

void _SysVehicule::radio_active_exit() {
    radio_active_lastState = radio_active_subState;
    switch (radio_active_subState) {
        // State musique_1
        case musique_1:
        {
            cancel(radio_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
            radio_active_lastState = musique_1;
        }
        break;
        // State musique_2
        case musique_2:
        {
            cancel(radio_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
            radio_active_lastState = musique_2;
        }
        break;
        // State musique_3
        case musique_3:
        {
            cancel(radio_active_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
            radio_active_lastState = musique_3;
        }
        break;
        default:
            break;
    }
    radio_active_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active");
}

IOxfReactive::TakeEventStatus _SysVehicule::priorite_appel_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 151 
            if(!(IS_IN(appel_en_cours_kit)))
                {
                    NOTIFY_TRANSITION_STARTED("151");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio");
                    contact_radio_actif_subState = priorite_radio;
                    state_278_active = priorite_radio;
                    state_260_entDef();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active");
                    state_233_subState = radio_active;
                    if(radio_active_lastState != OMNonState)
                        {
                            radio_active_subState = radio_active_lastState;
                            switch (radio_active_subState) {
                                // State musique_1
                                case musique_1:
                                {
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                                    radio_active_subState = musique_1;
                                    state_233_active = musique_1;
                                    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1.(Entry) 
                                    affichage_titre_musique = "musique_1";
                                    play_sound("musique_1.wav");
                                    //#]
                                    radio_active_timeout = scheduleTimeout(60*4+0-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
                                }
                                break;
                                // State musique_2
                                case musique_2:
                                {
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                                    radio_active_subState = musique_2;
                                    state_233_active = musique_2;
                                    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2.(Entry) 
                                    affichage_titre_musique = "musique_2";
                                    play_sound("musique_2.wav");
                                    //#]
                                    radio_active_timeout = scheduleTimeout(60*2+20-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
                                }
                                break;
                                // State musique_3
                                case musique_3:
                                {
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                                    radio_active_subState = musique_3;
                                    state_233_active = musique_3;
                                    //#[ state Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3.(Entry) 
                                    affichage_titre_musique = "musique_3";
                                    play_sound("musique_3.wav");
                                    //#]
                                    radio_active_timeout = scheduleTimeout(60*1+16-1, "ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
                                }
                                break;
                                default:
                                    break;
                            }
                        }
                    NOTIFY_TRANSITION_TERMINATED("151");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = contact_radio_actif_handleEvent();
        }
    return res;
}

void _SysVehicule::state_275_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_275");
    NOTIFY_TRANSITION_STARTED("184");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_275.reglage_voiture_devant");
    state_275_subState = reglage_voiture_devant;
    state_275_active = reglage_voiture_devant;
    //#[ state Systeme.state_275.reglage_voiture_devant.(Entry) 
    distance_inter_voiture = 0;
    //#]
    NOTIFY_TRANSITION_TERMINATED("184");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_275_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_275_active) {
        // State loop_simulation
        case loop_simulation:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 181 
                    if(cmd_simulation_voiture_devant==true)
                        {
                            NOTIFY_TRANSITION_STARTED("181");
                            //#[ state Systeme.state_275.simulation_voiture_devant.loop_simulation.(Exit) 
                            distance_inter_voiture = distance_voiture_devant - distance;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_275.simulation_voiture_devant.loop_simulation");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_275.simulation_voiture_devant.loop_simulation");
                            simulation_voiture_devant_subState = loop_simulation;
                            state_275_active = loop_simulation;
                            //#[ state Systeme.state_275.simulation_voiture_devant.loop_simulation.(Entry) 
                            calcul_distance_voiture_devant();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("181");
                            res = eventConsumed;
                        }
                }
            
            if(res == eventNotConsumed)
                {
                    res = simulation_voiture_devant_handleEvent();
                }
        }
        break;
        // State reglage_voiture_devant
        case reglage_voiture_devant:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 182 
                    if(cmd_simulation_voiture_devant==true)
                        {
                            NOTIFY_TRANSITION_STARTED("182");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_275.reglage_voiture_devant");
                            simulation_voiture_devant_entDef();
                            NOTIFY_TRANSITION_TERMINATED("182");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::simulation_voiture_devant_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_275.simulation_voiture_devant");
    state_275_subState = simulation_voiture_devant;
    //#[ state Systeme.state_275.simulation_voiture_devant.(Entry) 
    distance_voiture_devant = distance + distance_inter_voiture;
    //#]
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_275.simulation_voiture_devant.loop_simulation");
    simulation_voiture_devant_subState = loop_simulation;
    state_275_active = loop_simulation;
    //#[ state Systeme.state_275.simulation_voiture_devant.loop_simulation.(Entry) 
    calcul_distance_voiture_devant();
    //#]
}

void _SysVehicule::simulation_voiture_devant_exit() {
    // State loop_simulation
    if(simulation_voiture_devant_subState == loop_simulation)
        {
            //#[ state Systeme.state_275.simulation_voiture_devant.loop_simulation.(Exit) 
            distance_inter_voiture = distance_voiture_devant - distance;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_275.simulation_voiture_devant.loop_simulation");
        }
    simulation_voiture_devant_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_275.simulation_voiture_devant");
}

IOxfReactive::TakeEventStatus _SysVehicule::simulation_voiture_devant_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 183 
            if(cmd_simulation_voiture_devant == false)
                {
                    NOTIFY_TRANSITION_STARTED("183");
                    simulation_voiture_devant_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_275.reglage_voiture_devant");
                    state_275_subState = reglage_voiture_devant;
                    state_275_active = reglage_voiture_devant;
                    //#[ state Systeme.state_275.reglage_voiture_devant.(Entry) 
                    distance_inter_voiture = 0;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("183");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_252_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252");
    NOTIFY_TRANSITION_STARTED("27");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.fonctionelle");
    state_252_subState = fonctionelle;
    state_252_active = fonctionelle;
    NOTIFY_TRANSITION_TERMINATED("27");
}

void _SysVehicule::state_252_exit() {
    switch (state_252_subState) {
        // State fonctionelle
        case fonctionelle:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.fonctionelle");
        }
        break;
        // State panne_carburant
        case panne_carburant:
        {
            //#[ state Systeme.state_252.panne_carburant.(Exit) 
            carburant_faible = false;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.panne_carburant");
        }
        break;
        // State panne_batterie
        case panne_batterie:
        {
            //#[ state Systeme.state_252.panne_batterie.(Exit) 
            batterie_faible = false;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.panne_batterie");
        }
        break;
        // State remplir_carburant
        case remplir_carburant:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.remplir_carburant");
        }
        break;
        // State depanner_batterie
        case depanner_batterie:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.depanner_batterie");
        }
        break;
        default:
            break;
    }
    state_252_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_252");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_252_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_252_active) {
        // State fonctionelle
        case fonctionelle:
        {
            if(IS_EVENT_TYPE_OF(ev_remplir_carburant__MonPkg_id))
                {
                    //## transition 26 
                    if( speed == 0 && IS_IN(contact_off))
                        {
                            NOTIFY_TRANSITION_STARTED("26");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.fonctionelle");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.remplir_carburant");
                            pushNullTransition();
                            state_252_subState = remplir_carburant;
                            state_252_active = remplir_carburant;
                            //#[ state Systeme.state_252.remplir_carburant.(Entry) 
                            ex_remplir_carburant();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("26");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 18 
                    if( reservoir_carburant  < SEUIL_carburant)
                        {
                            NOTIFY_TRANSITION_STARTED("18");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.fonctionelle");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.panne_carburant");
                            state_252_subState = panne_carburant;
                            state_252_active = panne_carburant;
                            //#[ state Systeme.state_252.panne_carburant.(Entry) 
                            carburant_faible = true;
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("18");
                            res = eventConsumed;
                        }
                    else
                        {
                            //## transition 19 
                            if( niveau_batterie  < SEUIL_batterie)
                                {
                                    NOTIFY_TRANSITION_STARTED("19");
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.fonctionelle");
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.panne_batterie");
                                    state_252_subState = panne_batterie;
                                    state_252_active = panne_batterie;
                                    //#[ state Systeme.state_252.panne_batterie.(Entry) 
                                    batterie_faible = true;
                                    //#]
                                    NOTIFY_TRANSITION_TERMINATED("19");
                                    res = eventConsumed;
                                }
                        }
                }
            
            
        }
        break;
        // State panne_carburant
        case panne_carburant:
        {
            if(IS_EVENT_TYPE_OF(ev_remplir_carburant__MonPkg_id))
                {
                    //## transition 20 
                    if(speed == 0 && IS_IN(contact_off))
                        {
                            NOTIFY_TRANSITION_STARTED("20");
                            //#[ state Systeme.state_252.panne_carburant.(Exit) 
                            carburant_faible = false;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.panne_carburant");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.remplir_carburant");
                            pushNullTransition();
                            state_252_subState = remplir_carburant;
                            state_252_active = remplir_carburant;
                            //#[ state Systeme.state_252.remplir_carburant.(Entry) 
                            ex_remplir_carburant();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("20");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State panne_batterie
        case panne_batterie:
        {
            if(IS_EVENT_TYPE_OF(ev_depanner_batterie__MonPkg_id))
                {
                    //## transition 21 
                    if(speed == 0 && IS_IN(contact_off))
                        {
                            NOTIFY_TRANSITION_STARTED("21");
                            //#[ state Systeme.state_252.panne_batterie.(Exit) 
                            batterie_faible = false;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.panne_batterie");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.depanner_batterie");
                            pushNullTransition();
                            state_252_subState = depanner_batterie;
                            state_252_active = depanner_batterie;
                            //#[ state Systeme.state_252.depanner_batterie.(Entry) 
                            ex_depanner_batterie();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("21");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State remplir_carburant
        case remplir_carburant:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    NOTIFY_TRANSITION_STARTED("23");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.remplir_carburant");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.fonctionelle");
                    state_252_subState = fonctionelle;
                    state_252_active = fonctionelle;
                    NOTIFY_TRANSITION_TERMINATED("23");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State depanner_batterie
        case depanner_batterie:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    NOTIFY_TRANSITION_STARTED("22");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_252.depanner_batterie");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_252.fonctionelle");
                    state_252_subState = fonctionelle;
                    state_252_active = fonctionelle;
                    NOTIFY_TRANSITION_TERMINATED("22");
                    res = eventConsumed;
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_206_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_206");
    NOTIFY_TRANSITION_STARTED("138");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_206.sms_exterrieur");
    state_206_subState = sms_exterrieur;
    state_206_active = sms_exterrieur;
    NOTIFY_TRANSITION_TERMINATED("138");
}

void _SysVehicule::state_206_exit() {
    // State sms_exterrieur
    if(state_206_subState == sms_exterrieur)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_206.sms_exterrieur");
        }
    state_206_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_206");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_206_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State sms_exterrieur
    if(state_206_active == sms_exterrieur)
        {
            if(IS_EVENT_TYPE_OF(ev_btn_SIM_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("126");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_206.sms_exterrieur");
                    //#[ transition 126 
                    GEN(ev_SIM_envoi_sms);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_206.sms_exterrieur");
                    state_206_subState = sms_exterrieur;
                    state_206_active = sms_exterrieur;
                    NOTIFY_TRANSITION_TERMINATED("126");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_166_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166");
    NOTIFY_TRANSITION_STARTED("83");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.telephone_deconnecte");
    state_166_subState = telephone_deconnecte;
    state_166_active = telephone_deconnecte;
    //#[ state Systeme.state_166.telephone_deconnecte.(Entry) 
    envoi_batterie_kit(0);
    //#]
    NOTIFY_TRANSITION_TERMINATED("83");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_166_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_166_active) {
        // State controle_telephone_connecte
        case controle_telephone_connecte:
        {
            res = controle_telephone_connecte_processEvent();
        }
        break;
        // State telephone_deconnecte
        case telephone_deconnecte:
        {
            res = telephone_deconnecte_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::telephone_deconnecteTakeEVAL() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    //## transition 84 
    if(IS_IN(telephone_connecte))
        {
            NOTIFY_TRANSITION_STARTED("84");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.telephone_deconnecte");
            controle_telephone_connecte_entDef();
            NOTIFY_TRANSITION_TERMINATED("84");
            res = eventConsumed;
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::telephone_deconnecte_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            res = telephone_deconnecteTakeEVAL();
        }
    
    
    return res;
}

void _SysVehicule::controle_telephone_connecte_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte");
    state_166_subState = controle_telephone_connecte;
    state_166_active = controle_telephone_connecte;
    state_130_entDef();
    state_131_entDef();
    state_173_entDef();
    state_174_entDef();
    state_198_entDef();
    state_199_entDef();
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_204");
}

void _SysVehicule::controle_telephone_connecte_exit() {
    state_130_exit();
    switch (state_131_subState) {
        // State attente_redirection_appel
        case attente_redirection_appel:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
        }
        break;
        // State appel_en_cours_kit
        case appel_en_cours_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit");
        }
        break;
        // State gestion_sonnerie_kit
        case gestion_sonnerie_kit:
        {
            gestion_sonnerie_kit_exit();
        }
        break;
        default:
            break;
    }
    state_131_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131");
    state_173_exit();
    state_174_exit();
    state_198_exit();
    switch (state_199_subState) {
        // State messagerie_kit
        case messagerie_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
        }
        break;
        // State init_redirection_sms_kit
        case init_redirection_sms_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.init_redirection_sms_kit");
        }
        break;
        // State lire_message_kit
        case lire_message_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.lire_message_kit");
        }
        break;
        default:
            break;
    }
    state_199_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199");
    state_204_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_204");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte");
}

IOxfReactive::TakeEventStatus _SysVehicule::controle_telephone_connecteTakeEVAL() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    //## transition 85 
    if(!(IS_IN(telephone_connecte)))
        {
            NOTIFY_TRANSITION_STARTED("85");
            controle_telephone_connecte_exit();
            //#[ transition 85 
            VOYANT_kit(false);
            nbr_sms_kit=0;
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.telephone_deconnecte");
            state_166_subState = telephone_deconnecte;
            state_166_active = telephone_deconnecte;
            //#[ state Systeme.state_166.telephone_deconnecte.(Entry) 
            envoi_batterie_kit(0);
            //#]
            NOTIFY_TRANSITION_TERMINATED("85");
            res = eventConsumed;
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::controle_telephone_connecte_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_130
    if(state_130_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(controle_telephone_connecte))
                {
                    return res;
                }
        }
    // State state_131
    if(state_131_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(controle_telephone_connecte))
                {
                    return res;
                }
        }
    // State state_173
    if(state_173_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(controle_telephone_connecte))
                {
                    return res;
                }
        }
    // State state_174
    if(state_174_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(controle_telephone_connecte))
                {
                    return res;
                }
        }
    // State state_198
    if(state_198_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(controle_telephone_connecte))
                {
                    return res;
                }
        }
    // State state_199
    if(state_199_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(controle_telephone_connecte))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = controle_telephone_connecte_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::controle_telephone_connecte_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            res = controle_telephone_connecteTakeEVAL();
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::state_204_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    return res;
}

void _SysVehicule::state_199_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199");
    NOTIFY_TRANSITION_STARTED("133");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.init_redirection_sms_kit");
    state_199_subState = init_redirection_sms_kit;
    state_199_active = init_redirection_sms_kit;
    NOTIFY_TRANSITION_TERMINATED("133");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_199_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_199_active) {
        // State messagerie_kit
        case messagerie_kit:
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_sms_nouveau_kit__MonPkg_id))
                {
                    OMSETPARAMS(ev_telephone_sms_nouveau_kit);
                    NOTIFY_TRANSITION_STARTED("139");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
                    //#[ transition 139 
                    nbr_sms_kit=params->sms_telephone;
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
                    state_199_subState = messagerie_kit;
                    state_199_active = messagerie_kit;
                    //#[ state Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit.(Entry) 
                    VOYANT_kit_sms =(nbr_sms_kit>0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("139");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(ev_kit_tentative_lire_sms__MonPkg_id))
                {
                    //## transition 136 
                    if(speed<=0)
                        {
                            NOTIFY_TRANSITION_STARTED("136");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.lire_message_kit");
                            state_199_subState = lire_message_kit;
                            state_199_active = lire_message_kit;
                            //#[ state Systeme.state_166.controle_telephone_connecte.state_199.lire_message_kit.(Entry) 
                            GEN(ev_kit_lire_sms);
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("136");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State init_redirection_sms_kit
        case init_redirection_sms_kit:
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_sms_historique_kit__MonPkg_id))
                {
                    OMSETPARAMS(ev_telephone_sms_historique_kit);
                    NOTIFY_TRANSITION_STARTED("135");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.init_redirection_sms_kit");
                    //#[ transition 135 
                    nbr_sms_kit=params->historique;
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
                    state_199_subState = messagerie_kit;
                    state_199_active = messagerie_kit;
                    //#[ state Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit.(Entry) 
                    VOYANT_kit_sms =(nbr_sms_kit>0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("135");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State lire_message_kit
        case lire_message_kit:
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_actualisation_sms_kit__MonPkg_id))
                {
                    OMSETPARAMS(ev_telephone_actualisation_sms_kit);
                    NOTIFY_TRANSITION_STARTED("137");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.lire_message_kit");
                    //#[ transition 137 
                    nbr_sms_kit=params->sms_tel;
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
                    state_199_subState = messagerie_kit;
                    state_199_active = messagerie_kit;
                    //#[ state Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit.(Entry) 
                    VOYANT_kit_sms =(nbr_sms_kit>0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("137");
                    res = eventConsumed;
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_198_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_198");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_198.gestion_btn_lire_sms_kit");
    state_198_subState = gestion_btn_lire_sms_kit;
    state_198_active = gestion_btn_lire_sms_kit;
}

void _SysVehicule::state_198_exit() {
    // State gestion_btn_lire_sms_kit
    if(state_198_subState == gestion_btn_lire_sms_kit)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_198.gestion_btn_lire_sms_kit");
        }
    state_198_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_198");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_198_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State gestion_btn_lire_sms_kit
    if(state_198_active == gestion_btn_lire_sms_kit)
        {
            if(IS_EVENT_TYPE_OF(ev_btn_kit_lire_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("134");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_198.gestion_btn_lire_sms_kit");
                    //#[ transition 134 
                    GEN(ev_kit_tentative_lire_sms);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_198.gestion_btn_lire_sms_kit");
                    state_198_subState = gestion_btn_lire_sms_kit;
                    state_198_active = gestion_btn_lire_sms_kit;
                    NOTIFY_TRANSITION_TERMINATED("134");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_174_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_174");
    NOTIFY_TRANSITION_STARTED("115");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_174.gestion_btn_decrocher_kit");
    state_174_subState = gestion_btn_decrocher_kit;
    state_174_active = gestion_btn_decrocher_kit;
    NOTIFY_TRANSITION_TERMINATED("115");
}

void _SysVehicule::state_174_exit() {
    // State gestion_btn_decrocher_kit
    if(state_174_subState == gestion_btn_decrocher_kit)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_174.gestion_btn_decrocher_kit");
        }
    state_174_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_174");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_174_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State gestion_btn_decrocher_kit
    if(state_174_active == gestion_btn_decrocher_kit)
        {
            if(IS_EVENT_TYPE_OF(ev_btn_kit_decrocher__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("116");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_174.gestion_btn_decrocher_kit");
                    //#[ transition 116 
                    GEN(ev_kit_decrocher);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_174.gestion_btn_decrocher_kit");
                    state_174_subState = gestion_btn_decrocher_kit;
                    state_174_active = gestion_btn_decrocher_kit;
                    NOTIFY_TRANSITION_TERMINATED("116");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_173_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_173");
    NOTIFY_TRANSITION_STARTED("113");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_173.gestion_btn_raccrocher_kit");
    state_173_subState = gestion_btn_raccrocher_kit;
    state_173_active = gestion_btn_raccrocher_kit;
    NOTIFY_TRANSITION_TERMINATED("113");
}

void _SysVehicule::state_173_exit() {
    // State gestion_btn_raccrocher_kit
    if(state_173_subState == gestion_btn_raccrocher_kit)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_173.gestion_btn_raccrocher_kit");
        }
    state_173_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_173");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_173_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State gestion_btn_raccrocher_kit
    if(state_173_active == gestion_btn_raccrocher_kit)
        {
            if(IS_EVENT_TYPE_OF(ev_btn_kit_raccrocher__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("114");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_173.gestion_btn_raccrocher_kit");
                    //#[ transition 114 
                    GEN(ev_kit_raccrocher);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_173.gestion_btn_raccrocher_kit");
                    state_173_subState = gestion_btn_raccrocher_kit;
                    state_173_active = gestion_btn_raccrocher_kit;
                    NOTIFY_TRANSITION_TERMINATED("114");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_131_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131");
    NOTIFY_TRANSITION_STARTED("89");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
    state_131_subState = attente_redirection_appel;
    state_131_active = attente_redirection_appel;
    NOTIFY_TRANSITION_TERMINATED("89");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_131_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_131_active) {
        // State attente_redirection_appel
        case attente_redirection_appel:
        {
            res = attente_redirection_appel_handleEvent();
        }
        break;
        // State appel_en_cours_kit
        case appel_en_cours_kit:
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_appel_termine_kit__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("120");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit");
                    //#[ transition 120 
                    
                    VOYANT_kit_appel=false;
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
                    state_131_subState = attente_redirection_appel;
                    state_131_active = attente_redirection_appel;
                    NOTIFY_TRANSITION_TERMINATED("120");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State gestion_sonnerie_kit
        case gestion_sonnerie_kit:
        {
            res = gestion_sonnerie_kit_processEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::gestion_sonnerie_kit_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit");
    state_131_subState = gestion_sonnerie_kit;
    state_131_active = gestion_sonnerie_kit;
    gestion_sonnerie_kit_gestion_sonnerie_kit_entDef();
    gestion_sonnerie_kit_state_240_entDef();
}

void _SysVehicule::gestion_sonnerie_kit_exit() {
    gestion_sonnerie_kit_gestion_sonnerie_kit_exit();
    gestion_sonnerie_kit_state_240_exit();
    //#[ state Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.(Exit) 
    play_sound("stop");
    //#]
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit");
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_kit_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State gestion_sonnerie_kit
    if(gestion_sonnerie_kit_gestion_sonnerie_kit_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_sonnerie_kit))
                {
                    return res;
                }
        }
    // State state_240
    if(gestion_sonnerie_kit_state_240_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_sonnerie_kit))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = gestion_sonnerie_kit_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_kit_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_btn_kit_raccrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("121");
            gestion_sonnerie_kit_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
            state_131_subState = attente_redirection_appel;
            state_131_active = attente_redirection_appel;
            NOTIFY_TRANSITION_TERMINATED("121");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_telephone_fin_sonnerie_kit__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("175");
            gestion_sonnerie_kit_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
            state_131_subState = attente_redirection_appel;
            state_131_active = attente_redirection_appel;
            NOTIFY_TRANSITION_TERMINATED("175");
            res = eventConsumed;
        }
    
    
    return res;
}

void _SysVehicule::gestion_sonnerie_kit_state_240_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240");
    NOTIFY_TRANSITION_STARTED("168");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit");
    gestion_sonnerie_kit_state_240_subState = sonnerie_sonore_kit;
    gestion_sonnerie_kit_state_240_active = sonnerie_sonore_kit;
    //#[ state Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit.(Entry) 
    play_sound("sonnerie2.wav");
    //#]
    NOTIFY_TRANSITION_TERMINATED("168");
}

void _SysVehicule::gestion_sonnerie_kit_state_240_exit() {
    // State sonnerie_sonore_kit
    if(gestion_sonnerie_kit_state_240_subState == sonnerie_sonore_kit)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit");
        }
    gestion_sonnerie_kit_state_240_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240");
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_kit_state_240_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State sonnerie_sonore_kit
    if(gestion_sonnerie_kit_state_240_active == sonnerie_sonore_kit)
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_sonnerie_kit__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("167");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit");
                    gestion_sonnerie_kit_state_240_subState = sonnerie_sonore_kit;
                    gestion_sonnerie_kit_state_240_active = sonnerie_sonore_kit;
                    //#[ state Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit.(Entry) 
                    play_sound("sonnerie2.wav");
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("167");
                    res = eventConsumed;
                }
            
            if(res == eventNotConsumed)
                {
                    res = gestion_sonnerie_kit_state_240_handleEvent();
                }
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_kit_state_240_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_telephone_appel_transfere_kit__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("119");
            gestion_sonnerie_kit_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit");
            state_131_subState = appel_en_cours_kit;
            state_131_active = appel_en_cours_kit;
            //#[ state Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit.(Entry) 
            VOYANT_kit_appel =true;
            //#]
            NOTIFY_TRANSITION_TERMINATED("119");
            res = eventConsumed;
        }
    
    return res;
}

void _SysVehicule::gestion_sonnerie_kit_gestion_sonnerie_kit_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit");
    NOTIFY_TRANSITION_STARTED("169");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit");
    gestion_sonnerie_kit_gestion_sonnerie_kit_subState = sonnerie_lumineuse_kit;
    gestion_sonnerie_kit_gestion_sonnerie_kit_active = sonnerie_lumineuse_kit;
    //#[ state Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit.(Entry) 
    VOYANT_kit_sonnerie=!VOYANT_kit_sonnerie;
    
    //#]
    NOTIFY_TRANSITION_TERMINATED("169");
}

void _SysVehicule::gestion_sonnerie_kit_gestion_sonnerie_kit_exit() {
    // State sonnerie_lumineuse_kit
    if(gestion_sonnerie_kit_gestion_sonnerie_kit_subState == sonnerie_lumineuse_kit)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit");
        }
    gestion_sonnerie_kit_gestion_sonnerie_kit_subState = OMNonState;
    //#[ state Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.(Exit) 
    VOYANT_kit_sonnerie=false;
    //#]
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit");
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_kit_gestion_sonnerie_kit_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State sonnerie_lumineuse_kit
    if(gestion_sonnerie_kit_gestion_sonnerie_kit_active == sonnerie_lumineuse_kit)
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_appel_entrant_kit__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("170");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit");
                    gestion_sonnerie_kit_gestion_sonnerie_kit_subState = sonnerie_lumineuse_kit;
                    gestion_sonnerie_kit_gestion_sonnerie_kit_active = sonnerie_lumineuse_kit;
                    //#[ state Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit.(Entry) 
                    VOYANT_kit_sonnerie=!VOYANT_kit_sonnerie;
                    
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("170");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::attente_redirection_appel_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_telephone_appel_entrant_kit__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("117");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
            gestion_sonnerie_kit_entDef();
            NOTIFY_TRANSITION_TERMINATED("117");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_telephone_appel_transfere_kit__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("118");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit");
            state_131_subState = appel_en_cours_kit;
            state_131_active = appel_en_cours_kit;
            //#[ state Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit.(Entry) 
            VOYANT_kit_appel =true;
            //#]
            NOTIFY_TRANSITION_TERMINATED("118");
            res = eventConsumed;
        }
    
    
    return res;
}

void _SysVehicule::state_130_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_130");
    NOTIFY_TRANSITION_STARTED("87");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_130.affichage_batterie");
    state_130_subState = affichage_batterie;
    state_130_active = affichage_batterie;
    NOTIFY_TRANSITION_TERMINATED("87");
}

void _SysVehicule::state_130_exit() {
    // State affichage_batterie
    if(state_130_subState == affichage_batterie)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_130.affichage_batterie");
        }
    state_130_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_130");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_130_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State affichage_batterie
    if(state_130_active == affichage_batterie)
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_actualisation_batterie_kit__MonPkg_id))
                {
                    OMSETPARAMS(ev_telephone_actualisation_batterie_kit);
                    NOTIFY_TRANSITION_STARTED("86");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_166.controle_telephone_connecte.state_130.affichage_batterie");
                    //#[ transition 86 
                    envoi_batterie_kit(params->pourcentage);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_166.controle_telephone_connecte.state_130.affichage_batterie");
                    state_130_subState = affichage_batterie;
                    state_130_active = affichage_batterie;
                    NOTIFY_TRANSITION_TERMINATED("86");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_146_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146");
    NOTIFY_TRANSITION_STARTED("90");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.telephone_SIM");
    state_146_subState = telephone_SIM;
    state_146_active = telephone_SIM;
    NOTIFY_TRANSITION_TERMINATED("90");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_146_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_146_active) {
        // State telephone_SIM
        case telephone_SIM:
        {
            if(IS_EVENT_TYPE_OF(ev_btn_SIM_appel__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("91");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.telephone_SIM");
                    tentative_appel_entDef();
                    NOTIFY_TRANSITION_TERMINATED("91");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State debut_tentative
        case debut_tentative:
        {
            res = debut_tentative_handleEvent();
        }
        break;
        // State discussion_telephonique
        case discussion_telephonique:
        {
            if(IS_EVENT_TYPE_OF(ev_telephone_raccrocher_SIM__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("123");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.discussion_telephonique");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.telephone_SIM");
                    state_146_subState = telephone_SIM;
                    state_146_active = telephone_SIM;
                    NOTIFY_TRANSITION_TERMINATED("123");
                    res = eventConsumed;
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::tentative_appel_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.tentative_appel");
    state_146_subState = tentative_appel;
    state_146_timeout = scheduleTimeout(5000, "ROOT.Systeme.state_146.tentative_appel");
    NOTIFY_TRANSITION_STARTED("124");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.tentative_appel.debut_tentative");
    tentative_appel_subState = debut_tentative;
    state_146_active = debut_tentative;
    tentative_appel_timeout = scheduleTimeout(100, "ROOT.Systeme.state_146.tentative_appel.debut_tentative");
    NOTIFY_TRANSITION_TERMINATED("124");
}

void _SysVehicule::tentative_appel_exit() {
    // State debut_tentative
    if(tentative_appel_subState == debut_tentative)
        {
            cancel(tentative_appel_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.tentative_appel.debut_tentative");
        }
    tentative_appel_subState = OMNonState;
    cancel(state_146_timeout);
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.tentative_appel");
}

IOxfReactive::TakeEventStatus _SysVehicule::tentative_appel_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == state_146_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("125");
                    tentative_appel_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.telephone_SIM");
                    state_146_subState = telephone_SIM;
                    state_146_active = telephone_SIM;
                    NOTIFY_TRANSITION_TERMINATED("125");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_telephone_raccrocher_SIM__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("174");
            tentative_appel_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.telephone_SIM");
            state_146_subState = telephone_SIM;
            state_146_active = telephone_SIM;
            NOTIFY_TRANSITION_TERMINATED("174");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_telephone_appel_en_cours_SIM__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("122");
            tentative_appel_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.discussion_telephonique");
            state_146_subState = discussion_telephonique;
            state_146_active = discussion_telephonique;
            NOTIFY_TRANSITION_TERMINATED("122");
            res = eventConsumed;
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::debut_tentative_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == tentative_appel_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("92");
                    cancel(tentative_appel_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_146.tentative_appel.debut_tentative");
                    //#[ transition 92 
                    GEN(ev_SIM_appel);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_146.tentative_appel.debut_tentative");
                    tentative_appel_subState = debut_tentative;
                    state_146_active = debut_tentative;
                    tentative_appel_timeout = scheduleTimeout(100, "ROOT.Systeme.state_146.tentative_appel.debut_tentative");
                    NOTIFY_TRANSITION_TERMINATED("92");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = tentative_appel_handleEvent();
        }
    return res;
}

void _SysVehicule::state_139_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139");
    NOTIFY_TRANSITION_STARTED("94");
    arret_de_communication_entDef();
    NOTIFY_TRANSITION_TERMINATED("94");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_139_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_139_active) {
        // State gestion_communication_telephone
        case gestion_communication_telephone:
        {
            res = gestion_communication_telephone_processEvent();
        }
        break;
        // State gestion_sms_hors_ligne
        case gestion_sms_hors_ligne:
        {
            res = gestion_sms_hors_ligne_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::gestion_communication_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication");
    state_139_subState = gestion_communication;
    gestion_communicationEntDef();
}

void _SysVehicule::gestion_communicationEntDef() {
    NOTIFY_TRANSITION_STARTED("93");
    gestion_communication_telephone_entDef();
    NOTIFY_TRANSITION_TERMINATED("93");
}

void _SysVehicule::gestion_communication_exit() {
    // State gestion_communication_telephone
    if(gestion_communication_subState == gestion_communication_telephone)
        {
            gestion_communication_telephone_exit();
        }
    gestion_communication_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication");
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_communication_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 143 
            if(IS_IN(telephone_eteint))
                {
                    NOTIFY_TRANSITION_STARTED("143");
                    gestion_communication_exit();
                    arret_de_communication_entDef();
                    NOTIFY_TRANSITION_TERMINATED("143");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::gestion_communication_telephone_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone");
    gestion_communication_subState = gestion_communication_telephone;
    state_139_active = gestion_communication_telephone;
    state_183_entDef();
    state_184_entDef();
    state_262_entDef();
}

void _SysVehicule::gestion_communication_telephone_exit() {
    state_183_exit();
    switch (state_184_subState) {
        // State reception_sms
        case reception_sms:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
        }
        break;
        // State lire_sms
        case lire_sms:
        {
            cancel(state_184_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.lire_sms");
        }
        break;
        default:
            break;
    }
    state_184_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184");
    switch (state_262_subState) {
        // State redirection_kit_bluetooth_communication
        case redirection_kit_bluetooth_communication:
        {
            redirection_kit_bluetooth_communication_exit();
        }
        break;
        // State redirection_off
        case redirection_off:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_off");
        }
        break;
        default:
            break;
    }
    state_262_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone");
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_communication_telephone_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_183
    if(state_183_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_communication_telephone))
                {
                    return res;
                }
        }
    // State state_184
    if(state_184_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_communication_telephone))
                {
                    return res;
                }
        }
    // State state_262
    if(state_262_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_communication_telephone))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = gestion_communication_telephone_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_communication_telephone_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    res = gestion_communication_handleEvent();
    return res;
}

void _SysVehicule::state_262_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262");
    NOTIFY_TRANSITION_STARTED("186");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_off");
    state_262_subState = redirection_off;
    state_262_active = redirection_off;
    NOTIFY_TRANSITION_TERMINATED("186");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_262_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_262_active) {
        // State redirection_kit_bluetooth_communication
        case redirection_kit_bluetooth_communication:
        {
            res = redirection_kit_bluetooth_communication_processEvent();
        }
        break;
        // State redirection_off
        case redirection_off:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 187 
                    if(IS_IN(kit_connecte))
                        {
                            NOTIFY_TRANSITION_STARTED("187");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_off");
                            //#[ transition 187 
                            VOYANT_telephone_sonnerie=false;
                            //#]
                            redirection_kit_bluetooth_communication_entDef();
                            NOTIFY_TRANSITION_TERMINATED("187");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::redirection_kit_bluetooth_communication_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication");
    state_262_subState = redirection_kit_bluetooth_communication;
    state_262_active = redirection_kit_bluetooth_communication;
    state_188_entDef();
    state_189_entDef();
}

void _SysVehicule::redirection_kit_bluetooth_communication_exit() {
    state_188_exit();
    switch (state_189_subState) {
        // State reception_sms_kit
        case reception_sms_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
        }
        break;
        // State lire_sms_kit
        case lire_sms_kit:
        {
            cancel(state_189_timeout);
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit.(Exit) 
            GEN(ev_telephone_actualisation_sms_kit(nbr_sms_telephone));
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit");
        }
        break;
        default:
            break;
    }
    state_189_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication");
}

IOxfReactive::TakeEventStatus _SysVehicule::redirection_kit_bluetooth_communication_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_188
    if(state_188_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(redirection_kit_bluetooth_communication))
                {
                    return res;
                }
        }
    // State state_189
    if(state_189_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(redirection_kit_bluetooth_communication))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = redirection_kit_bluetooth_communication_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::redirection_kit_bluetooth_communication_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 188 
            if(!(IS_IN(kit_connecte)))
                {
                    NOTIFY_TRANSITION_STARTED("188");
                    redirection_kit_bluetooth_communication_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_off");
                    state_262_subState = redirection_off;
                    state_262_active = redirection_off;
                    NOTIFY_TRANSITION_TERMINATED("188");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_189_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189");
    NOTIFY_TRANSITION_STARTED("131");
    //#[ transition 131 
    GEN(ev_telephone_sms_historique_kit(nbr_sms_telephone));
    //#]
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
    state_189_subState = reception_sms_kit;
    state_189_active = reception_sms_kit;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit.(Entry) 
    GEN(ev_telephone_sms_nouveau_kit(nbr_sms_telephone));
    VOYANT_telephone_sms=(nbr_sms_telephone>0);
    //#]
    NOTIFY_TRANSITION_TERMINATED("131");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_189_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_189_active) {
        // State reception_sms_kit
        case reception_sms_kit:
        {
            if(IS_EVENT_TYPE_OF(ev_btn_telephone_lire_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("190");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
                    //#[ transition 190 
                    GEN(ev_telephone_actualisation_sms_kit(nbr_sms_telephone));
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
                    state_189_subState = reception_sms_kit;
                    state_189_active = reception_sms_kit;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit.(Entry) 
                    GEN(ev_telephone_sms_nouveau_kit(nbr_sms_telephone));
                    VOYANT_telephone_sms=(nbr_sms_telephone>0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("190");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(ev_kit_lire_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("191");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit");
                    state_189_subState = lire_sms_kit;
                    state_189_active = lire_sms_kit;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit.(Entry) 
                    ex_actualisation_sms_telephone(-1);
                    //#]
                    state_189_timeout = scheduleTimeout(1, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit");
                    NOTIFY_TRANSITION_TERMINATED("191");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(ev_SIM_envoi_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("132");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
                    state_189_subState = reception_sms_kit;
                    state_189_active = reception_sms_kit;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit.(Entry) 
                    GEN(ev_telephone_sms_nouveau_kit(nbr_sms_telephone));
                    VOYANT_telephone_sms=(nbr_sms_telephone>0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("132");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State lire_sms_kit
        case lire_sms_kit:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_189_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("201");
                            cancel(state_189_timeout);
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit.(Exit) 
                            GEN(ev_telephone_actualisation_sms_kit(nbr_sms_telephone));
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
                            state_189_subState = reception_sms_kit;
                            state_189_active = reception_sms_kit;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit.(Entry) 
                            GEN(ev_telephone_sms_nouveau_kit(nbr_sms_telephone));
                            VOYANT_telephone_sms=(nbr_sms_telephone>0);
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("201");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_188_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188");
    NOTIFY_TRANSITION_STARTED("104");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.init_appel_kit");
    pushNullTransition();
    state_188_subState = init_appel_kit;
    state_188_active = init_appel_kit;
    NOTIFY_TRANSITION_TERMINATED("104");
}

void _SysVehicule::state_188_exit() {
    switch (state_188_subState) {
        // State init_appel_kit
        case init_appel_kit:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.init_appel_kit");
        }
        break;
        // State attente_appel_kit
        case attente_appel_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
        }
        break;
        // State sonnerie_transfert
        case sonnerie_transfert:
        {
            sonnerie_transfert_exit();
        }
        break;
        // State transfer_appel
        case transfer_appel:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
        }
        break;
        // State fin_appel_kit
        case fin_appel_kit:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.fin_appel_kit");
        }
        break;
        default:
            break;
    }
    state_188_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_188_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_188_active) {
        // State init_appel_kit
        case init_appel_kit:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    //## transition 105 
                    if(appel_en_cours_telephone)
                        {
                            NOTIFY_TRANSITION_STARTED("105");
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.init_appel_kit");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
                            state_188_subState = transfer_appel;
                            state_188_active = transfer_appel;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel.(Entry) 
                            GEN(ev_telephone_appel_transfere_kit);
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("105");
                            res = eventConsumed;
                        }
                    else
                        {
                            //## transition 106 
                            if(!(appel_en_cours_telephone))
                                {
                                    NOTIFY_TRANSITION_STARTED("106");
                                    popNullTransition();
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.init_appel_kit");
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
                                    state_188_subState = attente_appel_kit;
                                    state_188_active = attente_appel_kit;
                                    NOTIFY_TRANSITION_TERMINATED("106");
                                    res = eventConsumed;
                                }
                        }
                }
            
            
        }
        break;
        // State attente_appel_kit
        case attente_appel_kit:
        {
            if(IS_EVENT_TYPE_OF(ev_SIM_appel__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("107");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
                    sonnerie_transfert_entDef();
                    NOTIFY_TRANSITION_TERMINATED("107");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State sonnerie_transfert
        case sonnerie_transfert:
        {
            res = sonnerie_transfert_processEvent();
        }
        break;
        // State transfer_appel
        case transfer_appel:
        {
            if(IS_EVENT_TYPE_OF(ev_kit_raccrocher__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("112");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.fin_appel_kit");
                    pushNullTransition();
                    state_188_subState = fin_appel_kit;
                    state_188_active = fin_appel_kit;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.fin_appel_kit.(Entry) 
                    appel_en_cours_telephone = false;
                    GEN(ev_telephone_appel_termine_kit);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("112");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 192 
                    if(!appel_en_cours_telephone)
                        {
                            NOTIFY_TRANSITION_STARTED("192");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
                            //#[ transition 192 
                             GEN(ev_telephone_appel_termine_kit);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
                            state_188_subState = attente_appel_kit;
                            state_188_active = attente_appel_kit;
                            NOTIFY_TRANSITION_TERMINATED("192");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State fin_appel_kit
        case fin_appel_kit:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    NOTIFY_TRANSITION_STARTED("206");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.fin_appel_kit");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
                    state_188_subState = attente_appel_kit;
                    state_188_active = attente_appel_kit;
                    NOTIFY_TRANSITION_TERMINATED("206");
                    res = eventConsumed;
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::sonnerie_transfert_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert");
    state_188_subState = sonnerie_transfert;
    state_188_active = sonnerie_transfert;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.(Entry) 
    GEN(ev_telephone_appel_entrant_kit);
    sonnerie_en_cours=true;
    //#]
    state_242_entDef();
    state_243_entDef();
}

void _SysVehicule::sonnerie_transfert_exit() {
    switch (state_242_subState) {
        // State sonnerie_kit_redirige
        case sonnerie_kit_redirige:
        {
            cancel(state_242_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
        }
        break;
        // State sonnerie_finie_kit
        case sonnerie_finie_kit:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_finie_kit");
        }
        break;
        default:
            break;
    }
    state_242_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242");
    state_243_exit();
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.(Exit) 
    sonnerie_en_cours=false;
    //#]
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert");
}

IOxfReactive::TakeEventStatus _SysVehicule::sonnerie_transfert_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_242
    if(state_242_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(sonnerie_transfert))
                {
                    return res;
                }
        }
    // State state_243
    if(state_243_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(sonnerie_transfert))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = sonnerie_transfert_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::sonnerie_transfert_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_kit_raccrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("110");
            sonnerie_transfert_exit();
            //#[ transition 110 
            GEN(ev_telephone_raccrocher_SIM);
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
            state_188_subState = attente_appel_kit;
            state_188_active = attente_appel_kit;
            NOTIFY_TRANSITION_TERMINATED("110");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_kit_decrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("111");
            sonnerie_transfert_exit();
            //#[ transition 111 
            appel_en_cours_telephone =true;
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
            state_188_subState = transfer_appel;
            state_188_active = transfer_appel;
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel.(Entry) 
            GEN(ev_telephone_appel_transfere_kit);
            //#]
            NOTIFY_TRANSITION_TERMINATED("111");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_btn_telephone_decrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("189");
            sonnerie_transfert_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
            state_188_subState = transfer_appel;
            state_188_active = transfer_appel;
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel.(Entry) 
            GEN(ev_telephone_appel_transfere_kit);
            //#]
            NOTIFY_TRANSITION_TERMINATED("189");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 109 
            if(IS_IN(sonnerie_finie_kit))
                {
                    NOTIFY_TRANSITION_STARTED("109");
                    sonnerie_transfert_exit();
                    //#[ transition 109 
                    GEN(ev_telephone_fin_sonnerie_kit);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
                    state_188_subState = attente_appel_kit;
                    state_188_active = attente_appel_kit;
                    NOTIFY_TRANSITION_TERMINATED("109");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_243_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243");
    NOTIFY_TRANSITION_STARTED("166");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
    state_243_subState = sonnerie_sonore_trasnfert;
    state_243_active = sonnerie_sonore_trasnfert;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert.(Entry) 
    GEN(ev_telephone_sonnerie_kit);
    //#]
    state_243_timeout = scheduleTimeout(3000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
    NOTIFY_TRANSITION_TERMINATED("166");
}

void _SysVehicule::state_243_exit() {
    // State sonnerie_sonore_trasnfert
    if(state_243_subState == sonnerie_sonore_trasnfert)
        {
            cancel(state_243_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
        }
    state_243_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_243_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State sonnerie_sonore_trasnfert
    if(state_243_active == sonnerie_sonore_trasnfert)
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_243_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("165");
                            cancel(state_243_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
                            state_243_subState = sonnerie_sonore_trasnfert;
                            state_243_active = sonnerie_sonore_trasnfert;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert.(Entry) 
                            GEN(ev_telephone_sonnerie_kit);
                            //#]
                            state_243_timeout = scheduleTimeout(3000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
                            NOTIFY_TRANSITION_TERMINATED("165");
                            res = eventConsumed;
                        }
                }
            
            
        }
    return res;
}

void _SysVehicule::state_242_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242");
    NOTIFY_TRANSITION_STARTED("164");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
    state_242_subState = sonnerie_kit_redirige;
    state_242_active = sonnerie_kit_redirige;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige.(Entry) 
    GEN(ev_telephone_appel_entrant_kit);
    //#]
    state_242_timeout = scheduleTimeout(1000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
    NOTIFY_TRANSITION_TERMINATED("164");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_242_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_242_active) {
        // State sonnerie_kit_redirige
        case sonnerie_kit_redirige:
        {
            if(IS_EVENT_TYPE_OF(ev_SIM_appel__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("108");
                    cancel(state_242_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
                    state_242_subState = sonnerie_kit_redirige;
                    state_242_active = sonnerie_kit_redirige;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige.(Entry) 
                    GEN(ev_telephone_appel_entrant_kit);
                    //#]
                    state_242_timeout = scheduleTimeout(1000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
                    NOTIFY_TRANSITION_TERMINATED("108");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_242_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("173");
                            cancel(state_242_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_finie_kit");
                            state_242_subState = sonnerie_finie_kit;
                            state_242_active = sonnerie_finie_kit;
                            NOTIFY_TRANSITION_TERMINATED("173");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_184_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184");
    NOTIFY_TRANSITION_STARTED("130");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
    state_184_subState = reception_sms;
    state_184_active = reception_sms;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms.(Entry) 
    VOYANT_telephone_sms=(nbr_sms_telephone>0);
    //#]
    NOTIFY_TRANSITION_TERMINATED("130");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_184_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_184_active) {
        // State reception_sms
        case reception_sms:
        {
            if(IS_EVENT_TYPE_OF(ev_btn_telephone_lire_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("128");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.lire_sms");
                    state_184_subState = lire_sms;
                    state_184_active = lire_sms;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.lire_sms.(Entry) 
                    ex_actualisation_sms_telephone(-1);
                    //#]
                    state_184_timeout = scheduleTimeout(1, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.lire_sms");
                    NOTIFY_TRANSITION_TERMINATED("128");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(ev_SIM_envoi_sms__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("127");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
                    //#[ transition 127 
                    ex_actualisation_sms_telephone(1);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
                    state_184_subState = reception_sms;
                    state_184_active = reception_sms;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms.(Entry) 
                    VOYANT_telephone_sms=(nbr_sms_telephone>0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("127");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State lire_sms
        case lire_sms:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_184_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("129");
                            cancel(state_184_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.lire_sms");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
                            state_184_subState = reception_sms;
                            state_184_active = reception_sms;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms.(Entry) 
                            VOYANT_telephone_sms=(nbr_sms_telephone>0);
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("129");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_183_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183");
    NOTIFY_TRANSITION_STARTED("95");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.init_appel_telephone");
    pushNullTransition();
    state_183_subState = init_appel_telephone;
    state_183_active = init_appel_telephone;
    NOTIFY_TRANSITION_TERMINATED("95");
}

void _SysVehicule::state_183_exit() {
    switch (state_183_subState) {
        // State init_appel_telephone
        case init_appel_telephone:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.init_appel_telephone");
        }
        break;
        // State attente_appel_tel
        case attente_appel_tel:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
        }
        break;
        // State appel_en_cours
        case appel_en_cours:
        {
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours.(Exit) 
            VOYANT_telephone_appel = false;
            GEN(ev_telephone_raccrocher_SIM);
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
        }
        break;
        // State gestion_sonnerie
        case gestion_sonnerie:
        {
            gestion_sonnerie_exit();
        }
        break;
        default:
            break;
    }
    state_183_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_183_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_183_active) {
        // State init_appel_telephone
        case init_appel_telephone:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    //## transition 96 
                    if(appel_en_cours_telephone)
                        {
                            NOTIFY_TRANSITION_STARTED("96");
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.init_appel_telephone");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
                            state_183_subState = appel_en_cours;
                            state_183_active = appel_en_cours;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours.(Entry) 
                            VOYANT_telephone_appel = true;
                            VOYANT_telephone_sonnerie=false;
                            play_sound("stop");
                            GEN(ev_telephone_appel_en_cours_SIM);
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("96");
                            res = eventConsumed;
                        }
                    else
                        {
                            //## transition 103 
                            if(!(appel_en_cours_telephone))
                                {
                                    NOTIFY_TRANSITION_STARTED("103");
                                    popNullTransition();
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.init_appel_telephone");
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
                                    state_183_subState = attente_appel_tel;
                                    state_183_active = attente_appel_tel;
                                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel.(Entry) 
                                    VOYANT_telephone_sonnerie=false;
                                    //#]
                                    NOTIFY_TRANSITION_TERMINATED("103");
                                    res = eventConsumed;
                                }
                        }
                }
            
            
        }
        break;
        // State attente_appel_tel
        case attente_appel_tel:
        {
            if(IS_EVENT_TYPE_OF(ev_SIM_appel__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("97");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
                    gestion_sonnerie_entDef();
                    NOTIFY_TRANSITION_TERMINATED("97");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State appel_en_cours
        case appel_en_cours:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 193 
                    if(!appel_en_cours_telephone)
                        {
                            NOTIFY_TRANSITION_STARTED("193");
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours.(Exit) 
                            VOYANT_telephone_appel = false;
                            GEN(ev_telephone_raccrocher_SIM);
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
                            state_183_subState = attente_appel_tel;
                            state_183_active = attente_appel_tel;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel.(Entry) 
                            VOYANT_telephone_sonnerie=false;
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("193");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(ev_btn_telephone_raccrocher__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("102");
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours.(Exit) 
                    VOYANT_telephone_appel = false;
                    GEN(ev_telephone_raccrocher_SIM);
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
                    //#[ transition 102 
                    appel_en_cours_telephone = false;
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
                    state_183_subState = attente_appel_tel;
                    state_183_active = attente_appel_tel;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel.(Entry) 
                    VOYANT_telephone_sonnerie=false;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("102");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State gestion_sonnerie
        case gestion_sonnerie:
        {
            res = gestion_sonnerie_processEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::gestion_sonnerie_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie");
    state_183_subState = gestion_sonnerie;
    state_183_active = gestion_sonnerie;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.(Entry) 
    sonnerie_en_cours=true;
    //#]
    state_239_entDef();
    state_240_entDef();
}

void _SysVehicule::gestion_sonnerie_exit() {
    switch (state_239_subState) {
        // State sonnerie_lumineuse
        case sonnerie_lumineuse:
        {
            cancel(state_239_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
        }
        break;
        // State sonnerie_finie
        case sonnerie_finie:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_finie");
        }
        break;
        default:
            break;
    }
    state_239_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239");
    state_240_exit();
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.(Exit) 
    sonnerie_en_cours=false;
    play_sound("stop");
    //#]
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie");
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_239
    if(state_239_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_sonnerie))
                {
                    return res;
                }
        }
    // State state_240
    if(state_240_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(gestion_sonnerie))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = gestion_sonnerie_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sonnerie_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_kit_decrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("194");
            gestion_sonnerie_exit();
            //#[ transition 194 
            appel_en_cours_telephone = true;
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
            state_183_subState = appel_en_cours;
            state_183_active = appel_en_cours;
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours.(Entry) 
            VOYANT_telephone_appel = true;
            VOYANT_telephone_sonnerie=false;
            play_sound("stop");
            GEN(ev_telephone_appel_en_cours_SIM);
            //#]
            NOTIFY_TRANSITION_TERMINATED("194");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_btn_telephone_decrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("99");
            gestion_sonnerie_exit();
            //#[ transition 99 
            appel_en_cours_telephone =true;
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
            state_183_subState = appel_en_cours;
            state_183_active = appel_en_cours;
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours.(Entry) 
            VOYANT_telephone_appel = true;
            VOYANT_telephone_sonnerie=false;
            play_sound("stop");
            GEN(ev_telephone_appel_en_cours_SIM);
            //#]
            NOTIFY_TRANSITION_TERMINATED("99");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_btn_telephone_raccrocher__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("101");
            gestion_sonnerie_exit();
            //#[ transition 101 
            GEN(ev_telephone_raccrocher_SIM);
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
            state_183_subState = attente_appel_tel;
            state_183_active = attente_appel_tel;
            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel.(Entry) 
            VOYANT_telephone_sonnerie=false;
            //#]
            NOTIFY_TRANSITION_TERMINATED("101");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 100 
            if(IS_IN(sonnerie_finie))
                {
                    NOTIFY_TRANSITION_STARTED("100");
                    gestion_sonnerie_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
                    state_183_subState = attente_appel_tel;
                    state_183_active = attente_appel_tel;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel.(Entry) 
                    VOYANT_telephone_sonnerie=false;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("100");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_240_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240");
    NOTIFY_TRANSITION_STARTED("162");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
    state_240_subState = sonnerie_sonore;
    state_240_active = sonnerie_sonore;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore.(Entry) 
    play_sound("sonnerie.wav");
    //#]
    state_240_timeout = scheduleTimeout(3000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
    NOTIFY_TRANSITION_TERMINATED("162");
}

void _SysVehicule::state_240_exit() {
    // State sonnerie_sonore
    if(state_240_subState == sonnerie_sonore)
        {
            cancel(state_240_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
        }
    state_240_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_240_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State sonnerie_sonore
    if(state_240_active == sonnerie_sonore)
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_240_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("163");
                            cancel(state_240_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
                            state_240_subState = sonnerie_sonore;
                            state_240_active = sonnerie_sonore;
                            //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore.(Entry) 
                            play_sound("sonnerie.wav");
                            //#]
                            state_240_timeout = scheduleTimeout(3000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
                            NOTIFY_TRANSITION_TERMINATED("163");
                            res = eventConsumed;
                        }
                }
            
            
        }
    return res;
}

void _SysVehicule::state_239_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239");
    NOTIFY_TRANSITION_STARTED("161");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
    state_239_subState = sonnerie_lumineuse;
    state_239_active = sonnerie_lumineuse;
    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse.(Entry) 
    VOYANT_telephone_sonnerie=!VOYANT_telephone_sonnerie;
    
    //#]
    state_239_timeout = scheduleTimeout(1000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
    NOTIFY_TRANSITION_TERMINATED("161");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_239_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_239_active) {
        // State sonnerie_lumineuse
        case sonnerie_lumineuse:
        {
            if(IS_EVENT_TYPE_OF(ev_SIM_appel__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("98");
                    cancel(state_239_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
                    state_239_subState = sonnerie_lumineuse;
                    state_239_active = sonnerie_lumineuse;
                    //#[ state Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse.(Entry) 
                    VOYANT_telephone_sonnerie=!VOYANT_telephone_sonnerie;
                    
                    //#]
                    state_239_timeout = scheduleTimeout(1000, "ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
                    NOTIFY_TRANSITION_TERMINATED("98");
                    res = eventConsumed;
                }
            else if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_239_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("172");
                            cancel(state_239_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_finie");
                            state_239_subState = sonnerie_finie;
                            state_239_active = sonnerie_finie;
                            NOTIFY_TRANSITION_TERMINATED("172");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        
        default:
            break;
    }
    return res;
}

void _SysVehicule::arret_de_communication_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.arret_de_communication");
    state_139_subState = arret_de_communication;
    //#[ state Systeme.state_139.arret_de_communication.(Entry) 
    nbr_sauvegarde_sms_telephone=nbr_sms_telephone;
    eteindre_telephone();
    GEN(ev_telephone_raccrocher_SIM);
    //#]
    NOTIFY_TRANSITION_STARTED("208");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.arret_de_communication.gestion_sms_hors_ligne");
    arret_de_communication_subState = gestion_sms_hors_ligne;
    state_139_active = gestion_sms_hors_ligne;
    NOTIFY_TRANSITION_TERMINATED("208");
}

void _SysVehicule::arret_de_communication_exit() {
    // State gestion_sms_hors_ligne
    if(arret_de_communication_subState == gestion_sms_hors_ligne)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.arret_de_communication.gestion_sms_hors_ligne");
        }
    arret_de_communication_subState = OMNonState;
    //#[ state Systeme.state_139.arret_de_communication.(Exit) 
    nbr_sms_telephone=nbr_sauvegarde_sms_telephone;
    //#]
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.arret_de_communication");
}

IOxfReactive::TakeEventStatus _SysVehicule::arret_de_communicationTakeEVAL() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    //## transition 144 
    if(IS_IN(telephone_actif))
        {
            NOTIFY_TRANSITION_STARTED("144");
            arret_de_communication_exit();
            gestion_communication_entDef();
            NOTIFY_TRANSITION_TERMINATED("144");
            res = eventConsumed;
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::arret_de_communication_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            res = arret_de_communicationTakeEVAL();
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::gestion_sms_hors_ligne_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_SIM_envoi_sms__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("209");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_139.arret_de_communication.gestion_sms_hors_ligne");
            //#[ transition 209 
            nbr_sauvegarde_sms_telephone+=1;
            //#]
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_139.arret_de_communication.gestion_sms_hors_ligne");
            arret_de_communication_subState = gestion_sms_hors_ligne;
            state_139_active = gestion_sms_hors_ligne;
            NOTIFY_TRANSITION_TERMINATED("209");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = arret_de_communication_handleEvent();
        }
    return res;
}

void _SysVehicule::state_126_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126");
    NOTIFY_TRANSITION_STARTED("88");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126.batterie_telephone");
    pushNullTransition();
    state_126_subState = batterie_telephone;
    state_126_active = batterie_telephone;
    //#[ state Systeme.state_126.batterie_telephone.(Entry) 
    GEN(ev_telephone_actualisation_batterie_kit(niveau_batterie_telephone));
    decharge_telephone();
    //#]
    NOTIFY_TRANSITION_TERMINATED("88");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_126_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_126_active) {
        // State batterie_telephone
        case batterie_telephone:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    //## transition 80 
                    if(cmd_charge_vehicule_telephone ==true)
                        {
                            NOTIFY_TRANSITION_STARTED("80");
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.batterie_telephone");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126.charge_batterie_telephone");
                            pushNullTransition();
                            state_126_subState = charge_batterie_telephone;
                            state_126_active = charge_batterie_telephone;
                            //#[ state Systeme.state_126.charge_batterie_telephone.(Entry) 
                            GEN(ev_telephone_actualisation_batterie_kit(niveau_batterie_telephone));
                            charge_telephone();
                            //#]
                            state_126_timeout = scheduleTimeout(1500, "ROOT.Systeme.state_126.charge_batterie_telephone");
                            NOTIFY_TRANSITION_TERMINATED("80");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 146 
                    if(IS_IN(telephone_actif))
                        {
                            NOTIFY_TRANSITION_STARTED("146");
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.batterie_telephone");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126.verifiaction_telephone_allume");
                            state_126_subState = verifiaction_telephone_allume;
                            state_126_active = verifiaction_telephone_allume;
                            state_126_timeout = scheduleTimeout(1000, "ROOT.Systeme.state_126.verifiaction_telephone_allume");
                            NOTIFY_TRANSITION_TERMINATED("146");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State charge_batterie_telephone
        case charge_batterie_telephone:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_126_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("82");
                            popNullTransition();
                            cancel(state_126_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.charge_batterie_telephone");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126.charge_batterie_telephone");
                            pushNullTransition();
                            state_126_subState = charge_batterie_telephone;
                            state_126_active = charge_batterie_telephone;
                            //#[ state Systeme.state_126.charge_batterie_telephone.(Entry) 
                            GEN(ev_telephone_actualisation_batterie_kit(niveau_batterie_telephone));
                            charge_telephone();
                            //#]
                            state_126_timeout = scheduleTimeout(1500, "ROOT.Systeme.state_126.charge_batterie_telephone");
                            NOTIFY_TRANSITION_TERMINATED("82");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    //## transition 81 
                    if(cmd_charge_vehicule_telephone==false)
                        {
                            NOTIFY_TRANSITION_STARTED("81");
                            popNullTransition();
                            cancel(state_126_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.charge_batterie_telephone");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126.batterie_telephone");
                            pushNullTransition();
                            state_126_subState = batterie_telephone;
                            state_126_active = batterie_telephone;
                            //#[ state Systeme.state_126.batterie_telephone.(Entry) 
                            GEN(ev_telephone_actualisation_batterie_kit(niveau_batterie_telephone));
                            decharge_telephone();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("81");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State verifiaction_telephone_allume
        case verifiaction_telephone_allume:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_126_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("145");
                            cancel(state_126_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_126.verifiaction_telephone_allume");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_126.batterie_telephone");
                            pushNullTransition();
                            state_126_subState = batterie_telephone;
                            state_126_active = batterie_telephone;
                            //#[ state Systeme.state_126.batterie_telephone.(Entry) 
                            GEN(ev_telephone_actualisation_batterie_kit(niveau_batterie_telephone));
                            decharge_telephone();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("145");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimated_SysVehicule::serializeAttributes(AOMSAttributes* aomsAttributes) const {
    aomsAttributes->addAttribute("speed", x2String(myReal->speed));
    aomsAttributes->addAttribute("brakePedal", x2String(myReal->brakePedal));
    aomsAttributes->addAttribute("ignition", x2String(myReal->ignition));
    aomsAttributes->addAttribute("distance", x2String(myReal->distance));
    aomsAttributes->addAttribute("throttle", x2String(myReal->throttle));
    aomsAttributes->addAttribute("alpha", x2String(myReal->alpha));
    aomsAttributes->addAttribute("accelPedal", x2String(myReal->accelPedal));
    aomsAttributes->addAttribute("float_distance", x2String(myReal->float_distance));
    aomsAttributes->addAttribute("_simu", x2String(myReal->_simu));
    aomsAttributes->addAttribute("float_speed", x2String(myReal->float_speed));
    aomsAttributes->addAttribute("vitesseConsigne", x2String(myReal->vitesseConsigne));
    aomsAttributes->addAttribute("reservoir_carburant", x2String(myReal->reservoir_carburant));
    aomsAttributes->addAttribute("niveau_batterie", x2String(myReal->niveau_batterie));
    aomsAttributes->addAttribute("cmd_contact", x2String(myReal->cmd_contact));
    aomsAttributes->addAttribute("voyant_regulateur", x2String(myReal->voyant_regulateur));
    aomsAttributes->addAttribute("voyant_limiteur", x2String(myReal->voyant_limiteur));
    aomsAttributes->addAttribute("PARAM_SIMU_max_throttle", x2String(myReal->PARAM_SIMU_max_throttle));
    aomsAttributes->addAttribute("PARAM_SIMU_max_speed", x2String(myReal->PARAM_SIMU_max_speed));
    aomsAttributes->addAttribute("PARAM_SIMU_masse", x2String(myReal->PARAM_SIMU_masse));
    aomsAttributes->addAttribute("PARAM_SIMU_frottement_air", x2String(myReal->PARAM_SIMU_frottement_air));
    aomsAttributes->addAttribute("PARAM_SIMU_puissance_moteur", x2String(myReal->PARAM_SIMU_puissance_moteur));
    aomsAttributes->addAttribute("PARAM_SIMU_puissance_frein", x2String(myReal->PARAM_SIMU_puissance_frein));
    aomsAttributes->addAttribute("PARAM_SIMU_freq_rafraichissement", x2String(myReal->PARAM_SIMU_freq_rafraichissement));
    aomsAttributes->addAttribute("PARAM_SIMU_vitesse_repos", x2String(myReal->PARAM_SIMU_vitesse_repos));
    aomsAttributes->addAttribute("PARAM_SIMU_max_accel", x2String(myReal->PARAM_SIMU_max_accel));
    aomsAttributes->addAttribute("PARAM_SIMU_max_brake", x2String(myReal->PARAM_SIMU_max_brake));
    aomsAttributes->addAttribute("PARAM_SIMU_Kp_regulateur", x2String(myReal->PARAM_SIMU_Kp_regulateur));
    aomsAttributes->addAttribute("PARAM_SIMU_freq_regulateur", x2String(myReal->PARAM_SIMU_freq_regulateur));
    aomsAttributes->addAttribute("PARAM_SIMU_Ki_regulateur", x2String(myReal->PARAM_SIMU_Ki_regulateur));
    aomsAttributes->addAttribute("SEUIL_batterie", x2String(myReal->SEUIL_batterie));
    aomsAttributes->addAttribute("SEUIL_carburant", x2String(myReal->SEUIL_carburant));
    aomsAttributes->addAttribute("Ki_regulateur", x2String(myReal->Ki_regulateur));
    aomsAttributes->addAttribute("Kp_regulateur", x2String(myReal->Kp_regulateur));
    aomsAttributes->addAttribute("throttle_repos", x2String(myReal->throttle_repos));
    aomsAttributes->addAttribute("steady", x2String(myReal->steady));
    aomsAttributes->addAttribute("limiteur_depasse", x2String(myReal->limiteur_depasse));
    aomsAttributes->addAttribute("batterie_faible", x2String(myReal->batterie_faible));
    aomsAttributes->addAttribute("carburant_faible", x2String(myReal->carburant_faible));
    aomsAttributes->addAttribute("valeur_initiale_limiteur", x2String(myReal->valeur_initiale_limiteur));
    aomsAttributes->addAttribute("limiteur_attente", x2String(myReal->limiteur_attente));
    aomsAttributes->addAttribute("VOYANT_bluetooth_vehicule", x2String(myReal->VOYANT_bluetooth_vehicule));
    aomsAttributes->addAttribute("VOYANT_telephone_appairage", x2String(myReal->VOYANT_telephone_appairage));
    aomsAttributes->addAttribute("VOYANT_telephone_connecte", x2String(myReal->VOYANT_telephone_connecte));
    aomsAttributes->addAttribute("champ_mdp", x2String(myReal->champ_mdp));
    aomsAttributes->addAttribute("affichage_appairage", x2String(myReal->affichage_appairage));
    aomsAttributes->addAttribute("liste_appareils_detectes", array2String(2, myReal->liste_appareils_detectes, sizeof(OMString), &x2String));
    aomsAttributes->addAttribute("messages_appairage", array2String(6, myReal->messages_appairage, sizeof(OMString), &x2String));
    aomsAttributes->addAttribute("mot_de_passe", x2String(myReal->mot_de_passe));
    aomsAttributes->addAttribute("affichage_liste_appareils", x2String(myReal->affichage_liste_appareils));
    aomsAttributes->addAttribute("VOYANT_kit_connecte", x2String(myReal->VOYANT_kit_connecte));
    aomsAttributes->addAttribute("kit_jumele", x2String(myReal->kit_jumele));
    aomsAttributes->addAttribute("cmd_bluetooth_telephone_actif", x2String(myReal->cmd_bluetooth_telephone_actif));
    aomsAttributes->addAttribute("niveau_batterie_telephone", x2String(myReal->niveau_batterie_telephone));
    aomsAttributes->addAttribute("VOYANT_kit_appel", x2String(myReal->VOYANT_kit_appel));
    aomsAttributes->addAttribute("VOYANT_kit_sms", x2String(myReal->VOYANT_kit_sms));
    aomsAttributes->addAttribute("cmd_charge_vehicule_telephone", x2String(myReal->cmd_charge_vehicule_telephone));
    aomsAttributes->addAttribute("niveau_batterie_kit", x2String(myReal->niveau_batterie_kit));
    aomsAttributes->addAttribute("VOYANT_telephone_appel", x2String(myReal->VOYANT_telephone_appel));
    aomsAttributes->addAttribute("VOYANT_telephone_sms", x2String(myReal->VOYANT_telephone_sms));
    aomsAttributes->addAttribute("appel_en_cours_telephone", x2String(myReal->appel_en_cours_telephone));
    aomsAttributes->addAttribute("VOYANT_telephone_sonnerie", x2String(myReal->VOYANT_telephone_sonnerie));
    aomsAttributes->addAttribute("VOYANT_kit_sonnerie", x2String(myReal->VOYANT_kit_sonnerie));
    aomsAttributes->addAttribute("nbr_sms_telephone", x2String(myReal->nbr_sms_telephone));
    aomsAttributes->addAttribute("nbr_sms_kit", x2String(myReal->nbr_sms_kit));
    aomsAttributes->addAttribute("telephone_allume", x2String(myReal->telephone_allume));
    aomsAttributes->addAttribute("nbr_sauvegarde_sms_telephone", x2String(myReal->nbr_sauvegarde_sms_telephone));
    aomsAttributes->addAttribute("affichage_titre_musique", x2String(myReal->affichage_titre_musique));
    aomsAttributes->addAttribute("cmd_radio", x2String(myReal->cmd_radio));
    aomsAttributes->addAttribute("VOYANT_radio", x2String(myReal->VOYANT_radio));
    aomsAttributes->addAttribute("sonnerie_en_cours", x2String(myReal->sonnerie_en_cours));
    aomsAttributes->addAttribute("vitesse_voiture_devant", x2String(myReal->vitesse_voiture_devant));
    aomsAttributes->addAttribute("distance_voiture_devant", x2String(myReal->distance_voiture_devant));
    aomsAttributes->addAttribute("distance_entiere_voiture_devant", x2String(myReal->distance_entiere_voiture_devant));
    aomsAttributes->addAttribute("distance_inter_voiture", x2String(myReal->distance_inter_voiture));
    aomsAttributes->addAttribute("distance_securite", x2String(myReal->distance_securite));
    aomsAttributes->addAttribute("cmd_simulation_voiture_devant", x2String(myReal->cmd_simulation_voiture_devant));
    aomsAttributes->addAttribute("chemin_sons", x2String(myReal->chemin_sons));
    aomsAttributes->addAttribute("PARAM_SIMU_periode_pedales", x2String(myReal->PARAM_SIMU_periode_pedales));
}

void OMAnimated_SysVehicule::rootState_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT");
    if(myReal->rootState_subState == _SysVehicule::Systeme)
        {
            Systeme_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::Systeme_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme");
    state_60_serializeStates(aomsState);
    state_61_serializeStates(aomsState);
    state_62_serializeStates(aomsState);
    state_71_serializeStates(aomsState);
    state_72_serializeStates(aomsState);
    state_76_serializeStates(aomsState);
    state_87_serializeStates(aomsState);
    state_96_serializeStates(aomsState);
    state_126_serializeStates(aomsState);
    state_139_serializeStates(aomsState);
    state_146_serializeStates(aomsState);
    state_166_serializeStates(aomsState);
    state_206_serializeStates(aomsState);
    state_252_serializeStates(aomsState);
    state_275_serializeStates(aomsState);
    state_278_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_96_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96");
    switch (myReal->state_96_subState) {
        case _SysVehicule::telephone_actif:
        {
            telephone_actif_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::telephone_eteint:
        {
            telephone_eteint_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::telephone_eteint_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_eteint");
}

void OMAnimated_SysVehicule::telephone_actif_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif");
    switch (myReal->telephone_actif_subState) {
        case _SysVehicule::bluetooth_telephone_active:
        {
            bluetooth_telephone_active_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::bluetooth_telephone_desactive:
        {
            bluetooth_telephone_desactive_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::bluetooth_telephone_desactive_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_desactive");
}

void OMAnimated_SysVehicule::bluetooth_telephone_active_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active");
    switch (myReal->bluetooth_telephone_active_subState) {
        case _SysVehicule::recherche_bluetooth:
        {
            recherche_bluetooth_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::jumelage:
        {
            jumelage_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::connexion:
        {
            connexion_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::kit_connecte:
        {
            kit_connecte_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::kit_detecte:
        {
            kit_detecte_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::interruption_bluetooth_kit:
        {
            interruption_bluetooth_kit_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::recherche_bluetooth_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.recherche_bluetooth");
}

void OMAnimated_SysVehicule::kit_detecte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_detecte");
}

void OMAnimated_SysVehicule::kit_connecte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.kit_connecte");
}

void OMAnimated_SysVehicule::jumelage_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage");
    switch (myReal->jumelage_subState) {
        case _SysVehicule::attente_jumelage:
        {
            attente_jumelage_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::attente_reponse:
        {
            attente_reponse_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::jumelage_effectif:
        {
            jumelage_effectif_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::jumelage_effectif_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.jumelage_effectif");
}

void OMAnimated_SysVehicule::attente_reponse_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_reponse");
}

void OMAnimated_SysVehicule::attente_jumelage_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.jumelage.attente_jumelage");
}

void OMAnimated_SysVehicule::interruption_bluetooth_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.interruption_bluetooth_kit");
}

void OMAnimated_SysVehicule::connexion_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.telephone_actif.bluetooth_telephone_active.connexion");
}

void OMAnimated_SysVehicule::state_87_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87");
    switch (myReal->state_87_subState) {
        case _SysVehicule::bluetooth_desactive:
        {
            bluetooth_desactive_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::bluetooth_active:
        {
            bluetooth_active_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::demarrage_bluetooth:
        {
            demarrage_bluetooth_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::demarrage_bluetooth_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.demarrage_bluetooth");
}

void OMAnimated_SysVehicule::bluetooth_desactive_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_desactive");
}

void OMAnimated_SysVehicule::bluetooth_active_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active");
    switch (myReal->bluetooth_active_subState) {
        case _SysVehicule::recherche_telephone:
        {
            recherche_telephone_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::telephone_connecte:
        {
            telephone_connecte_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::operation_jumelage:
        {
            operation_jumelage_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::telephone_connecte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
}

void OMAnimated_SysVehicule::recherche_telephone_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
}

void OMAnimated_SysVehicule::operation_jumelage_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage");
    switch (myReal->operation_jumelage_subState) {
        case _SysVehicule::jumelage_kit:
        {
            jumelage_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::attente_connexion:
        {
            attente_connexion_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::jumelage_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.jumelage_kit");
}

void OMAnimated_SysVehicule::attente_connexion_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.operation_jumelage.attente_connexion");
}

void OMAnimated_SysVehicule::state_76_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76");
    switch (myReal->state_76_subState) {
        case _SysVehicule::limiteur_on:
        {
            limiteur_on_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::limiteur_off:
        {
            limiteur_off_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::limiteur_on_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on");
    switch (myReal->limiteur_on_subState) {
        case _SysVehicule::consigne_fixe:
        {
            consigne_fixe_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::limiteur_on_plus:
        {
            limiteur_on_plus_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::limiteur_on_moins:
        {
            limiteur_on_moins_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::limiteur_on_plus_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.plus");
}

void OMAnimated_SysVehicule::limiteur_on_moins_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.moins");
}

void OMAnimated_SysVehicule::consigne_fixe_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.consigne_fixe");
    switch (myReal->consigne_fixe_subState) {
        case _SysVehicule::limiteur_inhibe:
        {
            limiteur_inhibe_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::limiteur_effectif:
        {
            limiteur_effectif_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::limiteur_inhibe_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_inhibe");
}

void OMAnimated_SysVehicule::limiteur_effectif_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif");
    switch (myReal->limiteur_effectif_subState) {
        case _SysVehicule::limite_tenue:
        {
            limite_tenue_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::depassement:
        {
            depassement_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::limite_tenue_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.limite_tenue");
}

void OMAnimated_SysVehicule::depassement_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.consigne_fixe.limiteur_effectif.depassement");
}

void OMAnimated_SysVehicule::limiteur_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_off");
}

void OMAnimated_SysVehicule::state_72_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_72");
    if(myReal->state_72_subState == _SysVehicule::simulation_du_vehicule)
        {
            simulation_du_vehicule_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::simulation_du_vehicule_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_72.simulation_du_vehicule");
}

void OMAnimated_SysVehicule::state_71_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71");
    switch (myReal->state_71_subState) {
        case _SysVehicule::mode_manuel:
        {
            mode_manuel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::mode_regulateur:
        {
            mode_regulateur_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::mode_regulateur_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur");
    switch (myReal->mode_regulateur_subState) {
        case _SysVehicule::maintien:
        {
            maintien_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::plus:
        {
            plus_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::moins:
        {
            moins_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::plus_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur.plus");
}

void OMAnimated_SysVehicule::moins_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur.moins");
}

void OMAnimated_SysVehicule::maintien_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur.maintien");
}

void OMAnimated_SysVehicule::mode_manuel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_manuel");
}

void OMAnimated_SysVehicule::state_62_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_62");
    if(myReal->state_62_subState == _SysVehicule::horloge_rafraichissement)
        {
            horloge_rafraichissement_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::horloge_rafraichissement_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_62.horloge_rafraichissement");
}

void OMAnimated_SysVehicule::state_61_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61");
    switch (myReal->state_61_subState) {
        case _SysVehicule::contact_off:
        {
            contact_off_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::contact_on:
        {
            contact_on_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::contact_on_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on");
    state_266_serializeStates(aomsState);
    state_267_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_267_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.state_267");
    if(myReal->state_267_subState == _SysVehicule::calcul_batterie_voiture)
        {
            calcul_batterie_voiture_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::calcul_batterie_voiture_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.state_267.calcul_batterie_voiture");
}

void OMAnimated_SysVehicule::state_266_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.state_266");
    switch (myReal->state_266_subState) {
        case _SysVehicule::moteur_off:
        {
            moteur_off_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::moteur_on:
        {
            moteur_on_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::moteur_on_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.state_266.moteur_on");
}

void OMAnimated_SysVehicule::moteur_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.state_266.moteur_off");
}

void OMAnimated_SysVehicule::contact_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_off");
}

void OMAnimated_SysVehicule::state_60_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60");
    switch (myReal->state_60_subState) {
        case _SysVehicule::pedales:
        {
            pedales_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::regulateur:
        {
            regulateur_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::regulateur_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.regulateur");
    switch (myReal->regulateur_subState) {
        case _SysVehicule::verification_distance_securite:
        {
            verification_distance_securite_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::suivi_distance_consigne:
        {
            suivi_distance_consigne_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::suivi_vitesse_consigne:
        {
            suivi_vitesse_consigne_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::verification_distance_securite_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.regulateur.verification_distance_securite");
}

void OMAnimated_SysVehicule::suivi_vitesse_consigne_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.regulateur.suivi_vitesse_consigne");
}

void OMAnimated_SysVehicule::suivi_distance_consigne_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.regulateur.suivi_distance_consigne");
}

void OMAnimated_SysVehicule::pedales_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.pedales");
    switch (myReal->pedales_subState) {
        case _SysVehicule::freinage_injection:
        {
            freinage_injection_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::acceleration:
        {
            acceleration_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::freinage_injection_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.pedales.freinage_injection");
}

void OMAnimated_SysVehicule::acceleration_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.pedales.acceleration");
}

void OMAnimated_SysVehicule::state_278_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278");
    switch (myReal->state_278_subState) {
        case _SysVehicule::contact_radio_actif:
        {
            contact_radio_actif_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::radio_eteinte:
        {
            radio_eteinte_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::radio_prete:
        {
            radio_prete_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::radio_prete_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.radio_prete");
}

void OMAnimated_SysVehicule::radio_eteinte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.radio_eteinte");
}

void OMAnimated_SysVehicule::contact_radio_actif_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif");
    switch (myReal->contact_radio_actif_subState) {
        case _SysVehicule::priorite_radio:
        {
            priorite_radio_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::priorite_appel:
        {
            priorite_appel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::priorite_sonnerie:
        {
            priorite_sonnerie_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::priorite_sonnerie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_sonnerie");
}

void OMAnimated_SysVehicule::priorite_radio_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio");
    state_233_serializeStates(aomsState);
    state_260_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_260_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260");
    switch (myReal->state_260_subState) {
        case _SysVehicule::attente_btn_radio:
        {
            attente_btn_radio_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::appui_btn_radio:
        {
            appui_btn_radio_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::attente_btn_radio_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.attente_btn_radio");
}

void OMAnimated_SysVehicule::appui_btn_radio_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_260.appui_btn_radio");
}

void OMAnimated_SysVehicule::state_233_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233");
    switch (myReal->state_233_subState) {
        case _SysVehicule::radio_active:
        {
            radio_active_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::lancement_radio:
        {
            lancement_radio_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::radio_active_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active");
    switch (myReal->radio_active_subState) {
        case _SysVehicule::musique_1:
        {
            musique_1_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::musique_2:
        {
            musique_2_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::musique_3:
        {
            musique_3_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::musique_3_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_3");
}

void OMAnimated_SysVehicule::musique_2_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_2");
}

void OMAnimated_SysVehicule::musique_1_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.radio_active.musique_1");
}

void OMAnimated_SysVehicule::lancement_radio_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_radio.state_233.lancement_radio");
}

void OMAnimated_SysVehicule::priorite_appel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_278.contact_radio_actif.priorite_appel");
}

void OMAnimated_SysVehicule::state_275_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_275");
    switch (myReal->state_275_subState) {
        case _SysVehicule::simulation_voiture_devant:
        {
            simulation_voiture_devant_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::reglage_voiture_devant:
        {
            reglage_voiture_devant_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::simulation_voiture_devant_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_275.simulation_voiture_devant");
    if(myReal->simulation_voiture_devant_subState == _SysVehicule::loop_simulation)
        {
            loop_simulation_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::loop_simulation_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_275.simulation_voiture_devant.loop_simulation");
}

void OMAnimated_SysVehicule::reglage_voiture_devant_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_275.reglage_voiture_devant");
}

void OMAnimated_SysVehicule::state_252_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_252");
    switch (myReal->state_252_subState) {
        case _SysVehicule::fonctionelle:
        {
            fonctionelle_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::panne_carburant:
        {
            panne_carburant_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::panne_batterie:
        {
            panne_batterie_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::remplir_carburant:
        {
            remplir_carburant_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::depanner_batterie:
        {
            depanner_batterie_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::remplir_carburant_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_252.remplir_carburant");
}

void OMAnimated_SysVehicule::panne_carburant_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_252.panne_carburant");
}

void OMAnimated_SysVehicule::panne_batterie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_252.panne_batterie");
}

void OMAnimated_SysVehicule::fonctionelle_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_252.fonctionelle");
}

void OMAnimated_SysVehicule::depanner_batterie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_252.depanner_batterie");
}

void OMAnimated_SysVehicule::state_206_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_206");
    if(myReal->state_206_subState == _SysVehicule::sms_exterrieur)
        {
            sms_exterrieur_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::sms_exterrieur_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_206.sms_exterrieur");
}

void OMAnimated_SysVehicule::state_166_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166");
    switch (myReal->state_166_subState) {
        case _SysVehicule::controle_telephone_connecte:
        {
            controle_telephone_connecte_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::telephone_deconnecte:
        {
            telephone_deconnecte_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::telephone_deconnecte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.telephone_deconnecte");
}

void OMAnimated_SysVehicule::controle_telephone_connecte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte");
    state_130_serializeStates(aomsState);
    state_131_serializeStates(aomsState);
    state_173_serializeStates(aomsState);
    state_174_serializeStates(aomsState);
    state_198_serializeStates(aomsState);
    state_199_serializeStates(aomsState);
    state_204_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_204_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_204");
}

void OMAnimated_SysVehicule::state_199_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_199");
    switch (myReal->state_199_subState) {
        case _SysVehicule::messagerie_kit:
        {
            messagerie_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::init_redirection_sms_kit:
        {
            init_redirection_sms_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::lire_message_kit:
        {
            lire_message_kit_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::messagerie_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.messagerie_kit");
}

void OMAnimated_SysVehicule::lire_message_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.lire_message_kit");
}

void OMAnimated_SysVehicule::init_redirection_sms_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_199.init_redirection_sms_kit");
}

void OMAnimated_SysVehicule::state_198_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_198");
    if(myReal->state_198_subState == _SysVehicule::gestion_btn_lire_sms_kit)
        {
            gestion_btn_lire_sms_kit_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::gestion_btn_lire_sms_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_198.gestion_btn_lire_sms_kit");
}

void OMAnimated_SysVehicule::state_174_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_174");
    if(myReal->state_174_subState == _SysVehicule::gestion_btn_decrocher_kit)
        {
            gestion_btn_decrocher_kit_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::gestion_btn_decrocher_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_174.gestion_btn_decrocher_kit");
}

void OMAnimated_SysVehicule::state_173_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_173");
    if(myReal->state_173_subState == _SysVehicule::gestion_btn_raccrocher_kit)
        {
            gestion_btn_raccrocher_kit_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::gestion_btn_raccrocher_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_173.gestion_btn_raccrocher_kit");
}

void OMAnimated_SysVehicule::state_131_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131");
    switch (myReal->state_131_subState) {
        case _SysVehicule::attente_redirection_appel:
        {
            attente_redirection_appel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::appel_en_cours_kit:
        {
            appel_en_cours_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::gestion_sonnerie_kit:
        {
            gestion_sonnerie_kit_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::gestion_sonnerie_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit");
    gestion_sonnerie_kit_gestion_sonnerie_kit_serializeStates(aomsState);
    gestion_sonnerie_kit_state_240_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::gestion_sonnerie_kit_state_240_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240");
    if(myReal->gestion_sonnerie_kit_state_240_subState == _SysVehicule::sonnerie_sonore_kit)
        {
            sonnerie_sonore_kit_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::sonnerie_sonore_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.state_240.sonnerie_sonore_kit");
}

void OMAnimated_SysVehicule::gestion_sonnerie_kit_gestion_sonnerie_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit");
    if(myReal->gestion_sonnerie_kit_gestion_sonnerie_kit_subState == _SysVehicule::sonnerie_lumineuse_kit)
        {
            sonnerie_lumineuse_kit_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::sonnerie_lumineuse_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.gestion_sonnerie_kit.gestion_sonnerie_kit.sonnerie_lumineuse_kit");
}

void OMAnimated_SysVehicule::attente_redirection_appel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.attente_redirection_appel");
}

void OMAnimated_SysVehicule::appel_en_cours_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_131.appel_en_cours_kit");
}

void OMAnimated_SysVehicule::state_130_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_130");
    if(myReal->state_130_subState == _SysVehicule::affichage_batterie)
        {
            affichage_batterie_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::affichage_batterie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_166.controle_telephone_connecte.state_130.affichage_batterie");
}

void OMAnimated_SysVehicule::state_146_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_146");
    switch (myReal->state_146_subState) {
        case _SysVehicule::telephone_SIM:
        {
            telephone_SIM_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::tentative_appel:
        {
            tentative_appel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::discussion_telephonique:
        {
            discussion_telephonique_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::tentative_appel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_146.tentative_appel");
    if(myReal->tentative_appel_subState == _SysVehicule::debut_tentative)
        {
            debut_tentative_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::debut_tentative_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_146.tentative_appel.debut_tentative");
}

void OMAnimated_SysVehicule::telephone_SIM_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_146.telephone_SIM");
}

void OMAnimated_SysVehicule::discussion_telephonique_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_146.discussion_telephonique");
}

void OMAnimated_SysVehicule::state_139_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139");
    switch (myReal->state_139_subState) {
        case _SysVehicule::gestion_communication:
        {
            gestion_communication_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::arret_de_communication:
        {
            arret_de_communication_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::gestion_communication_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication");
    if(myReal->gestion_communication_subState == _SysVehicule::gestion_communication_telephone)
        {
            gestion_communication_telephone_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::gestion_communication_telephone_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone");
    state_183_serializeStates(aomsState);
    state_184_serializeStates(aomsState);
    state_262_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_262_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262");
    switch (myReal->state_262_subState) {
        case _SysVehicule::redirection_kit_bluetooth_communication:
        {
            redirection_kit_bluetooth_communication_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::redirection_off:
        {
            redirection_off_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::redirection_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_off");
}

void OMAnimated_SysVehicule::redirection_kit_bluetooth_communication_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication");
    state_188_serializeStates(aomsState);
    state_189_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_189_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189");
    switch (myReal->state_189_subState) {
        case _SysVehicule::reception_sms_kit:
        {
            reception_sms_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::lire_sms_kit:
        {
            lire_sms_kit_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::reception_sms_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.reception_sms_kit");
}

void OMAnimated_SysVehicule::lire_sms_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_189.lire_sms_kit");
}

void OMAnimated_SysVehicule::state_188_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188");
    switch (myReal->state_188_subState) {
        case _SysVehicule::init_appel_kit:
        {
            init_appel_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::attente_appel_kit:
        {
            attente_appel_kit_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::sonnerie_transfert:
        {
            sonnerie_transfert_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::transfer_appel:
        {
            transfer_appel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::fin_appel_kit:
        {
            fin_appel_kit_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::transfer_appel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.transfer_appel");
}

void OMAnimated_SysVehicule::sonnerie_transfert_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert");
    state_242_serializeStates(aomsState);
    state_243_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_243_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243");
    if(myReal->state_243_subState == _SysVehicule::sonnerie_sonore_trasnfert)
        {
            sonnerie_sonore_trasnfert_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::sonnerie_sonore_trasnfert_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_243.sonnerie_sonore_trasnfert");
}

void OMAnimated_SysVehicule::state_242_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242");
    switch (myReal->state_242_subState) {
        case _SysVehicule::sonnerie_kit_redirige:
        {
            sonnerie_kit_redirige_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::sonnerie_finie_kit:
        {
            sonnerie_finie_kit_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::sonnerie_kit_redirige_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_kit_redirige");
}

void OMAnimated_SysVehicule::sonnerie_finie_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.sonnerie_transfert.state_242.sonnerie_finie_kit");
}

void OMAnimated_SysVehicule::init_appel_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.init_appel_kit");
}

void OMAnimated_SysVehicule::fin_appel_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.fin_appel_kit");
}

void OMAnimated_SysVehicule::attente_appel_kit_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_262.redirection_kit_bluetooth_communication.state_188.attente_appel_kit");
}

void OMAnimated_SysVehicule::state_184_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184");
    switch (myReal->state_184_subState) {
        case _SysVehicule::reception_sms:
        {
            reception_sms_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::lire_sms:
        {
            lire_sms_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::reception_sms_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.reception_sms");
}

void OMAnimated_SysVehicule::lire_sms_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_184.lire_sms");
}

void OMAnimated_SysVehicule::state_183_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183");
    switch (myReal->state_183_subState) {
        case _SysVehicule::init_appel_telephone:
        {
            init_appel_telephone_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::attente_appel_tel:
        {
            attente_appel_tel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::appel_en_cours:
        {
            appel_en_cours_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::gestion_sonnerie:
        {
            gestion_sonnerie_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::init_appel_telephone_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.init_appel_telephone");
}

void OMAnimated_SysVehicule::gestion_sonnerie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie");
    state_239_serializeStates(aomsState);
    state_240_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_240_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240");
    if(myReal->state_240_subState == _SysVehicule::sonnerie_sonore)
        {
            sonnerie_sonore_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::sonnerie_sonore_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_240.sonnerie_sonore");
}

void OMAnimated_SysVehicule::state_239_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239");
    switch (myReal->state_239_subState) {
        case _SysVehicule::sonnerie_lumineuse:
        {
            sonnerie_lumineuse_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::sonnerie_finie:
        {
            sonnerie_finie_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::sonnerie_lumineuse_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_lumineuse");
}

void OMAnimated_SysVehicule::sonnerie_finie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.gestion_sonnerie.state_239.sonnerie_finie");
}

void OMAnimated_SysVehicule::attente_appel_tel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.attente_appel_tel");
}

void OMAnimated_SysVehicule::appel_en_cours_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.gestion_communication.gestion_communication_telephone.state_183.appel_en_cours");
}

void OMAnimated_SysVehicule::arret_de_communication_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.arret_de_communication");
    if(myReal->arret_de_communication_subState == _SysVehicule::gestion_sms_hors_ligne)
        {
            gestion_sms_hors_ligne_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::gestion_sms_hors_ligne_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_139.arret_de_communication.gestion_sms_hors_ligne");
}

void OMAnimated_SysVehicule::state_126_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_126");
    switch (myReal->state_126_subState) {
        case _SysVehicule::batterie_telephone:
        {
            batterie_telephone_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::charge_batterie_telephone:
        {
            charge_batterie_telephone_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::verifiaction_telephone_allume:
        {
            verifiaction_telephone_allume_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::verifiaction_telephone_allume_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_126.verifiaction_telephone_allume");
}

void OMAnimated_SysVehicule::charge_batterie_telephone_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_126.charge_batterie_telephone");
}

void OMAnimated_SysVehicule::batterie_telephone_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_126.batterie_telephone");
}
//#]

IMPLEMENT_REACTIVE_META_P(_SysVehicule, _MonPkg, _MonPkg, false, OMAnimated_SysVehicule)

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setAccelPedal_double, "setAccelPedal", FALSE, "setAccelPedal(double)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setAccelPedal_double, _SysVehicule, setAccelPedal(p_accelPedal), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setAffichage_liste_appareils_OMString, "setAffichage_liste_appareils", FALSE, "setAffichage_liste_appareils(OMString)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setAffichage_liste_appareils_OMString, _SysVehicule, setAffichage_liste_appareils(p_affichage_liste_appareils), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setAlpha_int, "setAlpha", FALSE, "setAlpha(int)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setAlpha_int, _SysVehicule, setAlpha(p_alpha), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setBrakePedal_double, "setBrakePedal", FALSE, "setBrakePedal(double)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setBrakePedal_double, _SysVehicule, setBrakePedal(p_brakePedal), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setChamp_mdp_OMString, "setChamp_mdp", FALSE, "setChamp_mdp(OMString)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setChamp_mdp_OMString, _SysVehicule, setChamp_mdp(p_champ_mdp), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool, "setCmd_bluetooth_telephone_actif", FALSE, "setCmd_bluetooth_telephone_actif(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool, _SysVehicule, setCmd_bluetooth_telephone_actif(p_cmd_bluetooth_telephone_actif), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool, "setCmd_charge_vehicule_telephone", FALSE, "setCmd_charge_vehicule_telephone(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool, _SysVehicule, setCmd_charge_vehicule_telephone(p_cmd_charge_vehicule_telephone), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setCmd_contact_bool, "setCmd_contact", FALSE, "setCmd_contact(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setCmd_contact_bool, _SysVehicule, setCmd_contact(p_cmd_contact), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setCmd_radio_bool, "setCmd_radio", FALSE, "setCmd_radio(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setCmd_radio_bool, _SysVehicule, setCmd_radio(p_cmd_radio), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool, "setCmd_simulation_voiture_devant", FALSE, "setCmd_simulation_voiture_devant(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool, _SysVehicule, setCmd_simulation_voiture_devant(p_cmd_simulation_voiture_devant), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setDistance_inter_voiture_double, "setDistance_inter_voiture", FALSE, "setDistance_inter_voiture(double)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setDistance_inter_voiture_double, _SysVehicule, setDistance_inter_voiture(p_distance_inter_voiture), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setTelephone_allume_bool, "setTelephone_allume", FALSE, "setTelephone_allume(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setTelephone_allume_bool, _SysVehicule, setTelephone_allume(p_telephone_allume), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setVitesse_voiture_devant_double, "setVitesse_voiture_devant", FALSE, "setVitesse_voiture_devant(double)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setVitesse_voiture_devant_double, _SysVehicule, setVitesse_voiture_devant(p_vitesse_voiture_devant), NO_OP())
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.cpp
*********************************************************************/
