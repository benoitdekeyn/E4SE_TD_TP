/*********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _MonPkg
//!	Generated Date	: Thu, 26, Nov 2026  
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.h
*********************************************************************/

#ifndef _MonPkg_H
#define _MonPkg_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "Windows.h"
//## auto_generated
#include "stdlib.h"
//## auto_generated
#include "stdio.h"
//## auto_generated
#include "string.h"
//## auto_generated
#include "stdint.h"
//## auto_generated
#include "tchar.h"
//## auto_generated
#include <oxf\event.h>
//## auto_generated
class _SysVehicule;

//#[ ignore
#define Push_Carburant__MonPkg_id 13401

#define cablage__MonPkg_id 13402

#define f__MonPkg_id 13403

#define Operation_108__MonPkg_id 13404

#define decr_vitesseConsigne__MonPkg_id 13405

#define incr_vitesseConsigne__MonPkg_id 13406

#define ev_Demarrer__MonPkg_id 13407

#define evDemarrer__MonPkg_id 13408

#define ev_demarrer__MonPkg_id 13409

#define ev_depanner_batterie__MonPkg_id 13410

#define ev_remplir_carburant__MonPkg_id 13411

#define ev_vitesseConsigne_moins__MonPkg_id 13412

#define ev_vitesseConsigne_plus__MonPkg_id 13413

#define moteur__MonPkg_id 13414

#define t__MonPkg_id 13415

#define EVAL__MonPkg_id 13416

#define ev_limiteur__MonPkg_id 13417

#define ev_regulateur__MonPkg_id 13418

#define ev_ok__MonPkg_id 13419

#define ev_jumeler__MonPkg_id 13420

#define ev_kit_vehicule_pret__MonPkg_id 13421

#define ev_OK__MonPkg_id 13422

#define kit_connecte__MonPkg_id 13423

#define connexion_demandee__MonPkg_id 13424

#define ev_connexion_demandee__MonPkg_id 13425

#define connexion_acceptee__MonPkg_id 13426

#define bluetooth_vehicule_desactive__MonPkg_id 13427

#define bluetooth_kit_desactive__MonPkg_id 13428

#define ev_bluetooth_telephone_desactive__MonPkg_id 13429

#define ev_bluetooth_kit_desactive__MonPkg_id 13430

#define evJumelage_demandee__MonPkg_id 13431

#define ev_jumelage_demande__MonPkg_id 13432

#define ev_mdp_incorrect__MonPkg_id 13433

#define ev_mdp_correct__MonPkg_id 13434

#define ev_jumelage_demandee__MonPkg_id 13435

#define ev_jumelage_reussit__MonPkg_id 13436

#define ev_tentative_jumelage__MonPkg_id 13437

#define ev_demande_jumelage__MonPkg_id 13438

#define ev_demande_mot_de_passe__MonPkg_id 13439

#define ev_tentative_password__MonPkg_id 13440

#define ev_tentative_code_pin__MonPkg_id 13441

#define ev_demande_code_pin__MonPkg_id 13442

#define ev_code_pin_incorrect__MonPkg_id 13443

#define ev_demande_mdp__MonPkg_id 13444

#define ev_demande_connexion__MonPkg_id 13445

#define ev_tentative_mdp__MonPkg_id 13446

#define ev_actualisation_telephone__MonPkg_id 13447

#define ev_actualisation_batterie_telephone_vehicule__MonPkg_id 13448

#define ev_appel__MonPkg_id 13449

#define ev_sms__MonPkg_id 13450

#define ev_appel_recu__MonPkg_id 13451

#define ev_appel_fin__MonPkg_id 13452

#define ev_raccrocher__MonPkg_id 13453

#define ev_connexion_acceptee__MonPkg_id 13454

#define ev_blue_telephone_desactive__MonPkg_id 13455

#define ev_appel_recu_kit__MonPkg_id 13456

#define ev_appel_demande__MonPkg_id 13457

#define ev_bouton_appel__MonPkg_id 13458

#define ev_appel_exterieur__MonPkg_id 13459

#define ev_refuser_appel__MonPkg_id 13460

#define ev_appel_externe__MonPkg_id 13461

#define ev_decrocher_telephone__MonPkg_id 13462

#define ev_racrocher_telephone__MonPkg_id 13463

#define ev_raccrocher_telephone__MonPkg_id 13464

#define ev_decrocher_kit___MonPkg_id 13465

#define ev_raccrocher_kit__MonPkg_id 13466

#define ev_decrocher_kit__MonPkg_id 13467

#define ev_btn_decrocher_kit__MonPkg_id 13468

#define ev_btn_raccrocher_kit__MonPkg_id 13469

#define ev_appel_entrant_kit__MonPkg_id 13470

#define ev_appel_transfere__MonPkg_id 13471

#define ev_appel_transfere_kit__MonPkg_id 13472

#define ev_eppel_termine_kit__MonPkg_id 13473

#define ev_appel_termine_kit__MonPkg_id 13474

#define ev_appel_en_cours__MonPkg_id 13475

#define ev_raccroher_telephone__MonPkg_id 13476

#define ev_rraccrocher_telephonel__MonPkg_id 13477

#define ev_raccrocher_telephonel__MonPkg_id 13478

#define ev_envoi_sms__MonPkg_id 13479

#define ev_btn_telephone_sms__MonPkg_id 13480

#define ev_lire_sms_kit__MonPkg_id 13481

#define ev_nv_message_kit__MonPkg_id 13482

#define ev_messagerie_vide_kit__MonPkg_id 13483

#define ev_btn_lire_sms_kit__MonPkg_id 13484

#define ev_transfert_sms_telephone_to_kit__MonPkg_id 13485

#define ev_transfert_sms_to_kit__MonPkg_id 13486

#define ev_transfert_sms_to_telephone__MonPkg_id 13487

#define ev_tentative_lire_sms_kit__MonPkg_id 13488

#define ev_nv_sms_kit__MonPkg_id 13489

#define ev_actualisation_sms_kit__MonPkg_id 13490

#define ev_btn_radio_on__MonPkg_id 13491

#define ev_btn_radio_off__MonPkg_id 13492

#define ev_transition_musique_1__MonPkg_id 13493

#define ev_skip_musique__MonPkg_id 13494

#define ev_btn_radio_skip__MonPkg_id 13495

#define ev_btn_start_radio__MonPkg_id 13496

#define ev_sonnerie_kit__MonPkg_id 13497

#define eval__MonPkg_id 13498

#define ev_fin_sonnerie__MonPkg_id 13499

#define ev_bnt_appel_externe__MonPkg_id 13500

#define ev_btn_appel_externe__MonPkg_id 13501

#define ev_btn_appel_SIM__MonPkg_id 13502

#define ev_btn_SIM_appel__MonPkg_id 13503

#define ev_SIM_appel__MonPkg_id 13504

#define ev_SIM_raccrocher__MonPkg_id 13505

#define ev_btn_raccrocher_telephone__MonPkg_id 13506

#define ev_SIM_refuser_appel__MonPkg_id 13507

#define ev_telephone_decrocher__MonPkg_id 13508

#define ev_telephone_raccrocher__MonPkg_id 13509

#define ev_btn_telephone_raccrocher___MonPkg_id 13510

#define ev_kit_decrocher__MonPkg_id 13511

#define ev_kit_raccrocher__MonPkg_id 13512

#define ev_kit_appel_entrant__MonPkg_id 13513

#define ev_kit_sonnerie__MonPkg_id 13514

#define ev_kit_appel_transfere__MonPkg_id 13515

#define ev_kit_appel_termine__MonPkg_id 13516

#define ev_btn_kit_raccrocher__MonPkg_id 13517

#define ev_btn_kit_decrocher__MonPkg_id 13518

#define ev_btn_SIM_sms__MonPkg_id 13519

#define ev_SIM_envoi_sms__MonPkg_id 13520

#define ev_lire_sms__MonPkg_id 13521

#define ev_kit_lire_sms__MonPkg_id 13522

#define ev_btn_telephone_lire_sms__MonPkg_id 13523

#define ev_btn_kit_lire_sms__MonPkg_id 13524

#define ev_SIM_appel_en_cours__MonPkg_id 13525

#define ev_btn_telephone_decrocher__MonPkg_id 13526

#define ev_btn_telephone_raccrocher__MonPkg_id 13527

#define ev_bnt_telephone_decrocher__MonPkg_id 13528

#define ev_kit_fin_sonnerie__MonPkg_id 13529

#define ev_btn_ok__MonPkg_id 13530

#define ev_kit_bluetooth_desactive__MonPkg_id 13531

#define ev__MonPkg_id 13532

#define ev_tel_demande_jumelage__MonPkg_id 13533

#define ev_telephone_demande_jumelage__MonPkg_id 13534

#define ev_kit_demande_mdp__MonPkg_id 13535

#define ev_telephone_tentative_mdp__MonPkg_id 13536

#define ev_kit_mdp_correct__MonPkg_id 13537

#define ev_kit_mdp_incorrect__MonPkg_id 13538

#define ev_telephone_demande_connexion__MonPkg_id 13539

#define ev_kit_connexion_acceptee__MonPkg_id 13540

#define ev_btn_appairage__MonPkg_id 13541

#define ev_btn_telephone_appairage__MonPkg_id 13542

#define ev_telephone_kit_appel_entrant__MonPkg_id 13543

#define ev_telephone_kit_sonnerie__MonPkg_id 13544

#define ev_telephone_kit_fin_sonnerie__MonPkg_id 13545

#define ev_telephone_kit_appel_transfere__MonPkg_id 13546

#define ev_telephone_kit_appel_termine__MonPkg_id 13547

#define ev_telephone_appel_entrant_kit__MonPkg_id 13548

#define ev_telephone_sonnerie_kit__MonPkg_id 13549

#define ev_telephone_appel_transfere_kit__MonPkg_id 13550

#define ev_telephone_appel_kit_termine__MonPkg_id 13551

#define ev_telephone_appel_termine_kit__MonPkg_id 13552

#define ev_telephone_fin_sonnerie_kit__MonPkg_id 13553

#define ev_kit_tentative_lire_sms__MonPkg_id 13554

#define ev_telephone_sms_historique_kit__MonPkg_id 13555

#define ev_telephone_sms_nouveau_kit__MonPkg_id 13556

#define ev_telephone_appel_en_cours__MonPkg_id 13557

#define ev_telephone_appel_en_cours_SIM__MonPkg_id 13558

#define ev_telephone_raccrocher_SIM__MonPkg_id 13559

#define ev_kit_actualisation_sms__MonPkg_id 13560

#define ev_telephone_actualisation_batterie_kit__MonPkg_id 13561

#define ev_telephone_actualisation_sms_kit__MonPkg_id 13562

#define ev_telephone_bluetooth_desactive__MonPkg_id 13563
//#]

//## package _MonPkg



//## event Push_Carburant()
class Push_Carburant : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedPush_Carburant;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    Push_Carburant();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedPush_Carburant : virtual public AOMEvent {
    DECLARE_META_EVENT(Push_Carburant)
};
//#]
#endif // _OMINSTRUMENT

//## event cablage()
class cablage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedcablage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    cablage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedcablage : virtual public AOMEvent {
    DECLARE_META_EVENT(cablage)
};
//#]
#endif // _OMINSTRUMENT

//## event f()
class f : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedf;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    f();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedf : virtual public AOMEvent {
    DECLARE_META_EVENT(f)
};
//#]
#endif // _OMINSTRUMENT

//## event Operation_108()
class Operation_108 : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedOperation_108;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    Operation_108();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedOperation_108 : virtual public AOMEvent {
    DECLARE_META_EVENT(Operation_108)
};
//#]
#endif // _OMINSTRUMENT

//## event decr_vitesseConsigne()
class decr_vitesseConsigne : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimateddecr_vitesseConsigne;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    decr_vitesseConsigne();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimateddecr_vitesseConsigne : virtual public AOMEvent {
    DECLARE_META_EVENT(decr_vitesseConsigne)
};
//#]
#endif // _OMINSTRUMENT

//## event incr_vitesseConsigne()
class incr_vitesseConsigne : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedincr_vitesseConsigne;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    incr_vitesseConsigne();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedincr_vitesseConsigne : virtual public AOMEvent {
    DECLARE_META_EVENT(incr_vitesseConsigne)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_Demarrer()
class ev_Demarrer : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_Demarrer;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_Demarrer();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_Demarrer : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_Demarrer)
};
//#]
#endif // _OMINSTRUMENT

//## event evDemarrer()
class evDemarrer : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedevDemarrer;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    evDemarrer();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedevDemarrer : virtual public AOMEvent {
    DECLARE_META_EVENT(evDemarrer)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demarrer()
class ev_demarrer : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demarrer;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demarrer();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demarrer : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demarrer)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_depanner_batterie()
class ev_depanner_batterie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_depanner_batterie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_depanner_batterie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_depanner_batterie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_depanner_batterie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_remplir_carburant()
class ev_remplir_carburant : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_remplir_carburant;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_remplir_carburant();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_remplir_carburant : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_remplir_carburant)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_vitesseConsigne_moins()
class ev_vitesseConsigne_moins : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_vitesseConsigne_moins;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_vitesseConsigne_moins();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_vitesseConsigne_moins : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_vitesseConsigne_moins)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_vitesseConsigne_plus()
class ev_vitesseConsigne_plus : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_vitesseConsigne_plus;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_vitesseConsigne_plus();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_vitesseConsigne_plus : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_vitesseConsigne_plus)
};
//#]
#endif // _OMINSTRUMENT

//## event moteur()
class moteur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedmoteur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    moteur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedmoteur : virtual public AOMEvent {
    DECLARE_META_EVENT(moteur)
};
//#]
#endif // _OMINSTRUMENT

//## event t()
class t : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedt;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    t();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedt : virtual public AOMEvent {
    DECLARE_META_EVENT(t)
};
//#]
#endif // _OMINSTRUMENT

//## event EVAL()
class EVAL : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedEVAL;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    EVAL();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedEVAL : virtual public AOMEvent {
    DECLARE_META_EVENT(EVAL)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_limiteur()
class ev_limiteur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_limiteur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_limiteur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_limiteur : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_limiteur)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_regulateur()
class ev_regulateur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_regulateur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_regulateur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_regulateur : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_regulateur)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_ok()
class ev_ok : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_ok;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_ok();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_ok : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_ok)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_jumeler()
class ev_jumeler : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_jumeler;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_jumeler();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_jumeler : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_jumeler)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_vehicule_pret()
class ev_kit_vehicule_pret : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_vehicule_pret;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_vehicule_pret();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_vehicule_pret : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_vehicule_pret)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_OK()
class ev_OK : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_OK;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_OK();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_OK : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_OK)
};
//#]
#endif // _OMINSTRUMENT

//## event kit_connecte()
class kit_connecte : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedkit_connecte;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    kit_connecte();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedkit_connecte : virtual public AOMEvent {
    DECLARE_META_EVENT(kit_connecte)
};
//#]
#endif // _OMINSTRUMENT

//## event connexion_demandee()
class connexion_demandee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedconnexion_demandee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    connexion_demandee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedconnexion_demandee : virtual public AOMEvent {
    DECLARE_META_EVENT(connexion_demandee)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_connexion_demandee()
class ev_connexion_demandee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_connexion_demandee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_connexion_demandee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_connexion_demandee : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_connexion_demandee)
};
//#]
#endif // _OMINSTRUMENT

//## event connexion_acceptee()
class connexion_acceptee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedconnexion_acceptee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    connexion_acceptee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedconnexion_acceptee : virtual public AOMEvent {
    DECLARE_META_EVENT(connexion_acceptee)
};
//#]
#endif // _OMINSTRUMENT

//## event bluetooth_vehicule_desactive()
class bluetooth_vehicule_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedbluetooth_vehicule_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    bluetooth_vehicule_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedbluetooth_vehicule_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(bluetooth_vehicule_desactive)
};
//#]
#endif // _OMINSTRUMENT

//## event bluetooth_kit_desactive()
class bluetooth_kit_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedbluetooth_kit_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    bluetooth_kit_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedbluetooth_kit_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(bluetooth_kit_desactive)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_bluetooth_telephone_desactive()
class ev_bluetooth_telephone_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_bluetooth_telephone_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_bluetooth_telephone_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_bluetooth_telephone_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_bluetooth_telephone_desactive)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_bluetooth_kit_desactive()
class ev_bluetooth_kit_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_bluetooth_kit_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_bluetooth_kit_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_bluetooth_kit_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_bluetooth_kit_desactive)
};
//#]
#endif // _OMINSTRUMENT

//## event evJumelage_demandee()
class evJumelage_demandee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedevJumelage_demandee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    evJumelage_demandee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedevJumelage_demandee : virtual public AOMEvent {
    DECLARE_META_EVENT(evJumelage_demandee)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_jumelage_demande(OMString)
class ev_jumelage_demande : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_jumelage_demande;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_jumelage_demande();
    
    //## auto_generated
    ev_jumelage_demande(OMString p_mot_de_passe);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    OMString mot_de_passe;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_jumelage_demande : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_jumelage_demande)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_mdp_incorrect()
class ev_mdp_incorrect : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_mdp_incorrect;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_mdp_incorrect();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_mdp_incorrect : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_mdp_incorrect)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_mdp_correct()
class ev_mdp_correct : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_mdp_correct;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_mdp_correct();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_mdp_correct : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_mdp_correct)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_jumelage_demandee()
class ev_jumelage_demandee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_jumelage_demandee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_jumelage_demandee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_jumelage_demandee : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_jumelage_demandee)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_jumelage_reussit()
class ev_jumelage_reussit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_jumelage_reussit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_jumelage_reussit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_jumelage_reussit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_jumelage_reussit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_tentative_jumelage()
class ev_tentative_jumelage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_tentative_jumelage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_tentative_jumelage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_tentative_jumelage : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_tentative_jumelage)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demande_jumelage()
class ev_demande_jumelage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demande_jumelage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demande_jumelage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demande_jumelage : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demande_jumelage)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demande_mot_de_passe()
class ev_demande_mot_de_passe : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demande_mot_de_passe;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demande_mot_de_passe();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demande_mot_de_passe : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demande_mot_de_passe)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_tentative_password()
class ev_tentative_password : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_tentative_password;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_tentative_password();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_tentative_password : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_tentative_password)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_tentative_code_pin(OMString)
class ev_tentative_code_pin : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_tentative_code_pin;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_tentative_code_pin();
    
    //## auto_generated
    ev_tentative_code_pin(OMString p_code_pin);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    OMString code_pin;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_tentative_code_pin : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_tentative_code_pin)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demande_code_pin()
class ev_demande_code_pin : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demande_code_pin;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demande_code_pin();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demande_code_pin : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demande_code_pin)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_code_pin_incorrect()
class ev_code_pin_incorrect : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_code_pin_incorrect;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_code_pin_incorrect();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_code_pin_incorrect : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_code_pin_incorrect)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demande_mdp()
class ev_demande_mdp : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demande_mdp;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demande_mdp();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demande_mdp : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demande_mdp)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demande_connexion()
class ev_demande_connexion : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demande_connexion;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demande_connexion();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demande_connexion : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demande_connexion)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_tentative_mdp(OMString)
class ev_tentative_mdp : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_tentative_mdp;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_tentative_mdp();
    
    //## auto_generated
    ev_tentative_mdp(OMString p_mdp);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    OMString mdp;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_tentative_mdp : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_tentative_mdp)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_actualisation_telephone()
class ev_actualisation_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_actualisation_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_actualisation_telephone();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_actualisation_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_actualisation_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_actualisation_batterie_telephone_vehicule(int)
class ev_actualisation_batterie_telephone_vehicule : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_actualisation_batterie_telephone_vehicule;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_actualisation_batterie_telephone_vehicule();
    
    //## auto_generated
    ev_actualisation_batterie_telephone_vehicule(int p_pourcentage);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int pourcentage;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_actualisation_batterie_telephone_vehicule : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_actualisation_batterie_telephone_vehicule)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel()
class ev_appel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_sms()
class ev_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_recu()
class ev_appel_recu : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_recu;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_recu();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_recu : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_recu)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_fin()
class ev_appel_fin : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_fin;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_fin();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_fin : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_fin)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_raccrocher()
class ev_raccrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_raccrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_raccrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_raccrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_raccrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_connexion_acceptee()
class ev_connexion_acceptee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_connexion_acceptee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_connexion_acceptee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_connexion_acceptee : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_connexion_acceptee)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_blue_telephone_desactive()
class ev_blue_telephone_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_blue_telephone_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_blue_telephone_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_blue_telephone_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_blue_telephone_desactive)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_recu_kit()
class ev_appel_recu_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_recu_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_recu_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_recu_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_recu_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_demande()
class ev_appel_demande : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_demande;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_demande();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_demande : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_demande)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_bouton_appel()
class ev_bouton_appel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_bouton_appel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_bouton_appel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_bouton_appel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_bouton_appel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_exterieur()
class ev_appel_exterieur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_exterieur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_exterieur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_exterieur : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_exterieur)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_refuser_appel()
class ev_refuser_appel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_refuser_appel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_refuser_appel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_refuser_appel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_refuser_appel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_externe()
class ev_appel_externe : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_externe;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_externe();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_externe : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_externe)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_decrocher_telephone()
class ev_decrocher_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_decrocher_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_decrocher_telephone();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_decrocher_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_decrocher_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_racrocher_telephone()
class ev_racrocher_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_racrocher_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_racrocher_telephone();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_racrocher_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_racrocher_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_raccrocher_telephone()
class ev_raccrocher_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_raccrocher_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_raccrocher_telephone();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_raccrocher_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_raccrocher_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_decrocher_kit_()
class ev_decrocher_kit_ : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_decrocher_kit_;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_decrocher_kit_();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_decrocher_kit_ : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_decrocher_kit_)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_raccrocher_kit()
class ev_raccrocher_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_raccrocher_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_raccrocher_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_raccrocher_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_raccrocher_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_decrocher_kit()
class ev_decrocher_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_decrocher_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_decrocher_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_decrocher_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_decrocher_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_decrocher_kit()
class ev_btn_decrocher_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_decrocher_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_decrocher_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_decrocher_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_decrocher_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_raccrocher_kit()
class ev_btn_raccrocher_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_raccrocher_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_raccrocher_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_raccrocher_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_raccrocher_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_entrant_kit()
class ev_appel_entrant_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_entrant_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_entrant_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_entrant_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_entrant_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_transfere()
class ev_appel_transfere : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_transfere;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_transfere();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_transfere : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_transfere)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_transfere_kit()
class ev_appel_transfere_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_transfere_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_transfere_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_transfere_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_transfere_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_eppel_termine_kit()
class ev_eppel_termine_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_eppel_termine_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_eppel_termine_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_eppel_termine_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_eppel_termine_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_termine_kit()
class ev_appel_termine_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_termine_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_termine_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_termine_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_termine_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_appel_en_cours()
class ev_appel_en_cours : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_appel_en_cours;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_appel_en_cours();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_appel_en_cours : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_appel_en_cours)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_raccroher_telephone()
class ev_raccroher_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_raccroher_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_raccroher_telephone();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_raccroher_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_raccroher_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_rraccrocher_telephonel()
class ev_rraccrocher_telephonel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_rraccrocher_telephonel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_rraccrocher_telephonel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_rraccrocher_telephonel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_rraccrocher_telephonel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_raccrocher_telephonel()
class ev_raccrocher_telephonel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_raccrocher_telephonel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_raccrocher_telephonel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_raccrocher_telephonel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_raccrocher_telephonel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_envoi_sms()
class ev_envoi_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_envoi_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_envoi_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_envoi_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_envoi_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_telephone_sms()
class ev_btn_telephone_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_telephone_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_telephone_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_telephone_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_telephone_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_lire_sms_kit()
class ev_lire_sms_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_lire_sms_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_lire_sms_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_lire_sms_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_lire_sms_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_nv_message_kit()
class ev_nv_message_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_nv_message_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_nv_message_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_nv_message_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_nv_message_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_messagerie_vide_kit()
class ev_messagerie_vide_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_messagerie_vide_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_messagerie_vide_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_messagerie_vide_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_messagerie_vide_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_lire_sms_kit()
class ev_btn_lire_sms_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_lire_sms_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_lire_sms_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_lire_sms_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_lire_sms_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_transfert_sms_telephone_to_kit()
class ev_transfert_sms_telephone_to_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_transfert_sms_telephone_to_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_transfert_sms_telephone_to_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_transfert_sms_telephone_to_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_transfert_sms_telephone_to_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_transfert_sms_to_kit(int)
class ev_transfert_sms_to_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_transfert_sms_to_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_transfert_sms_to_kit();
    
    //## auto_generated
    ev_transfert_sms_to_kit(int p_historique);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int historique;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_transfert_sms_to_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_transfert_sms_to_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_transfert_sms_to_telephone(int)
class ev_transfert_sms_to_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_transfert_sms_to_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_transfert_sms_to_telephone();
    
    //## auto_generated
    ev_transfert_sms_to_telephone(int p_historique);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int historique;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_transfert_sms_to_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_transfert_sms_to_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_tentative_lire_sms_kit()
class ev_tentative_lire_sms_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_tentative_lire_sms_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_tentative_lire_sms_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_tentative_lire_sms_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_tentative_lire_sms_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_nv_sms_kit(int)
class ev_nv_sms_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_nv_sms_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_nv_sms_kit();
    
    //## auto_generated
    ev_nv_sms_kit(int p_sms_telephone);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int sms_telephone;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_nv_sms_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_nv_sms_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_actualisation_sms_kit(int)
class ev_actualisation_sms_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_actualisation_sms_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_actualisation_sms_kit();
    
    //## auto_generated
    ev_actualisation_sms_kit(int p_sms_tel);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int sms_tel;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_actualisation_sms_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_actualisation_sms_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_radio_on()
class ev_btn_radio_on : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_radio_on;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_radio_on();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_radio_on : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_radio_on)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_radio_off()
class ev_btn_radio_off : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_radio_off;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_radio_off();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_radio_off : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_radio_off)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_transition_musique_1()
class ev_transition_musique_1 : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_transition_musique_1;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_transition_musique_1();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_transition_musique_1 : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_transition_musique_1)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_skip_musique()
class ev_skip_musique : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_skip_musique;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_skip_musique();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_skip_musique : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_skip_musique)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_radio_skip()
class ev_btn_radio_skip : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_radio_skip;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_radio_skip();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_radio_skip : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_radio_skip)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_start_radio()
class ev_btn_start_radio : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_start_radio;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_start_radio();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_start_radio : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_start_radio)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_sonnerie_kit()
class ev_sonnerie_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_sonnerie_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_sonnerie_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_sonnerie_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_sonnerie_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event eval()
class eval : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedeval;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    eval();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedeval : virtual public AOMEvent {
    DECLARE_META_EVENT(eval)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_fin_sonnerie()
class ev_fin_sonnerie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_fin_sonnerie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_fin_sonnerie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_fin_sonnerie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_fin_sonnerie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_bnt_appel_externe()
class ev_bnt_appel_externe : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_bnt_appel_externe;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_bnt_appel_externe();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_bnt_appel_externe : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_bnt_appel_externe)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_appel_externe()
class ev_btn_appel_externe : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_appel_externe;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_appel_externe();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_appel_externe : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_appel_externe)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_appel_SIM()
class ev_btn_appel_SIM : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_appel_SIM;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_appel_SIM();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_appel_SIM : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_appel_SIM)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_SIM_appel()
class ev_btn_SIM_appel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_SIM_appel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_SIM_appel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_SIM_appel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_SIM_appel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_SIM_appel()
class ev_SIM_appel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_SIM_appel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_SIM_appel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_SIM_appel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_SIM_appel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_SIM_raccrocher()
class ev_SIM_raccrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_SIM_raccrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_SIM_raccrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_SIM_raccrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_SIM_raccrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_raccrocher_telephone()
class ev_btn_raccrocher_telephone : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_raccrocher_telephone;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_raccrocher_telephone();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_raccrocher_telephone : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_raccrocher_telephone)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_SIM_refuser_appel()
class ev_SIM_refuser_appel : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_SIM_refuser_appel;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_SIM_refuser_appel();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_SIM_refuser_appel : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_SIM_refuser_appel)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_decrocher()
class ev_telephone_decrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_decrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_decrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_decrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_decrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_raccrocher()
class ev_telephone_raccrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_raccrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_raccrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_raccrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_raccrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_telephone_raccrocher_()
class ev_btn_telephone_raccrocher_ : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_telephone_raccrocher_;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_telephone_raccrocher_();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_telephone_raccrocher_ : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_telephone_raccrocher_)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_decrocher()
class ev_kit_decrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_decrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_decrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_decrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_decrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_raccrocher()
class ev_kit_raccrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_raccrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_raccrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_raccrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_raccrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_appel_entrant()
class ev_kit_appel_entrant : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_appel_entrant;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_appel_entrant();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_appel_entrant : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_appel_entrant)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_sonnerie()
class ev_kit_sonnerie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_sonnerie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_sonnerie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_sonnerie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_sonnerie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_appel_transfere()
class ev_kit_appel_transfere : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_appel_transfere;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_appel_transfere();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_appel_transfere : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_appel_transfere)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_appel_termine()
class ev_kit_appel_termine : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_appel_termine;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_appel_termine();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_appel_termine : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_appel_termine)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_kit_raccrocher()
class ev_btn_kit_raccrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_kit_raccrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_kit_raccrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_kit_raccrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_kit_raccrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_kit_decrocher()
class ev_btn_kit_decrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_kit_decrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_kit_decrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_kit_decrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_kit_decrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_SIM_sms()
class ev_btn_SIM_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_SIM_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_SIM_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_SIM_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_SIM_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_SIM_envoi_sms()
class ev_SIM_envoi_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_SIM_envoi_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_SIM_envoi_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_SIM_envoi_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_SIM_envoi_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_lire_sms()
class ev_lire_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_lire_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_lire_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_lire_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_lire_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_lire_sms()
class ev_kit_lire_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_lire_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_lire_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_lire_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_lire_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_telephone_lire_sms()
class ev_btn_telephone_lire_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_telephone_lire_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_telephone_lire_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_telephone_lire_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_telephone_lire_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_kit_lire_sms()
class ev_btn_kit_lire_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_kit_lire_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_kit_lire_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_kit_lire_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_kit_lire_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_SIM_appel_en_cours()
class ev_SIM_appel_en_cours : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_SIM_appel_en_cours;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_SIM_appel_en_cours();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_SIM_appel_en_cours : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_SIM_appel_en_cours)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_telephone_decrocher()
class ev_btn_telephone_decrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_telephone_decrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_telephone_decrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_telephone_decrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_telephone_decrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_telephone_raccrocher()
class ev_btn_telephone_raccrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_telephone_raccrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_telephone_raccrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_telephone_raccrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_telephone_raccrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_bnt_telephone_decrocher()
class ev_bnt_telephone_decrocher : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_bnt_telephone_decrocher;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_bnt_telephone_decrocher();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_bnt_telephone_decrocher : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_bnt_telephone_decrocher)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_fin_sonnerie()
class ev_kit_fin_sonnerie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_fin_sonnerie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_fin_sonnerie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_fin_sonnerie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_fin_sonnerie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_ok()
class ev_btn_ok : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_ok;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_ok();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_ok : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_ok)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_bluetooth_desactive()
class ev_kit_bluetooth_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_bluetooth_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_bluetooth_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_bluetooth_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_bluetooth_desactive)
};
//#]
#endif // _OMINSTRUMENT

//## event ev()
class ev : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev : virtual public AOMEvent {
    DECLARE_META_EVENT(ev)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_tel_demande_jumelage()
class ev_tel_demande_jumelage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_tel_demande_jumelage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_tel_demande_jumelage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_tel_demande_jumelage : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_tel_demande_jumelage)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_demande_jumelage(OMString)
class ev_telephone_demande_jumelage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_demande_jumelage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_demande_jumelage();
    
    //## auto_generated
    ev_telephone_demande_jumelage(OMString p_mot_de_passe);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    OMString mot_de_passe;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_demande_jumelage : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_demande_jumelage)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_demande_mdp()
class ev_kit_demande_mdp : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_demande_mdp;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_demande_mdp();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_demande_mdp : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_demande_mdp)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_tentative_mdp(OMString)
class ev_telephone_tentative_mdp : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_tentative_mdp;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_tentative_mdp();
    
    //## auto_generated
    ev_telephone_tentative_mdp(OMString p_mdp);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    OMString mdp;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_tentative_mdp : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_tentative_mdp)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_mdp_correct()
class ev_kit_mdp_correct : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_mdp_correct;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_mdp_correct();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_mdp_correct : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_mdp_correct)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_mdp_incorrect()
class ev_kit_mdp_incorrect : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_mdp_incorrect;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_mdp_incorrect();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_mdp_incorrect : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_mdp_incorrect)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_demande_connexion()
class ev_telephone_demande_connexion : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_demande_connexion;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_demande_connexion();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_demande_connexion : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_demande_connexion)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_connexion_acceptee()
class ev_kit_connexion_acceptee : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_connexion_acceptee;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_connexion_acceptee();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_connexion_acceptee : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_connexion_acceptee)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_appairage()
class ev_btn_appairage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_appairage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_appairage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_appairage : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_appairage)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_btn_telephone_appairage()
class ev_btn_telephone_appairage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_btn_telephone_appairage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_btn_telephone_appairage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_btn_telephone_appairage : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_btn_telephone_appairage)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_kit_appel_entrant()
class ev_telephone_kit_appel_entrant : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_kit_appel_entrant;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_kit_appel_entrant();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_kit_appel_entrant : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_kit_appel_entrant)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_kit_sonnerie()
class ev_telephone_kit_sonnerie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_kit_sonnerie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_kit_sonnerie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_kit_sonnerie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_kit_sonnerie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_kit_fin_sonnerie()
class ev_telephone_kit_fin_sonnerie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_kit_fin_sonnerie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_kit_fin_sonnerie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_kit_fin_sonnerie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_kit_fin_sonnerie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_kit_appel_transfere()
class ev_telephone_kit_appel_transfere : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_kit_appel_transfere;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_kit_appel_transfere();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_kit_appel_transfere : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_kit_appel_transfere)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_kit_appel_termine()
class ev_telephone_kit_appel_termine : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_kit_appel_termine;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_kit_appel_termine();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_kit_appel_termine : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_kit_appel_termine)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_appel_entrant_kit()
class ev_telephone_appel_entrant_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_appel_entrant_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_appel_entrant_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_appel_entrant_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_appel_entrant_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_sonnerie_kit()
class ev_telephone_sonnerie_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_sonnerie_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_sonnerie_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_sonnerie_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_sonnerie_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_appel_transfere_kit()
class ev_telephone_appel_transfere_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_appel_transfere_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_appel_transfere_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_appel_transfere_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_appel_transfere_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_appel_kit_termine()
class ev_telephone_appel_kit_termine : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_appel_kit_termine;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_appel_kit_termine();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_appel_kit_termine : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_appel_kit_termine)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_appel_termine_kit()
class ev_telephone_appel_termine_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_appel_termine_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_appel_termine_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_appel_termine_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_appel_termine_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_fin_sonnerie_kit()
class ev_telephone_fin_sonnerie_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_fin_sonnerie_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_fin_sonnerie_kit();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_fin_sonnerie_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_fin_sonnerie_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_tentative_lire_sms()
class ev_kit_tentative_lire_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_tentative_lire_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_tentative_lire_sms();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_tentative_lire_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_tentative_lire_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_sms_historique_kit(int)
class ev_telephone_sms_historique_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_sms_historique_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_sms_historique_kit();
    
    //## auto_generated
    ev_telephone_sms_historique_kit(int p_historique);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int historique;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_sms_historique_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_sms_historique_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_sms_nouveau_kit(int)
class ev_telephone_sms_nouveau_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_sms_nouveau_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_sms_nouveau_kit();
    
    //## auto_generated
    ev_telephone_sms_nouveau_kit(int p_sms_telephone);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int sms_telephone;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_sms_nouveau_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_sms_nouveau_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_appel_en_cours()
class ev_telephone_appel_en_cours : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_appel_en_cours;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_appel_en_cours();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_appel_en_cours : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_appel_en_cours)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_appel_en_cours_SIM()
class ev_telephone_appel_en_cours_SIM : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_appel_en_cours_SIM;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_appel_en_cours_SIM();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_appel_en_cours_SIM : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_appel_en_cours_SIM)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_raccrocher_SIM()
class ev_telephone_raccrocher_SIM : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_raccrocher_SIM;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_raccrocher_SIM();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_raccrocher_SIM : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_raccrocher_SIM)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_actualisation_sms(int)
class ev_kit_actualisation_sms : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_actualisation_sms;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_actualisation_sms();
    
    //## auto_generated
    ev_kit_actualisation_sms(int p_sms_tel);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int sms_tel;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_actualisation_sms : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_actualisation_sms)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_actualisation_batterie_kit(int)
class ev_telephone_actualisation_batterie_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_actualisation_batterie_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_actualisation_batterie_kit();
    
    //## auto_generated
    ev_telephone_actualisation_batterie_kit(int p_pourcentage);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int pourcentage;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_actualisation_batterie_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_actualisation_batterie_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_actualisation_sms_kit(int)
class ev_telephone_actualisation_sms_kit : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_actualisation_sms_kit;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_actualisation_sms_kit();
    
    //## auto_generated
    ev_telephone_actualisation_sms_kit(int p_sms_tel);
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
    
    ////    Framework    ////
    
    int sms_tel;		//## auto_generated
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_actualisation_sms_kit : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_actualisation_sms_kit)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_telephone_bluetooth_desactive()
class ev_telephone_bluetooth_desactive : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_telephone_bluetooth_desactive;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_telephone_bluetooth_desactive();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_telephone_bluetooth_desactive : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_telephone_bluetooth_desactive)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.h
*********************************************************************/
