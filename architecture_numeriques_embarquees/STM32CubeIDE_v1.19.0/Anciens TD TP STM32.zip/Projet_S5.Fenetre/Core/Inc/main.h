/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define RGB_ROUGE_Pin GPIO_PIN_6
#define RGB_ROUGE_GPIO_Port GPIOA
#define RGB_VERTE_Pin GPIO_PIN_7
#define RGB_VERTE_GPIO_Port GPIOA
#define BLUE_Pin GPIO_PIN_10
#define BLUE_GPIO_Port GPIOB
#define PIR_Pin GPIO_PIN_7
#define PIR_GPIO_Port GPIOC
#define PIR_EXTI_IRQn EXTI9_5_IRQn
#define BTN_Pin GPIO_PIN_8
#define BTN_GPIO_Port GPIOA
#define BTN_EXTI_IRQn EXTI9_5_IRQn
#define BTN_FEN_Pin GPIO_PIN_10
#define BTN_FEN_GPIO_Port GPIOA
#define BTN_FEN_EXTI_IRQn EXTI15_10_IRQn
#define YELLOW_Pin GPIO_PIN_4
#define YELLOW_GPIO_Port GPIOB
#define RGB_BLEUE_Pin GPIO_PIN_6
#define RGB_BLEUE_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
