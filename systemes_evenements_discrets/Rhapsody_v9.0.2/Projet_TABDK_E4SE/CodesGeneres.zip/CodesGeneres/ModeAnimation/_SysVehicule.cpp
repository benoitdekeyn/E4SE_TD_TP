/********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _SysVehicule
//!	Generated Date	: Wed, 21, Oct 2026  
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX

#define _OMSTATECHART_ANIMATED
//#]

//## dependency _SysVehicule
#include "_SysVehicule.h"
//#[ ignore
#define _MonPkg__SysVehicule__SysVehicule_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_Operation_168_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_accelerer_SERIALIZE aomsmethod->addAttribute("accelPedal", x2String(accelPedal));

#define _MonPkg__SysVehicule_alerte_depassement_SERIALIZE aomsmethod->addAttribute("actif", x2String(actif));

#define _MonPkg__SysVehicule_arreter_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_batterie_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_carburant_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_regulateur_vitesse_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_calcul_vitesse_distance_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_demarrer_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_depanner_batterie_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_jumeler_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_ok_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_remplir_carburant_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_ex_vitesseConsigne_SERIALIZE aomsmethod->addAttribute("delta", x2String(delta));

#define _MonPkg__SysVehicule_freiner_injection_SERIALIZE aomsmethod->addAttribute("brakePedal", x2String(brakePedal));

#define _MonPkg__SysVehicule_init_SERIALIZE OM_NO_OP

#define _MonPkg__SysVehicule_regulateur_Prof_SERIALIZE OM_NO_OP

#define OMAnim__MonPkg__SysVehicule_setAccelPedal_double_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_accelPedal)

#define OMAnim__MonPkg__SysVehicule_setAccelPedal_double_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setAffichage_liste_appareils_OMString_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_affichage_liste_appareils)

#define OMAnim__MonPkg__SysVehicule_setAffichage_liste_appareils_OMString_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setAlpha_int_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_alpha)

#define OMAnim__MonPkg__SysVehicule_setAlpha_int_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setBrakePedal_double_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_brakePedal)

#define OMAnim__MonPkg__SysVehicule_setBrakePedal_double_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setChamp_mdp_OMString_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_champ_mdp)

#define OMAnim__MonPkg__SysVehicule_setChamp_mdp_OMString_SERIALIZE_RET_VAL

#define OMAnim__MonPkg__SysVehicule_setCmd_contact_bool_UNSERIALIZE_ARGS OP_UNSER(OMDestructiveString2X,p_cmd_contact)

#define OMAnim__MonPkg__SysVehicule_setCmd_contact_bool_SERIALIZE_RET_VAL
//#]

//## package _MonPkg

//## class _SysVehicule
void _SysVehicule::accelerer(double accelPedal) {
    NOTIFY_OPERATION(accelerer, accelerer(double), 1, _MonPkg__SysVehicule_accelerer_SERIALIZE);
    //#[ operation accelerer(double)
    // --- PARAMETRES EXTERNES ---
    const double MAX_THROTTLE = PARAM_SIMU_max_throttle;
    const double CST_RALENTI  = throttle_repos;
    const double MAX_ACCEL    = (double)PARAM_SIMU_max_accel;
    
    // --- LOGIQUE ---
    // Mise � l'�chelle : 0->10 sur la p�dale donne 1.0->10.0 sur le throttle
    double plage_utile = MAX_THROTTLE - CST_RALENTI;
    throttle = CST_RALENTI + (accelPedal / MAX_ACCEL) * plage_utile;
    //#]
}

void _SysVehicule::arreter() {
    NOTIFY_OPERATION(arreter, arreter(), 0, _MonPkg__SysVehicule_arreter_SERIALIZE);
    //#[ operation arreter()
    //stop engine
    ignition=false;
    //#]
}

void _SysVehicule::ex_demarrer() {
    NOTIFY_OPERATION(ex_demarrer, ex_demarrer(), 0, _MonPkg__SysVehicule_ex_demarrer_SERIALIZE);
    //#[ operation ex_demarrer()
    ignition = true;
    throttle = throttle_repos;
    niveau_batterie -= 10;
    //#]
}

void _SysVehicule::calcul_vitesse_distance() {
    NOTIFY_OPERATION(calcul_vitesse_distance, calcul_vitesse_distance(), 0, _MonPkg__SysVehicule_calcul_vitesse_distance_SERIALIZE);
    //#[ operation calcul_vitesse_distance()
    // --- PARAMETRES EXTERNES ---
    const double MAX_SPEED            = (double)PARAM_SIMU_max_speed;        // ex: 120 km/h
    const double MASSE                = (double)PARAM_SIMU_masse;            // ex: 1200 kg
    const double PUISSANCE            = (double)PARAM_SIMU_puissance_moteur; // ex: 600 N par unit� de throttle
    const double FORCE_FREINS         = (double)PARAM_SIMU_puissance_frein;  // ex: 80 N
    const double CST_RALENTI          = throttle_repos;                      // ex: 1.0
    const double MAX_BRAKE            = (double)PARAM_SIMU_max_brake;        // ex: 10.0
    const double AIR_DRAG             = PARAM_SIMU_frottement_air;           // en kg/m (mettre ~0.4)
    const double DELTA_T_MS           = (double)(1000/PARAM_SIMU_freq_rafraichissement);
    
    // --- CONSTANTES PHYSIQUES ET MATHEMATIQUES ---
    const double CST_COEFF_ROULEMENT   = 0.015;
    const double CST_MULTIPLICATEUR_F  = 10.0;
    const double CST_GRAVITE           = 9.81;
    const double CST_PI_SUR_180        = 3.14159 / 180.0;
    const double CST_CONVERSION_KMH_MS = 3.6;
    const double CST_CONVERSION_MS_S   = 1000.0;
    const double ZERO                  = 0.0;
    
    // --- LOGIQUE ---
    const double dt = DELTA_T_MS / CST_CONVERSION_MS_S; // 0.05 s
    
    if (ignition == false) {
        throttle = ZERO;
    }
    
    // 1. Force motrice / Frein moteur
    double forceMoteur = ZERO;
    
    if (throttle <= CST_RALENTI || ignition == false) {
        if (float_speed > 10.0) {
            // Au-dessus de 10 km/h pied lev� : couple r�sistant m�canique (frein moteur ~300 N)
            forceMoteur = -300.0;
        } else {
            // En dessous de 10 km/h : traction douce du ralenti pour ne pas caler
            forceMoteur = throttle * PUISSANCE;
        }
    } else {
        // Phase d'acc�l�ration active (p�dale ou r�gulateur)
        forceMoteur = throttle * PUISSANCE;
    }
    
    // 2. Calcul des forces r�sistantes (Unit�s SI : Newtons)
    const double vitesse_ms = float_speed / CST_CONVERSION_KMH_MS;
    
    // Tra�n�e a�rodynamique pure : F = (1/2 * rho * S * Cx) * v^2
    const double forceAir = AIR_DRAG * vitesse_ms * vitesse_ms;
    
    // Frottement au sol (roulement des pneumatiques)
    const double forceRoulement = CST_COEFF_ROULEMENT * MASSE * CST_GRAVITE * cos(alpha * CST_PI_SUR_180);
    
    // Gravit� le long de la pente
    const double forceGravite = MASSE * CST_GRAVITE * sin(alpha * CST_PI_SUR_180);
    
    // Frein m�canique progressif
    double pedale_frein = brakePedal;
    if (pedale_frein > MAX_BRAKE) pedale_frein = MAX_BRAKE;
    if (pedale_frein < ZERO) pedale_frein = ZERO;
    const double forceFrein = (pedale_frein / MAX_BRAKE) * (FORCE_FREINS * CST_MULTIPLICATEUR_F * MASSE / 100.0);
    
    // 3. Somme des forces et acc�l�ration Newtonienne (m/s�)
    const double forceTotale = forceMoteur - forceFrein - forceAir - forceRoulement - forceGravite;
    const double acceleration = forceTotale / MASSE;
    
    // 4. Int�gration temporelle et bridage
    float_speed += (acceleration * dt) * CST_CONVERSION_KMH_MS;
    
    if (float_speed > MAX_SPEED) float_speed = MAX_SPEED;
    if (float_speed < ZERO) float_speed = ZERO;
    
    float_distance += (float_speed / CST_CONVERSION_KMH_MS) * dt;
    
    speed = (int)float_speed;
    distance = (int)float_distance;
    //#]
}

void _SysVehicule::freiner_injection(double brakePedal) {
    NOTIFY_OPERATION(freiner_injection, freiner_injection(double), 1, _MonPkg__SysVehicule_freiner_injection_SERIALIZE);
    //#[ operation freiner_injection(double)
    if (throttle > throttle_repos) {
    	throttle = throttle_repos;
    }
    //#]
}

void _SysVehicule::init() {
    NOTIFY_OPERATION(init, init(), 0, _MonPkg__SysVehicule_init_SERIALIZE);
    //#[ operation init()
    speed=0;
    brakePedal=0;   
    accelPedal=0;
    float_speed=(double)speed;
    float_distance=(double)distance;
    
    const double MASSE                = (double)PARAM_SIMU_masse;
    const double PUISSANCE            = (double)PARAM_SIMU_puissance_moteur;
    const double AIR_DRAG             = PARAM_SIMU_frottement_air;
    const double VITESSE_REPOS        = (double)PARAM_SIMU_vitesse_repos;
    
    // Calcul du throttle de repos
    const double vit_repos_ms         = VITESSE_REPOS / 3.6;
    const double forceAir_repos       = AIR_DRAG * vit_repos_ms * vit_repos_ms;
    const double forceRoulement_repos = 0.015 * MASSE * 9.81;
    
    throttle_repos = (forceAir_repos + forceRoulement_repos) / PUISSANCE;
    throttle = throttle_repos;
    
    
    // Calcul des parametres du regulateur
    const double RATIO_CORRECTION_P   = PARAM_SIMU_Kp_regulateur;
    const double RATIO_LENTEUR_I      = PARAM_SIMU_Ki_regulateur;
    const double FREQ_REG             = (double)PARAM_SIMU_freq_regulateur;
    const double delta_v_par_throttle = (PUISSANCE / MASSE) * (1.0 / FREQ_REG) * 3.6;
    
    Kp_regulateur = RATIO_CORRECTION_P / delta_v_par_throttle;
    Ki_regulateur = (Kp_regulateur / RATIO_LENTEUR_I);
    //#]
}

_SysVehicule::~_SysVehicule() {
    NOTIFY_DESTRUCTOR(~_SysVehicule, true);
    cancelTimeouts();
}

bool _SysVehicule::get_simu() {
    return _simu;
}

void _SysVehicule::set_simu(bool p__simu) {
    _simu = p__simu;
}

double _SysVehicule::getAccelPedal() {
    return accelPedal;
}

void _SysVehicule::setAccelPedal(double p_accelPedal) {
    accelPedal = p_accelPedal;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getAlpha() {
    return alpha;
}

void _SysVehicule::setAlpha(int p_alpha) {
    alpha = p_alpha;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getBrakePedal() {
    return brakePedal;
}

void _SysVehicule::setBrakePedal(double p_brakePedal) {
    brakePedal = p_brakePedal;
    NOTIFY_SET_OPERATION;
}

int _SysVehicule::getDistance() {
    return distance;
}

void _SysVehicule::setDistance(int p_distance) {
    distance = p_distance;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getIgnition() {
    return ignition;
}

int _SysVehicule::getSpeed() {
    return speed;
}

double _SysVehicule::getSteady() {
    return steady;
}

void _SysVehicule::setSteady(double p_steady) {
    steady = p_steady;
}

double _SysVehicule::getThrottle() {
    return throttle;
}

int _SysVehicule::getVitesseConsigne() {
    return vitesseConsigne;
}

void _SysVehicule::setVitesseConsigne(int p_vitesseConsigne) {
    vitesseConsigne = p_vitesseConsigne;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::startBehavior() {
    bool done = false;
    done = OMReactive::startBehavior();
    if(done)
        {
            startDispatching();
        }
    return done;
}

_SysVehicule::_SysVehicule(IOxfActive* theActiveContext) : Ki_regulateur(0.0), Kp_regulateur(0.0), PARAM_SIMU_Ki_regulateur(1.0), PARAM_SIMU_Kp_regulateur(1), PARAM_SIMU_freq_rafraichissement(20), PARAM_SIMU_freq_regulateur(3), PARAM_SIMU_frottement_air(10), PARAM_SIMU_masse(800), PARAM_SIMU_max_accel(10), PARAM_SIMU_max_brake(10), PARAM_SIMU_max_speed(120), PARAM_SIMU_max_throttle(10.0), PARAM_SIMU_puissance_frein(100), PARAM_SIMU_puissance_moteur(1700), PARAM_SIMU_vitesse_repos(10), SEUIL_batterie(40.0), SEUIL_carburant(5.0), VOYANT_bluetooth_vehicule(false), VOYANT_telephone_appairage(false), VOYANT_telephone_connecte(false), VOYANT_vehicule_connectee(false), _simu(true), accelPedal(0.0), affichage_appairage("undefined"), affichage_liste_appareils("undefined"), alpha(0), batterie_faible(false), brakePedal(0.0), carburant_faible(false), champ_mdp(""), cmd_contact(false), distance(200000), float_distance(0.0), float_speed(0.0), ignition(false), limiteur_attente(false), limiteur_depasse(false), mot_de_passe("1234"), niveau_batterie(80.0), reservoir_carburant(40.0), speed(0), steady(0.0), throttle(0.0), throttle_repos(0.0), valeur_initiale_limiteur(50), vitesseConsigne(0), voyant_limiteur(false), voyant_regulateur(false) {
    NOTIFY_ACTIVE_CONSTRUCTOR(_SysVehicule, _SysVehicule(), 0, _MonPkg__SysVehicule__SysVehicule_SERIALIZE);
    setActiveContext(this, true);
    initStatechart();
    //#[ operation _SysVehicule()
    speed=0;
    brakePedal=0;   
    accelPedal=0;
    float_speed=(double)speed;
    float_distance=(double)distance;
    
    const double MASSE                = (double)PARAM_SIMU_masse;
    const double PUISSANCE            = (double)PARAM_SIMU_puissance_moteur;
    const double AIR_DRAG             = PARAM_SIMU_frottement_air;
    const double VITESSE_REPOS        = (double)PARAM_SIMU_vitesse_repos;
    
    // Calcul du throttle de repos
    const double vit_repos_ms         = VITESSE_REPOS / 3.6;
    const double forceAir_repos       = AIR_DRAG * vit_repos_ms * vit_repos_ms;
    const double forceRoulement_repos = 0.015 * MASSE * 9.81;
    
    throttle_repos = (forceAir_repos + forceRoulement_repos) / PUISSANCE;
    throttle = throttle_repos;
    
    
    // Calcul des parametres du regulateur
    const double RATIO_CORRECTION_P   = PARAM_SIMU_Kp_regulateur;
    const double RATIO_LENTEUR_I      = PARAM_SIMU_Ki_regulateur;
    const double FREQ_REG             = (double)PARAM_SIMU_freq_regulateur;
    const double delta_v_par_throttle = (PUISSANCE / MASSE) * (1.0 / FREQ_REG) * 3.6;
    
    Kp_regulateur = RATIO_CORRECTION_P / delta_v_par_throttle;
    Ki_regulateur = (Kp_regulateur / RATIO_LENTEUR_I);
    
    liste_appareils_detectes[0] = "Aucun appareil d�tect�";
    liste_appareils_detectes[1] = "Kit Bluetooth Vehicule";
    
    messages_appairage[0] = "Aucun appareil d�tect�";
    messages_appairage[1] = "Appareil non jumel�";
    messages_appairage[2] = "Entrez un mot de passe";
    messages_appairage[3] = "Mot de passe incorrect";
    messages_appairage[4] = "Appareil jumel�";
    //#]
}

void _SysVehicule::Operation_168() {
    NOTIFY_OPERATION(Operation_168, Operation_168(), 0, _MonPkg__SysVehicule_Operation_168_SERIALIZE);
    //#[ operation Operation_168()
    //#]
}

void _SysVehicule::alerte_depassement(int actif) {
    NOTIFY_OPERATION(alerte_depassement, alerte_depassement(int), 1, _MonPkg__SysVehicule_alerte_depassement_SERIALIZE);
    //#[ operation alerte_depassement(int)
    #include <windows.h>
    #pragma comment(lib, "winmm.lib")
    
    if (actif == 0) {
    	PlaySound(NULL, NULL, 0);
    	limiteur_depasse = false;
    } else {
    	PlaySound(TEXT("..\\..\\media\\alarme_incendie.wav"), NULL, SND_FILENAME | SND_ASYNC);
    	limiteur_depasse = true;
    }
    //#]
}

void _SysVehicule::calcul_batterie() {
    NOTIFY_OPERATION(calcul_batterie, calcul_batterie(), 0, _MonPkg__SysVehicule_calcul_batterie_SERIALIZE);
    //#[ operation calcul_batterie()
    // --- PARAMETRES ET CONSTANTES ---
    const int deltaTms                    = 1000 / PARAM_SIMU_freq_rafraichissement; // Division enti�re en ms
    const double dt                       = (double)deltaTms / 1000.0;               // En secondes pour la physique
    
    // Seuils d'injection
    const double SEUIL_THROTTLE_MIN       = 1.5;
    const double SEUIL_THROTTLE_MAX       = 5.0;
    
    // Taux de charge et d�charge physiques (% par seconde)
    const double TAUX_CHARGE_PAR_THROTTLE = 0.5;
    const double TAUX_CHARGE_MAX_SEC      = TAUX_CHARGE_PAR_THROTTLE * SEUIL_THROTTLE_MAX;
    const double TAUX_DECHARGE_SEC        = 0.25;
    
    // --- LOGIQUE ---
    double new_niveau_batterie = niveau_batterie;
    
    if (throttle > SEUIL_THROTTLE_MIN) {
        const double taux_charge = (throttle < SEUIL_THROTTLE_MAX)
                                   ? (TAUX_CHARGE_PAR_THROTTLE * throttle)
                                   : TAUX_CHARGE_MAX_SEC;
    
        new_niveau_batterie += taux_charge * dt;
        if (new_niveau_batterie > 100.0) {
            new_niveau_batterie = 100.0;
        }
    } else {
        new_niveau_batterie -= TAUX_DECHARGE_SEC * dt;
        if (new_niveau_batterie < 0.0) {
            new_niveau_batterie = 0.0;
        }
    }
    
    niveau_batterie = new_niveau_batterie;
    //#]
}

void _SysVehicule::calcul_carburant() {
    NOTIFY_OPERATION(calcul_carburant, calcul_carburant(), 0, _MonPkg__SysVehicule_calcul_carburant_SERIALIZE);
    //#[ operation calcul_carburant()
    const double COEF_CONSO = 0.005;
    
    double new_reservoir_carburant = reservoir_carburant;
    
    new_reservoir_carburant -= throttle*COEF_CONSO;
    
    if (new_reservoir_carburant < 0.0) {
    	new_reservoir_carburant = 0;
    } 
    
    reservoir_carburant = new_reservoir_carburant;
    //#]
}

void _SysVehicule::calcul_regulateur_vitesse() {
    NOTIFY_OPERATION(calcul_regulateur_vitesse, calcul_regulateur_vitesse(), 0, _MonPkg__SysVehicule_calcul_regulateur_vitesse_SERIALIZE);
    //#[ operation calcul_regulateur_vitesse()
    const double erreur = (double)vitesseConsigne+0.5 - (double)float_speed;
    
    steady += Ki_regulateur * erreur;
    
    if (steady > PARAM_SIMU_max_throttle) steady = PARAM_SIMU_max_throttle;
    if (steady < throttle_repos)          steady = throttle_repos;
    
    double commande = steady + (Kp_regulateur * erreur);
    
    if (commande > PARAM_SIMU_max_throttle) commande = PARAM_SIMU_max_throttle;
    if (commande < throttle_repos)          commande = throttle_repos;
    
    throttle = commande;
    //#]
}

void _SysVehicule::ex_depanner_batterie() {
    NOTIFY_OPERATION(ex_depanner_batterie, ex_depanner_batterie(), 0, _MonPkg__SysVehicule_ex_depanner_batterie_SERIALIZE);
    //#[ operation ex_depanner_batterie()
    if (niveau_batterie < SEUIL_batterie) {
    	niveau_batterie = SEUIL_batterie+15;
    }
    if (niveau_batterie > 100) {
    	niveau_batterie = 100;
    }
    //#]
}

void _SysVehicule::ex_jumeler() {
    NOTIFY_OPERATION(ex_jumeler, ex_jumeler(), 0, _MonPkg__SysVehicule_ex_jumeler_SERIALIZE);
    //#[ operation ex_jumeler()
    //#]
}

void _SysVehicule::ex_ok() {
    NOTIFY_OPERATION(ex_ok, ex_ok(), 0, _MonPkg__SysVehicule_ex_ok_SERIALIZE);
    //#[ operation ex_ok()
    //#]
}

void _SysVehicule::ex_remplir_carburant() {
    NOTIFY_OPERATION(ex_remplir_carburant, ex_remplir_carburant(), 0, _MonPkg__SysVehicule_ex_remplir_carburant_SERIALIZE);
    //#[ operation ex_remplir_carburant()
    double new_reservoir_carburant = reservoir_carburant;
    
    new_reservoir_carburant += 5;
    
    if (new_reservoir_carburant > 50.0) {
    	new_reservoir_carburant = 50;
    } 
    
    reservoir_carburant = new_reservoir_carburant;
    //#]
}

void _SysVehicule::ex_vitesseConsigne(int delta) {
    NOTIFY_OPERATION(ex_vitesseConsigne, ex_vitesseConsigne(int), 1, _MonPkg__SysVehicule_ex_vitesseConsigne_SERIALIZE);
    //#[ operation ex_vitesseConsigne(int)
    vitesseConsigne += delta;
    
    if (vitesseConsigne > PARAM_SIMU_max_speed) {
    	vitesseConsigne = PARAM_SIMU_max_speed;
    }
    if (vitesseConsigne < 0) {
    	vitesseConsigne = 0;
    }
    //#]
}

void _SysVehicule::regulateur_Prof() {
    NOTIFY_OPERATION(regulateur_Prof, regulateur_Prof(), 0, _MonPkg__SysVehicule_regulateur_Prof_SERIALIZE);
    //#[ operation regulateur_Prof()
    const double erreur = (double)(vitesseConsigne)+0.5 - float_speed;
    
    const double K_cube = PARAM_SIMU_Kp_regulateur;
    throttle += K_cube * erreur;
    
    if (throttle > PARAM_SIMU_max_throttle) throttle = PARAM_SIMU_max_throttle;
    if (throttle < throttle_repos)          throttle = throttle_repos;
    //#]
}

double _SysVehicule::getKi_regulateur() {
    return Ki_regulateur;
}

void _SysVehicule::setKi_regulateur(double p_Ki_regulateur) {
    Ki_regulateur = p_Ki_regulateur;
}

double _SysVehicule::getKp_regulateur() {
    return Kp_regulateur;
}

void _SysVehicule::setKp_regulateur(double p_Kp_regulateur) {
    Kp_regulateur = p_Kp_regulateur;
}

double _SysVehicule::getPARAM_SIMU_Ki_regulateur() {
    return PARAM_SIMU_Ki_regulateur;
}

void _SysVehicule::setPARAM_SIMU_Ki_regulateur(double p_PARAM_SIMU_Ki_regulateur) {
    PARAM_SIMU_Ki_regulateur = p_PARAM_SIMU_Ki_regulateur;
}

double _SysVehicule::getPARAM_SIMU_Kp_regulateur() {
    return PARAM_SIMU_Kp_regulateur;
}

void _SysVehicule::setPARAM_SIMU_Kp_regulateur(double p_PARAM_SIMU_Kp_regulateur) {
    PARAM_SIMU_Kp_regulateur = p_PARAM_SIMU_Kp_regulateur;
}

int _SysVehicule::getPARAM_SIMU_freq_rafraichissement() {
    return PARAM_SIMU_freq_rafraichissement;
}

void _SysVehicule::setPARAM_SIMU_freq_rafraichissement(int p_PARAM_SIMU_freq_rafraichissement) {
    PARAM_SIMU_freq_rafraichissement = p_PARAM_SIMU_freq_rafraichissement;
}

int _SysVehicule::getPARAM_SIMU_freq_regulateur() {
    return PARAM_SIMU_freq_regulateur;
}

void _SysVehicule::setPARAM_SIMU_freq_regulateur(int p_PARAM_SIMU_freq_regulateur) {
    PARAM_SIMU_freq_regulateur = p_PARAM_SIMU_freq_regulateur;
}

double _SysVehicule::getPARAM_SIMU_frottement_air() {
    return PARAM_SIMU_frottement_air;
}

void _SysVehicule::setPARAM_SIMU_frottement_air(double p_PARAM_SIMU_frottement_air) {
    PARAM_SIMU_frottement_air = p_PARAM_SIMU_frottement_air;
}

int _SysVehicule::getPARAM_SIMU_masse() {
    return PARAM_SIMU_masse;
}

void _SysVehicule::setPARAM_SIMU_masse(int p_PARAM_SIMU_masse) {
    PARAM_SIMU_masse = p_PARAM_SIMU_masse;
}

int _SysVehicule::getPARAM_SIMU_max_accel() {
    return PARAM_SIMU_max_accel;
}

void _SysVehicule::setPARAM_SIMU_max_accel(int p_PARAM_SIMU_max_accel) {
    PARAM_SIMU_max_accel = p_PARAM_SIMU_max_accel;
}

int _SysVehicule::getPARAM_SIMU_max_brake() {
    return PARAM_SIMU_max_brake;
}

void _SysVehicule::setPARAM_SIMU_max_brake(int p_PARAM_SIMU_max_brake) {
    PARAM_SIMU_max_brake = p_PARAM_SIMU_max_brake;
}

int _SysVehicule::getPARAM_SIMU_max_speed() {
    return PARAM_SIMU_max_speed;
}

void _SysVehicule::setPARAM_SIMU_max_speed(int p_PARAM_SIMU_max_speed) {
    PARAM_SIMU_max_speed = p_PARAM_SIMU_max_speed;
}

double _SysVehicule::getPARAM_SIMU_max_throttle() {
    return PARAM_SIMU_max_throttle;
}

void _SysVehicule::setPARAM_SIMU_max_throttle(double p_PARAM_SIMU_max_throttle) {
    PARAM_SIMU_max_throttle = p_PARAM_SIMU_max_throttle;
}

int _SysVehicule::getPARAM_SIMU_puissance_frein() {
    return PARAM_SIMU_puissance_frein;
}

void _SysVehicule::setPARAM_SIMU_puissance_frein(int p_PARAM_SIMU_puissance_frein) {
    PARAM_SIMU_puissance_frein = p_PARAM_SIMU_puissance_frein;
}

int _SysVehicule::getPARAM_SIMU_puissance_moteur() {
    return PARAM_SIMU_puissance_moteur;
}

void _SysVehicule::setPARAM_SIMU_puissance_moteur(int p_PARAM_SIMU_puissance_moteur) {
    PARAM_SIMU_puissance_moteur = p_PARAM_SIMU_puissance_moteur;
}

int _SysVehicule::getPARAM_SIMU_vitesse_repos() {
    return PARAM_SIMU_vitesse_repos;
}

void _SysVehicule::setPARAM_SIMU_vitesse_repos(int p_PARAM_SIMU_vitesse_repos) {
    PARAM_SIMU_vitesse_repos = p_PARAM_SIMU_vitesse_repos;
}

double _SysVehicule::getSEUIL_batterie() {
    return SEUIL_batterie;
}

void _SysVehicule::setSEUIL_batterie(double p_SEUIL_batterie) {
    SEUIL_batterie = p_SEUIL_batterie;
}

double _SysVehicule::getSEUIL_carburant() {
    return SEUIL_carburant;
}

void _SysVehicule::setSEUIL_carburant(double p_SEUIL_carburant) {
    SEUIL_carburant = p_SEUIL_carburant;
}

bool _SysVehicule::getVOYANT_bluetooth_vehicule() {
    return VOYANT_bluetooth_vehicule;
}

void _SysVehicule::setVOYANT_bluetooth_vehicule(bool p_VOYANT_bluetooth_vehicule) {
    VOYANT_bluetooth_vehicule = p_VOYANT_bluetooth_vehicule;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_appairage() {
    return VOYANT_telephone_appairage;
}

void _SysVehicule::setVOYANT_telephone_appairage(bool p_VOYANT_telephone_appairage) {
    VOYANT_telephone_appairage = p_VOYANT_telephone_appairage;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_telephone_connecte() {
    return VOYANT_telephone_connecte;
}

void _SysVehicule::setVOYANT_telephone_connecte(bool p_VOYANT_telephone_connecte) {
    VOYANT_telephone_connecte = p_VOYANT_telephone_connecte;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVOYANT_vehicule_connectee() {
    return VOYANT_vehicule_connectee;
}

void _SysVehicule::setVOYANT_vehicule_connectee(bool p_VOYANT_vehicule_connectee) {
    VOYANT_vehicule_connectee = p_VOYANT_vehicule_connectee;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getAffichage_appairage() {
    return affichage_appairage;
}

void _SysVehicule::setAffichage_appairage(OMString p_affichage_appairage) {
    affichage_appairage = p_affichage_appairage;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getAffichage_liste_appareils() {
    return affichage_liste_appareils;
}

void _SysVehicule::setAffichage_liste_appareils(OMString p_affichage_liste_appareils) {
    affichage_liste_appareils = p_affichage_liste_appareils;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getBatterie_faible() {
    return batterie_faible;
}

void _SysVehicule::setBatterie_faible(bool p_batterie_faible) {
    batterie_faible = p_batterie_faible;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCarburant_faible() {
    return carburant_faible;
}

void _SysVehicule::setCarburant_faible(bool p_carburant_faible) {
    carburant_faible = p_carburant_faible;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getChamp_mdp() {
    return champ_mdp;
}

void _SysVehicule::setChamp_mdp(OMString p_champ_mdp) {
    champ_mdp = p_champ_mdp;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getCmd_contact() {
    return cmd_contact;
}

void _SysVehicule::setCmd_contact(bool p_cmd_contact) {
    cmd_contact = p_cmd_contact;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getFloat_distance() {
    return float_distance;
}

void _SysVehicule::setFloat_distance(double p_float_distance) {
    float_distance = p_float_distance;
}

double _SysVehicule::getFloat_speed() {
    return float_speed;
}

void _SysVehicule::setFloat_speed(double p_float_speed) {
    float_speed = p_float_speed;
}

void _SysVehicule::setIgnition(bool p_ignition) {
    ignition = p_ignition;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getLimiteur_attente() {
    return limiteur_attente;
}

void _SysVehicule::setLimiteur_attente(bool p_limiteur_attente) {
    limiteur_attente = p_limiteur_attente;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getLimiteur_depasse() {
    return limiteur_depasse;
}

void _SysVehicule::setLimiteur_depasse(bool p_limiteur_depasse) {
    limiteur_depasse = p_limiteur_depasse;
    NOTIFY_SET_OPERATION;
}

OMString _SysVehicule::getListe_appareils_detectes(int i1) {
    return liste_appareils_detectes[i1];
}

void _SysVehicule::setListe_appareils_detectes(int i1, OMString p_liste_appareils_detectes) {
    liste_appareils_detectes[i1] = p_liste_appareils_detectes;
}

OMString _SysVehicule::getMessages_appairage(int i1) {
    return messages_appairage[i1];
}

void _SysVehicule::setMessages_appairage(int i1, OMString p_messages_appairage) {
    messages_appairage[i1] = p_messages_appairage;
}

OMString _SysVehicule::getMot_de_passe() {
    return mot_de_passe;
}

void _SysVehicule::setMot_de_passe(OMString p_mot_de_passe) {
    mot_de_passe = p_mot_de_passe;
}

double _SysVehicule::getNiveau_batterie() {
    return niveau_batterie;
}

void _SysVehicule::setNiveau_batterie(double p_niveau_batterie) {
    niveau_batterie = p_niveau_batterie;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getReservoir_carburant() {
    return reservoir_carburant;
}

void _SysVehicule::setReservoir_carburant(double p_reservoir_carburant) {
    reservoir_carburant = p_reservoir_carburant;
    NOTIFY_SET_OPERATION;
}

void _SysVehicule::setSpeed(int p_speed) {
    speed = p_speed;
    NOTIFY_SET_OPERATION;
}

void _SysVehicule::setThrottle(double p_throttle) {
    throttle = p_throttle;
    NOTIFY_SET_OPERATION;
}

double _SysVehicule::getThrottle_repos() {
    return throttle_repos;
}

void _SysVehicule::setThrottle_repos(double p_throttle_repos) {
    throttle_repos = p_throttle_repos;
}

int _SysVehicule::getValeur_initiale_limiteur() {
    return valeur_initiale_limiteur;
}

void _SysVehicule::setValeur_initiale_limiteur(int p_valeur_initiale_limiteur) {
    valeur_initiale_limiteur = p_valeur_initiale_limiteur;
}

bool _SysVehicule::getVoyant_limiteur() {
    return voyant_limiteur;
}

void _SysVehicule::setVoyant_limiteur(bool p_voyant_limiteur) {
    voyant_limiteur = p_voyant_limiteur;
    NOTIFY_SET_OPERATION;
}

bool _SysVehicule::getVoyant_regulateur() {
    return voyant_regulateur;
}

void _SysVehicule::setVoyant_regulateur(bool p_voyant_regulateur) {
    voyant_regulateur = p_voyant_regulateur;
    NOTIFY_SET_OPERATION;
}

void _SysVehicule::initStatechart() {
    rootState_subState = OMNonState;
    rootState_active = OMNonState;
    state_96_subState = OMNonState;
    state_96_active = OMNonState;
    state_87_subState = OMNonState;
    state_87_active = OMNonState;
    state_87_timeout = NULL;
    bluetooth_active_subState = OMNonState;
    bluetooth_active_timeout = NULL;
    state_76_subState = OMNonState;
    state_76_active = OMNonState;
    state_82_subState = OMNonState;
    state_82_active = OMNonState;
    state_82_timeout = NULL;
    maintien_consigne_subState = OMNonState;
    maintien_consigne_timeout = NULL;
    state_81_subState = OMNonState;
    state_81_active = OMNonState;
    state_75_subState = OMNonState;
    state_75_active = OMNonState;
    state_72_subState = OMNonState;
    state_72_active = OMNonState;
    state_71_subState = OMNonState;
    state_71_active = OMNonState;
    mode_regulateur_subState = OMNonState;
    state_62_subState = OMNonState;
    state_62_active = OMNonState;
    state_62_timeout = NULL;
    state_61_subState = OMNonState;
    state_61_active = OMNonState;
    contact_on_subState = OMNonState;
    contact_on_lastState = OMNonState;
    state_61_timeout = NULL;
    state_60_subState = OMNonState;
    state_60_active = OMNonState;
    state_60_timeout = NULL;
    pedales_subState = OMNonState;
    pedales_timeout = NULL;
}

void _SysVehicule::cancelTimeouts() {
    cancel(state_87_timeout);
    cancel(bluetooth_active_timeout);
    cancel(state_82_timeout);
    cancel(maintien_consigne_timeout);
    cancel(state_62_timeout);
    cancel(state_61_timeout);
    cancel(state_60_timeout);
    cancel(pedales_timeout);
}

bool _SysVehicule::cancelTimeout(const IOxfTimeout* arg) {
    bool res = false;
    if(state_87_timeout == arg)
        {
            state_87_timeout = NULL;
            res = true;
        }
    if(bluetooth_active_timeout == arg)
        {
            bluetooth_active_timeout = NULL;
            res = true;
        }
    if(state_82_timeout == arg)
        {
            state_82_timeout = NULL;
            res = true;
        }
    if(maintien_consigne_timeout == arg)
        {
            maintien_consigne_timeout = NULL;
            res = true;
        }
    if(state_62_timeout == arg)
        {
            state_62_timeout = NULL;
            res = true;
        }
    if(state_61_timeout == arg)
        {
            state_61_timeout = NULL;
            res = true;
        }
    if(state_60_timeout == arg)
        {
            state_60_timeout = NULL;
            res = true;
        }
    if(pedales_timeout == arg)
        {
            pedales_timeout = NULL;
            res = true;
        }
    return res;
}

void _SysVehicule::rootState_entDef() {
    {
        NOTIFY_STATE_ENTERED("ROOT");
        rootStateEntDef();
    }
}

void _SysVehicule::rootStateEntDef() {
    NOTIFY_TRANSITION_STARTED("0");
    Systeme_entDef();
    NOTIFY_TRANSITION_TERMINATED("0");
}

void _SysVehicule::rootState_exit() {
    // State Systeme
    if(rootState_subState == Systeme)
        {
            Systeme_exit();
        }
    rootState_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT");
}

IOxfReactive::TakeEventStatus _SysVehicule::rootState_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State Systeme
    if(rootState_active == Systeme)
        {
            res = Systeme_processEvent();
        }
    return res;
}

void _SysVehicule::Systeme_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme");
    rootState_subState = Systeme;
    rootState_active = Systeme;
    state_60_entDef();
    state_61_entDef();
    state_62_entDef();
    state_71_entDef();
    state_72_entDef();
    state_75_entDef();
    state_76_entDef();
    state_87_entDef();
    state_96_entDef();
}

void _SysVehicule::Systeme_exit() {
    switch (state_60_subState) {
        // State pedales
        case pedales:
        {
            switch (pedales_subState) {
                // State freinage_injection
                case freinage_injection:
                {
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                }
                break;
                // State acceleration
                case acceleration:
                {
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                }
                break;
                default:
                    break;
            }
            pedales_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales");
        }
        break;
        // State regulateur
        case regulateur:
        {
            cancel(state_60_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur");
        }
        break;
        default:
            break;
    }
    state_60_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60");
    switch (state_61_subState) {
        // State contact_off
        case contact_off:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_off");
        }
        break;
        // State contact_on
        case contact_on:
        {
            contact_on_lastState = contact_on_subState;
            switch (contact_on_subState) {
                // State moteur_off
                case moteur_off:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_off");
                    contact_on_lastState = moteur_off;
                }
                break;
                // State moteur_on
                case moteur_on:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_on");
                    contact_on_lastState = moteur_on;
                }
                break;
                default:
                    break;
            }
            contact_on_subState = OMNonState;
            cancel(state_61_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on");
        }
        break;
        default:
            break;
    }
    state_61_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61");
    state_62_exit();
    switch (state_71_subState) {
        // State mode_manuel
        case mode_manuel:
        {
            //#[ state Systeme.state_71.mode_manuel.(Exit) 
            voyant_regulateur = true;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_manuel");
        }
        break;
        // State mode_regulateur
        case mode_regulateur:
        {
            switch (mode_regulateur_subState) {
                // State maintien
                case maintien:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                }
                break;
                // State plus
                case plus:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                }
                break;
                // State moins
                case moins:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                }
                break;
                default:
                    break;
            }
            mode_regulateur_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
        }
        break;
        default:
            break;
    }
    state_71_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71");
    state_72_exit();
    state_75_exit();
    switch (state_76_subState) {
        // State limiteur_on
        case limiteur_on:
        {
            limiteur_on_exit();
        }
        break;
        // State limiteur_off
        case limiteur_off:
        {
            //#[ state Systeme.state_76.limiteur_off.(Exit) 
            voyant_limiteur = true;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_off");
        }
        break;
        default:
            break;
    }
    state_76_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76");
    switch (state_87_subState) {
        // State bluetooth_desactive
        case bluetooth_desactive:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_desactive");
        }
        break;
        // State bluetooth_active
        case bluetooth_active:
        {
            switch (bluetooth_active_subState) {
                // State recherche_telephone
                case recherche_telephone:
                {
                    cancel(bluetooth_active_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                }
                break;
                // State telephone_connecte
                case telephone_connecte:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
                }
                break;
                default:
                    break;
            }
            bluetooth_active_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active");
        }
        break;
        // State demarrage_bluetooth
        case demarrage_bluetooth:
        {
            cancel(state_87_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.demarrage_bluetooth");
        }
        break;
        default:
            break;
    }
    state_87_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87");
    switch (state_96_subState) {
        // State initerfsegb
        case initerfsegb:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.initerfsegb");
        }
        break;
        // State voy
        case voy:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.voy");
        }
        break;
        default:
            break;
    }
    state_96_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme");
}

IOxfReactive::TakeEventStatus _SysVehicule::Systeme_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_60
    if(state_60_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_61
    if(state_61_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_62
    if(state_62_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_71
    if(state_71_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_72
    if(state_72_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_75
    if(state_75_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_76
    if(state_76_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_87
    if(state_87_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    // State state_96
    if(state_96_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(Systeme))
                {
                    return res;
                }
        }
    
    return res;
}

void _SysVehicule::state_96_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96");
    NOTIFY_TRANSITION_STARTED("64");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.initerfsegb");
    state_96_subState = initerfsegb;
    state_96_active = initerfsegb;
    NOTIFY_TRANSITION_TERMINATED("64");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_96_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State initerfsegb
    if(state_96_active == initerfsegb)
        {
            if(IS_EVENT_TYPE_OF(ev_kit_vehicule_pret__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("63");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_96.initerfsegb");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_96.voy");
                    state_96_subState = voy;
                    state_96_active = voy;
                    //#[ state Systeme.state_96.voy.(Entry) 
                    VOYANT_vehicule_connecte = true;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("63");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_87_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87");
    NOTIFY_TRANSITION_STARTED("57");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_desactive");
    state_87_subState = bluetooth_desactive;
    state_87_active = bluetooth_desactive;
    //#[ state Systeme.state_87.bluetooth_desactive.(Entry) 
    VOYANT_bluetooth_vehicule = false;
    //#]
    NOTIFY_TRANSITION_TERMINATED("57");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_87_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_87_active) {
        // State bluetooth_desactive
        case bluetooth_desactive:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 58 
                    if( IS_IN(contact_on))
                        {
                            NOTIFY_TRANSITION_STARTED("58");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_desactive");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.demarrage_bluetooth");
                            state_87_subState = demarrage_bluetooth;
                            state_87_active = demarrage_bluetooth;
                            state_87_timeout = scheduleTimeout(325, "ROOT.Systeme.state_87.demarrage_bluetooth");
                            NOTIFY_TRANSITION_TERMINATED("58");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State recherche_telephone
        case recherche_telephone:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == bluetooth_active_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("62");
                            cancel(bluetooth_active_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                            bluetooth_active_subState = recherche_telephone;
                            state_87_active = recherche_telephone;
                            //#[ state Systeme.state_87.bluetooth_active.recherche_telephone.(Entry) 
                            GEN(ev_kit_vehicule_pret);
                            //#]
                            bluetooth_active_timeout = scheduleTimeout(500, "ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                            NOTIFY_TRANSITION_TERMINATED("62");
                            res = eventConsumed;
                        }
                }
            
            if(res == eventNotConsumed)
                {
                    res = bluetooth_active_handleEvent();
                }
        }
        break;
        // State telephone_connecte
        case telephone_connecte:
        {
            res = bluetooth_active_handleEvent();
        }
        break;
        // State demarrage_bluetooth
        case demarrage_bluetooth:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_87_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("60");
                            cancel(state_87_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.demarrage_bluetooth");
                            bluetooth_active_entDef();
                            NOTIFY_TRANSITION_TERMINATED("60");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::bluetooth_active_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active");
    state_87_subState = bluetooth_active;
    //#[ state Systeme.state_87.bluetooth_active.(Entry) 
    VOYANT_bluetooth_vehicule = true;
    //#]
    NOTIFY_TRANSITION_STARTED("61");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
    bluetooth_active_subState = recherche_telephone;
    state_87_active = recherche_telephone;
    //#[ state Systeme.state_87.bluetooth_active.recherche_telephone.(Entry) 
    GEN(ev_kit_vehicule_pret);
    //#]
    bluetooth_active_timeout = scheduleTimeout(500, "ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
    NOTIFY_TRANSITION_TERMINATED("61");
}

IOxfReactive::TakeEventStatus _SysVehicule::bluetooth_active_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 59 
            if(IS_IN(contact_on))
                {
                    NOTIFY_TRANSITION_STARTED("59");
                    switch (bluetooth_active_subState) {
                        // State recherche_telephone
                        case recherche_telephone:
                        {
                            cancel(bluetooth_active_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
                        }
                        break;
                        // State telephone_connecte
                        case telephone_connecte:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
                        }
                        break;
                        default:
                            break;
                    }
                    bluetooth_active_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_87.bluetooth_active");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_87.bluetooth_desactive");
                    state_87_subState = bluetooth_desactive;
                    state_87_active = bluetooth_desactive;
                    //#[ state Systeme.state_87.bluetooth_desactive.(Entry) 
                    VOYANT_bluetooth_vehicule = false;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("59");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_76_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76");
    NOTIFY_TRANSITION_STARTED("39");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
    state_76_subState = limiteur_off;
    state_76_active = limiteur_off;
    //#[ state Systeme.state_76.limiteur_off.(Entry) 
    voyant_limiteur = false;
    alerte_depassement(0);
    //#]
    NOTIFY_TRANSITION_TERMINATED("39");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_76_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_76_active) {
        // State limiteur_on
        case limiteur_on:
        {
            res = limiteur_on_processEvent();
        }
        break;
        // State limiteur_off
        case limiteur_off:
        {
            res = limiteur_off_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::limiteur_on_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on");
    state_76_subState = limiteur_on;
    state_76_active = limiteur_on;
    state_81_entDef();
    state_82_entDef();
}

void _SysVehicule::limiteur_on_exit() {
    switch (state_81_subState) {
        // State limiteur_inhibe
        case limiteur_inhibe:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_inhibe");
        }
        break;
        // State limiteur_effectif
        case limiteur_effectif:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_effectif");
        }
        break;
        default:
            break;
    }
    state_81_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_81");
    switch (state_82_subState) {
        // State maintien_consigne
        case maintien_consigne:
        {
            switch (maintien_consigne_subState) {
                // State limite_tenue
                case limite_tenue:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                }
                break;
                // State depassement
                case depassement:
                {
                    //#[ state Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement.(Exit) 
                    alerte_depassement(0);
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement");
                }
                break;
                // State stabilisation
                case stabilisation:
                {
                    cancel(maintien_consigne_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
                }
                break;
                default:
                    break;
            }
            maintien_consigne_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne");
        }
        break;
        // State plus
        case state_82_plus:
        {
            cancel(state_82_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.plus");
        }
        break;
        // State moins
        case state_82_moins:
        {
            cancel(state_82_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.moins");
        }
        break;
        default:
            break;
    }
    state_82_subState = OMNonState;
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82");
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on");
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_on_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State state_81
    if(state_81_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(limiteur_on))
                {
                    return res;
                }
        }
    // State state_82
    if(state_82_processEvent() != eventNotConsumed)
        {
            res = eventConsumed;
            if(!IS_IN(limiteur_on))
                {
                    return res;
                }
        }
    if(res == eventNotConsumed)
        {
            res = limiteur_on_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_on_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_regulateur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("52");
            limiteur_on_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
            state_76_subState = limiteur_off;
            state_76_active = limiteur_off;
            //#[ state Systeme.state_76.limiteur_off.(Entry) 
            voyant_limiteur = false;
            alerte_depassement(0);
            //#]
            NOTIFY_TRANSITION_TERMINATED("52");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_limiteur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("46");
            limiteur_on_exit();
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
            state_76_subState = limiteur_off;
            state_76_active = limiteur_off;
            //#[ state Systeme.state_76.limiteur_off.(Entry) 
            voyant_limiteur = false;
            alerte_depassement(0);
            //#]
            NOTIFY_TRANSITION_TERMINATED("46");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 29 
            if( IS_IN(moteur_off) || ((vitesseConsigne-speed)    < 10 && accelPedal > 7))
                {
                    NOTIFY_TRANSITION_STARTED("29");
                    limiteur_on_exit();
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_off");
                    state_76_subState = limiteur_off;
                    state_76_active = limiteur_off;
                    //#[ state Systeme.state_76.limiteur_off.(Entry) 
                    voyant_limiteur = false;
                    alerte_depassement(0);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("29");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_82_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82");
    NOTIFY_TRANSITION_STARTED("31");
    //#[ transition 31 
    vitesseConsigne = valeur_initiale_limiteur;
    //#]
    maintien_consigne_entDef();
    NOTIFY_TRANSITION_TERMINATED("31");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_82_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_82_active) {
        // State limite_tenue
        case limite_tenue:
        {
            res = limite_tenue_handleEvent();
        }
        break;
        // State depassement
        case depassement:
        {
            res = depassement_handleEvent();
        }
        break;
        // State stabilisation
        case stabilisation:
        {
            res = stabilisation_handleEvent();
        }
        break;
        // State plus
        case state_82_plus:
        {
            res = state_82_plus_handleEvent();
        }
        break;
        // State moins
        case state_82_moins:
        {
            res = state_82_moins_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::state_82_plus_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == state_82_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("36");
                    cancel(state_82_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.plus");
                    maintien_consigne_entDef();
                    NOTIFY_TRANSITION_TERMINATED("36");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_plus__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("33");
            cancel(state_82_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.plus");
            //#[ transition 33 
            ex_vitesseConsigne(+9);
            //#]
            maintien_consigne_entDef();
            NOTIFY_TRANSITION_TERMINATED("33");
            res = eventConsumed;
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::state_82_moins_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == state_82_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("37");
                    cancel(state_82_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.moins");
                    maintien_consigne_entDef();
                    NOTIFY_TRANSITION_TERMINATED("37");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_moins__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("35");
            cancel(state_82_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.moins");
            //#[ transition 35 
            ex_vitesseConsigne(-9);
            //#]
            maintien_consigne_entDef();
            NOTIFY_TRANSITION_TERMINATED("35");
            res = eventConsumed;
        }
    
    
    return res;
}

void _SysVehicule::maintien_consigne_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne");
    state_82_subState = maintien_consigne;
    NOTIFY_TRANSITION_STARTED("50");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
    maintien_consigne_subState = stabilisation;
    state_82_active = stabilisation;
    maintien_consigne_timeout = scheduleTimeout(2000, "ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
    NOTIFY_TRANSITION_TERMINATED("50");
}

IOxfReactive::TakeEventStatus _SysVehicule::maintien_consigne_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_plus__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("32");
            switch (maintien_consigne_subState) {
                // State limite_tenue
                case limite_tenue:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                }
                break;
                // State depassement
                case depassement:
                {
                    //#[ state Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement.(Exit) 
                    alerte_depassement(0);
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement");
                }
                break;
                // State stabilisation
                case stabilisation:
                {
                    cancel(maintien_consigne_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
                }
                break;
                default:
                    break;
            }
            maintien_consigne_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.plus");
            state_82_subState = state_82_plus;
            state_82_active = state_82_plus;
            //#[ state Systeme.state_76.limiteur_on.state_82.plus.(Entry) 
            ex_vitesseConsigne(+1);
            //#]
            state_82_timeout = scheduleTimeout(500, "ROOT.Systeme.state_76.limiteur_on.state_82.plus");
            NOTIFY_TRANSITION_TERMINATED("32");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_moins__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("34");
            switch (maintien_consigne_subState) {
                // State limite_tenue
                case limite_tenue:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                }
                break;
                // State depassement
                case depassement:
                {
                    //#[ state Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement.(Exit) 
                    alerte_depassement(0);
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement");
                }
                break;
                // State stabilisation
                case stabilisation:
                {
                    cancel(maintien_consigne_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
                }
                break;
                default:
                    break;
            }
            maintien_consigne_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.moins");
            state_82_subState = state_82_moins;
            state_82_active = state_82_moins;
            //#[ state Systeme.state_76.limiteur_on.state_82.moins.(Entry) 
            ex_vitesseConsigne(-1);
            //#]
            state_82_timeout = scheduleTimeout(500, "ROOT.Systeme.state_76.limiteur_on.state_82.moins");
            NOTIFY_TRANSITION_TERMINATED("34");
            res = eventConsumed;
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::stabilisation_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == maintien_consigne_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("51");
                    cancel(maintien_consigne_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                    maintien_consigne_subState = limite_tenue;
                    state_82_active = limite_tenue;
                    NOTIFY_TRANSITION_TERMINATED("51");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 49 
            if( vitesseConsigne  == speed)
                {
                    NOTIFY_TRANSITION_STARTED("49");
                    cancel(maintien_consigne_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                    maintien_consigne_subState = limite_tenue;
                    state_82_active = limite_tenue;
                    NOTIFY_TRANSITION_TERMINATED("49");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = maintien_consigne_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limite_tenue_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 47 
            if( vitesseConsigne < speed-3)
                {
                    NOTIFY_TRANSITION_STARTED("47");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement");
                    maintien_consigne_subState = depassement;
                    state_82_active = depassement;
                    //#[ state Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement.(Entry) 
                    alerte_depassement(1);
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("47");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = maintien_consigne_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::depassement_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 48 
            if( vitesseConsigne  == speed)
                {
                    NOTIFY_TRANSITION_STARTED("48");
                    //#[ state Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement.(Exit) 
                    alerte_depassement(0);
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
                    maintien_consigne_subState = limite_tenue;
                    state_82_active = limite_tenue;
                    NOTIFY_TRANSITION_TERMINATED("48");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = maintien_consigne_handleEvent();
        }
    return res;
}

void _SysVehicule::state_81_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_81");
    NOTIFY_TRANSITION_STARTED("54");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_inhibe");
    state_81_subState = limiteur_inhibe;
    state_81_active = limiteur_inhibe;
    //#[ state Systeme.state_76.limiteur_on.state_81.limiteur_inhibe.(Entry) 
    limiteur_attente = true;
    //#]
    NOTIFY_TRANSITION_TERMINATED("54");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_81_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_81_active) {
        // State limiteur_inhibe
        case limiteur_inhibe:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 55 
                    if(speed <  vitesseConsigne)
                        {
                            NOTIFY_TRANSITION_STARTED("55");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_inhibe");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_effectif");
                            state_81_subState = limiteur_effectif;
                            state_81_active = limiteur_effectif;
                            //#[ state Systeme.state_76.limiteur_on.state_81.limiteur_effectif.(Entry) 
                            limiteur_attente = false;
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("55");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State limiteur_effectif
        case limiteur_effectif:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 56 
                    if(speed >=  vitesseConsigne + 3)
                        {
                            NOTIFY_TRANSITION_STARTED("56");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_effectif");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_inhibe");
                            state_81_subState = limiteur_inhibe;
                            state_81_active = limiteur_inhibe;
                            //#[ state Systeme.state_76.limiteur_on.state_81.limiteur_inhibe.(Entry) 
                            limiteur_attente = true;
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("56");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::limiteur_off_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_limiteur__MonPkg_id))
        {
            //## transition 30 
            if( IS_IN(moteur_on))
                {
                    NOTIFY_TRANSITION_STARTED("30");
                    //#[ state Systeme.state_76.limiteur_off.(Exit) 
                    voyant_limiteur = true;
                    //#]
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_76.limiteur_off");
                    limiteur_on_entDef();
                    NOTIFY_TRANSITION_TERMINATED("30");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

void _SysVehicule::state_75_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75");
    NOTIFY_TRANSITION_STARTED("28");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.fonctionelle");
    state_75_subState = fonctionelle;
    state_75_active = fonctionelle;
    NOTIFY_TRANSITION_TERMINATED("28");
}

void _SysVehicule::state_75_exit() {
    switch (state_75_subState) {
        // State fonctionelle
        case fonctionelle:
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.fonctionelle");
        }
        break;
        // State panne_carburant
        case panne_carburant:
        {
            //#[ state Systeme.state_75.panne_carburant.(Exit) 
            carburant_faible = false;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.panne_carburant");
        }
        break;
        // State panne_batterie
        case panne_batterie:
        {
            //#[ state Systeme.state_75.panne_batterie.(Exit) 
            batterie_faible = false;
            //#]
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.panne_batterie");
        }
        break;
        // State remplir_carburant
        case remplir_carburant:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.remplir_carburant");
        }
        break;
        // State depanner_batterie
        case depanner_batterie:
        {
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.depanner_batterie");
        }
        break;
        default:
            break;
    }
    state_75_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_75");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_75_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_75_active) {
        // State fonctionelle
        case fonctionelle:
        {
            if(IS_EVENT_TYPE_OF(ev_remplir_carburant__MonPkg_id))
                {
                    //## transition 27 
                    if( speed == 0 && IS_IN(contact_off))
                        {
                            NOTIFY_TRANSITION_STARTED("27");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.fonctionelle");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.remplir_carburant");
                            pushNullTransition();
                            state_75_subState = remplir_carburant;
                            state_75_active = remplir_carburant;
                            //#[ state Systeme.state_75.remplir_carburant.(Entry) 
                            ex_remplir_carburant();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("27");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 19 
                    if( reservoir_carburant  < SEUIL_carburant)
                        {
                            NOTIFY_TRANSITION_STARTED("19");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.fonctionelle");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.panne_carburant");
                            state_75_subState = panne_carburant;
                            state_75_active = panne_carburant;
                            //#[ state Systeme.state_75.panne_carburant.(Entry) 
                            carburant_faible = true;
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("19");
                            res = eventConsumed;
                        }
                    else
                        {
                            //## transition 20 
                            if( niveau_batterie  < SEUIL_batterie)
                                {
                                    NOTIFY_TRANSITION_STARTED("20");
                                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.fonctionelle");
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.panne_batterie");
                                    state_75_subState = panne_batterie;
                                    state_75_active = panne_batterie;
                                    //#[ state Systeme.state_75.panne_batterie.(Entry) 
                                    batterie_faible = true;
                                    //#]
                                    NOTIFY_TRANSITION_TERMINATED("20");
                                    res = eventConsumed;
                                }
                        }
                }
            
            
        }
        break;
        // State panne_carburant
        case panne_carburant:
        {
            if(IS_EVENT_TYPE_OF(ev_remplir_carburant__MonPkg_id))
                {
                    //## transition 21 
                    if(speed == 0 && IS_IN(contact_off))
                        {
                            NOTIFY_TRANSITION_STARTED("21");
                            //#[ state Systeme.state_75.panne_carburant.(Exit) 
                            carburant_faible = false;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.panne_carburant");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.remplir_carburant");
                            pushNullTransition();
                            state_75_subState = remplir_carburant;
                            state_75_active = remplir_carburant;
                            //#[ state Systeme.state_75.remplir_carburant.(Entry) 
                            ex_remplir_carburant();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("21");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State panne_batterie
        case panne_batterie:
        {
            if(IS_EVENT_TYPE_OF(ev_depanner_batterie__MonPkg_id))
                {
                    //## transition 22 
                    if(speed == 0 && IS_IN(contact_off))
                        {
                            NOTIFY_TRANSITION_STARTED("22");
                            //#[ state Systeme.state_75.panne_batterie.(Exit) 
                            batterie_faible = false;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.panne_batterie");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.depanner_batterie");
                            pushNullTransition();
                            state_75_subState = depanner_batterie;
                            state_75_active = depanner_batterie;
                            //#[ state Systeme.state_75.depanner_batterie.(Entry) 
                            ex_depanner_batterie();
                            //#]
                            NOTIFY_TRANSITION_TERMINATED("22");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State remplir_carburant
        case remplir_carburant:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    NOTIFY_TRANSITION_STARTED("24");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.remplir_carburant");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.fonctionelle");
                    state_75_subState = fonctionelle;
                    state_75_active = fonctionelle;
                    NOTIFY_TRANSITION_TERMINATED("24");
                    res = eventConsumed;
                }
            
            
        }
        break;
        // State depanner_batterie
        case depanner_batterie:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    NOTIFY_TRANSITION_STARTED("23");
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_75.depanner_batterie");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_75.fonctionelle");
                    state_75_subState = fonctionelle;
                    state_75_active = fonctionelle;
                    NOTIFY_TRANSITION_TERMINATED("23");
                    res = eventConsumed;
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::state_72_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_72");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_72.simulation_du_vehicule");
    state_72_subState = simulation_du_vehicule;
    state_72_active = simulation_du_vehicule;
    //#[ state Systeme.state_72.simulation_du_vehicule.(Entry) 
    calcul_vitesse_distance();
    //#]
}

void _SysVehicule::state_72_exit() {
    // State simulation_du_vehicule
    if(state_72_subState == simulation_du_vehicule)
        {
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_72.simulation_du_vehicule");
        }
    state_72_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_72");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_72_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State simulation_du_vehicule
    if(state_72_active == simulation_du_vehicule)
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    NOTIFY_TRANSITION_STARTED("8");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_72.simulation_du_vehicule");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_72.simulation_du_vehicule");
                    state_72_subState = simulation_du_vehicule;
                    state_72_active = simulation_du_vehicule;
                    //#[ state Systeme.state_72.simulation_du_vehicule.(Entry) 
                    calcul_vitesse_distance();
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("8");
                    res = eventConsumed;
                }
            
            
        }
    return res;
}

void _SysVehicule::state_71_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71");
    NOTIFY_TRANSITION_STARTED("12");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
    state_71_subState = mode_manuel;
    state_71_active = mode_manuel;
    //#[ state Systeme.state_71.mode_manuel.(Entry) 
    voyant_regulateur = false;
    //#]
    NOTIFY_TRANSITION_TERMINATED("12");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_71_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_71_active) {
        // State mode_manuel
        case mode_manuel:
        {
            if(IS_EVENT_TYPE_OF(ev_regulateur__MonPkg_id))
                {
                    //## transition 45 
                    if( speed >= 30  && brakePedal < 0.5  && IS_IN(moteur_on))
                        {
                            NOTIFY_TRANSITION_STARTED("45");
                            //#[ state Systeme.state_71.mode_manuel.(Exit) 
                            voyant_regulateur = true;
                            //#]
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_manuel");
                            mode_regulateur_entDef();
                            NOTIFY_TRANSITION_TERMINATED("45");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State maintien
        case maintien:
        {
            res = maintien_handleEvent();
        }
        break;
        // State plus
        case plus:
        {
            res = plus_handleEvent();
        }
        break;
        // State moins
        case moins:
        {
            res = moins_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::mode_regulateur_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur");
    state_71_subState = mode_regulateur;
    //#[ state Systeme.state_71.mode_regulateur.(Entry) 
    vitesseConsigne = speed;
    steady = throttle;
    //#]
    NOTIFY_TRANSITION_STARTED("17");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.maintien");
    mode_regulateur_subState = maintien;
    state_71_active = maintien;
    NOTIFY_TRANSITION_TERMINATED("17");
}

IOxfReactive::TakeEventStatus _SysVehicule::mode_regulateur_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_limiteur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("53");
            switch (mode_regulateur_subState) {
                // State maintien
                case maintien:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                }
                break;
                // State plus
                case plus:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                }
                break;
                // State moins
                case moins:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                }
                break;
                default:
                    break;
            }
            mode_regulateur_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
            state_71_subState = mode_manuel;
            state_71_active = mode_manuel;
            //#[ state Systeme.state_71.mode_manuel.(Entry) 
            voyant_regulateur = false;
            //#]
            NOTIFY_TRANSITION_TERMINATED("53");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_regulateur__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("44");
            switch (mode_regulateur_subState) {
                // State maintien
                case maintien:
                {
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                }
                break;
                // State plus
                case plus:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                }
                break;
                // State moins
                case moins:
                {
                    popNullTransition();
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                }
                break;
                default:
                    break;
            }
            mode_regulateur_subState = OMNonState;
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
            state_71_subState = mode_manuel;
            state_71_active = mode_manuel;
            //#[ state Systeme.state_71.mode_manuel.(Entry) 
            voyant_regulateur = false;
            //#]
            NOTIFY_TRANSITION_TERMINATED("44");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 18 
            if( speed < 30  || brakePedal >= 0.5  || IS_IN(moteur_off))
                {
                    NOTIFY_TRANSITION_STARTED("18");
                    switch (mode_regulateur_subState) {
                        // State maintien
                        case maintien:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
                        }
                        break;
                        // State plus
                        case plus:
                        {
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
                        }
                        break;
                        // State moins
                        case moins:
                        {
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
                        }
                        break;
                        default:
                            break;
                    }
                    mode_regulateur_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_manuel");
                    state_71_subState = mode_manuel;
                    state_71_active = mode_manuel;
                    //#[ state Systeme.state_71.mode_manuel.(Entry) 
                    voyant_regulateur = false;
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("18");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::plus_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            NOTIFY_TRANSITION_STARTED("15");
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.plus");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            mode_regulateur_subState = maintien;
            state_71_active = maintien;
            NOTIFY_TRANSITION_TERMINATED("15");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = mode_regulateur_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::moins_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            NOTIFY_TRANSITION_STARTED("16");
            popNullTransition();
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.moins");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            mode_regulateur_subState = maintien;
            state_71_active = maintien;
            NOTIFY_TRANSITION_TERMINATED("16");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = mode_regulateur_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::maintien_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_plus__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("13");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.plus");
            pushNullTransition();
            mode_regulateur_subState = plus;
            state_71_active = plus;
            //#[ state Systeme.state_71.mode_regulateur.plus.(Entry) 
            ex_vitesseConsigne(+1);
            //#]
            NOTIFY_TRANSITION_TERMINATED("13");
            res = eventConsumed;
        }
    else if(IS_EVENT_TYPE_OF(ev_vitesseConsigne_moins__MonPkg_id))
        {
            NOTIFY_TRANSITION_STARTED("14");
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_71.mode_regulateur.maintien");
            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_71.mode_regulateur.moins");
            pushNullTransition();
            mode_regulateur_subState = moins;
            state_71_active = moins;
            //#[ state Systeme.state_71.mode_regulateur.moins.(Entry) 
            ex_vitesseConsigne(-1);
            //#]
            NOTIFY_TRANSITION_TERMINATED("14");
            res = eventConsumed;
        }
    
    if(res == eventNotConsumed)
        {
            res = mode_regulateur_handleEvent();
        }
    return res;
}

void _SysVehicule::state_62_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_62");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_62.horloge_rafraichissement");
    state_62_subState = horloge_rafraichissement;
    state_62_active = horloge_rafraichissement;
    //#[ state Systeme.state_62.horloge_rafraichissement.(Entry) 
    GEN(EVAL);
    //#]
    state_62_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_62.horloge_rafraichissement");
}

void _SysVehicule::state_62_exit() {
    // State horloge_rafraichissement
    if(state_62_subState == horloge_rafraichissement)
        {
            cancel(state_62_timeout);
            NOTIFY_STATE_EXITED("ROOT.Systeme.state_62.horloge_rafraichissement");
        }
    state_62_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.Systeme.state_62");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_62_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    // State horloge_rafraichissement
    if(state_62_active == horloge_rafraichissement)
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_62_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("38");
                            cancel(state_62_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_62.horloge_rafraichissement");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_62.horloge_rafraichissement");
                            state_62_subState = horloge_rafraichissement;
                            state_62_active = horloge_rafraichissement;
                            //#[ state Systeme.state_62.horloge_rafraichissement.(Entry) 
                            GEN(EVAL);
                            //#]
                            state_62_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_62.horloge_rafraichissement");
                            NOTIFY_TRANSITION_TERMINATED("38");
                            res = eventConsumed;
                        }
                }
            
            
        }
    return res;
}

void _SysVehicule::state_61_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61");
    NOTIFY_TRANSITION_STARTED("4");
    contact_on_entDef();
    NOTIFY_TRANSITION_TERMINATED("4");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_61_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_61_active) {
        // State contact_off
        case contact_off:
        {
            if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 26 
                    if( cmd_contact==true)
                        {
                            NOTIFY_TRANSITION_STARTED("26");
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_off");
                            contact_on_entDef();
                            NOTIFY_TRANSITION_TERMINATED("26");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State moteur_off
        case moteur_off:
        {
            res = moteur_off_handleEvent();
        }
        break;
        // State moteur_on
        case moteur_on:
        {
            res = moteur_on_handleEvent();
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::contact_on_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on");
    state_61_subState = contact_on;
    //#[ state Systeme.state_61.contact_on.(Entry) 
    calcul_batterie();
    //#]
    state_61_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_61.contact_on");
    NOTIFY_TRANSITION_STARTED("5");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.moteur_off");
    contact_on_subState = moteur_off;
    state_61_active = moteur_off;
    //#[ state Systeme.state_61.contact_on.moteur_off.(Entry) 
    arreter();
    //#]
    NOTIFY_TRANSITION_TERMINATED("5");
}

IOxfReactive::TakeEventStatus _SysVehicule::contact_on_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == state_61_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("43");
                    contact_on_lastState = contact_on_subState;
                    switch (contact_on_subState) {
                        // State moteur_off
                        case moteur_off:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_off");
                            contact_on_lastState = moteur_off;
                        }
                        break;
                        // State moteur_on
                        case moteur_on:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_on");
                            contact_on_lastState = moteur_on;
                        }
                        break;
                        default:
                            break;
                    }
                    contact_on_subState = OMNonState;
                    cancel(state_61_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on");
                    state_61_subState = contact_on;
                    //#[ state Systeme.state_61.contact_on.(Entry) 
                    calcul_batterie();
                    //#]
                    state_61_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_61.contact_on");
                    if(contact_on_lastState != OMNonState)
                        {
                            contact_on_subState = contact_on_lastState;
                            switch (contact_on_subState) {
                                // State moteur_off
                                case moteur_off:
                                {
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.moteur_off");
                                    contact_on_subState = moteur_off;
                                    state_61_active = moteur_off;
                                    //#[ state Systeme.state_61.contact_on.moteur_off.(Entry) 
                                    arreter();
                                    //#]
                                }
                                break;
                                // State moteur_on
                                case moteur_on:
                                {
                                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.moteur_on");
                                    contact_on_subState = moteur_on;
                                    state_61_active = moteur_on;
                                    //#[ state Systeme.state_61.contact_on.moteur_on.(Entry) 
                                    calcul_carburant();
                                    //#]
                                }
                                break;
                                default:
                                    break;
                            }
                        }
                    NOTIFY_TRANSITION_TERMINATED("43");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 1 
            if( cmd_contact==false)
                {
                    NOTIFY_TRANSITION_STARTED("1");
                    contact_on_lastState = contact_on_subState;
                    switch (contact_on_subState) {
                        // State moteur_off
                        case moteur_off:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_off");
                            contact_on_lastState = moteur_off;
                        }
                        break;
                        // State moteur_on
                        case moteur_on:
                        {
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_on");
                            contact_on_lastState = moteur_on;
                        }
                        break;
                        default:
                            break;
                    }
                    contact_on_subState = OMNonState;
                    cancel(state_61_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_off");
                    state_61_subState = contact_off;
                    state_61_active = contact_off;
                    NOTIFY_TRANSITION_TERMINATED("1");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::moteur_on_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 3 
            if( !IS_IN(fonctionelle) || cmd_contact==false)
                {
                    NOTIFY_TRANSITION_STARTED("3");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_on");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.moteur_off");
                    contact_on_subState = moteur_off;
                    state_61_active = moteur_off;
                    //#[ state Systeme.state_61.contact_on.moteur_off.(Entry) 
                    arreter();
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("3");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = contact_on_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::moteur_off_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(ev_demarrer__MonPkg_id))
        {
            //## transition 2 
            if( IS_IN(fonctionelle) )
                {
                    NOTIFY_TRANSITION_STARTED("2");
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_61.contact_on.moteur_off");
                    //#[ transition 2 
                    ex_demarrer();
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_61.contact_on.moteur_on");
                    contact_on_subState = moteur_on;
                    state_61_active = moteur_on;
                    //#[ state Systeme.state_61.contact_on.moteur_on.(Entry) 
                    calcul_carburant();
                    //#]
                    NOTIFY_TRANSITION_TERMINATED("2");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = contact_on_handleEvent();
        }
    return res;
}

void _SysVehicule::state_60_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60");
    NOTIFY_TRANSITION_STARTED("6");
    pedales_entDef();
    NOTIFY_TRANSITION_TERMINATED("6");
}

IOxfReactive::TakeEventStatus _SysVehicule::state_60_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (state_60_active) {
        // State freinage_injection
        case freinage_injection:
        {
            res = freinage_injection_handleEvent();
        }
        break;
        // State acceleration
        case acceleration:
        {
            res = acceleration_handleEvent();
        }
        break;
        // State regulateur
        case regulateur:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_60_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("40");
                            cancel(state_60_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur");
                            NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.regulateur");
                            state_60_subState = regulateur;
                            state_60_active = regulateur;
                            //#[ state Systeme.state_60.regulateur.(Entry) 
                            calcul_regulateur_vitesse();
                            //#]
                            state_60_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_regulateur, "ROOT.Systeme.state_60.regulateur");
                            NOTIFY_TRANSITION_TERMINATED("40");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
                {
                    //## transition 11 
                    if( IS_IN(mode_manuel)  ||  accelPedal >= 0.5)
                        {
                            NOTIFY_TRANSITION_STARTED("11");
                            cancel(state_60_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.regulateur");
                            pedales_entDef();
                            NOTIFY_TRANSITION_TERMINATED("11");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        default:
            break;
    }
    return res;
}

void _SysVehicule::pedales_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales");
    state_60_subState = pedales;
    NOTIFY_TRANSITION_STARTED("7");
    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.freinage_injection");
    pushNullTransition();
    pedales_subState = freinage_injection;
    state_60_active = freinage_injection;
    //#[ state Systeme.state_60.pedales.freinage_injection.(Entry) 
    freiner_injection(brakePedal);
    //#]
    pedales_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_60.pedales.freinage_injection");
    NOTIFY_TRANSITION_TERMINATED("7");
}

IOxfReactive::TakeEventStatus _SysVehicule::pedales_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(EVAL__MonPkg_id))
        {
            //## transition 10 
            if( IS_IN(mode_regulateur) &&  accelPedal < 0.5)
                {
                    NOTIFY_TRANSITION_STARTED("10");
                    switch (pedales_subState) {
                        // State freinage_injection
                        case freinage_injection:
                        {
                            popNullTransition();
                            cancel(pedales_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                        }
                        break;
                        // State acceleration
                        case acceleration:
                        {
                            popNullTransition();
                            cancel(pedales_timeout);
                            NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                        }
                        break;
                        default:
                            break;
                    }
                    pedales_subState = OMNonState;
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.regulateur");
                    state_60_subState = regulateur;
                    state_60_active = regulateur;
                    //#[ state Systeme.state_60.regulateur.(Entry) 
                    calcul_regulateur_vitesse();
                    //#]
                    state_60_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_regulateur, "ROOT.Systeme.state_60.regulateur");
                    NOTIFY_TRANSITION_TERMINATED("10");
                    res = eventConsumed;
                }
        }
    
    
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::freinage_injection_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == pedales_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("42");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    pushNullTransition();
                    pedales_subState = freinage_injection;
                    state_60_active = freinage_injection;
                    //#[ state Systeme.state_60.pedales.freinage_injection.(Entry) 
                    freiner_injection(brakePedal);
                    //#]
                    pedales_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_TRANSITION_TERMINATED("42");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            //## transition 9 
            if(brakePedal < 0.5    && IS_IN(moteur_on)   && !(IS_IN(limiteur_effectif) && float_speed >=  vitesseConsigne + 0.5))
                {
                    NOTIFY_TRANSITION_STARTED("9");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.acceleration");
                    pushNullTransition();
                    pedales_subState = acceleration;
                    state_60_active = acceleration;
                    //#[ state Systeme.state_60.pedales.acceleration.(Entry) 
                    accelerer(accelPedal);
                    //#]
                    pedales_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_TRANSITION_TERMINATED("9");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = pedales_handleEvent();
        }
    return res;
}

IOxfReactive::TakeEventStatus _SysVehicule::acceleration_handleEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
        {
            if(getCurrentEvent() == pedales_timeout)
                {
                    NOTIFY_TRANSITION_STARTED("41");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.acceleration");
                    pushNullTransition();
                    pedales_subState = acceleration;
                    state_60_active = acceleration;
                    //#[ state Systeme.state_60.pedales.acceleration.(Entry) 
                    accelerer(accelPedal);
                    //#]
                    pedales_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_TRANSITION_TERMINATED("41");
                    res = eventConsumed;
                }
        }
    else if(IS_EVENT_TYPE_OF(OMNullEventId))
        {
            //## transition 25 
            if(brakePedal >= 0.5 || IS_IN(moteur_off) || (IS_IN(limiteur_effectif) && float_speed >=  vitesseConsigne + 0.5))
                {
                    NOTIFY_TRANSITION_STARTED("25");
                    popNullTransition();
                    cancel(pedales_timeout);
                    NOTIFY_STATE_EXITED("ROOT.Systeme.state_60.pedales.acceleration");
                    NOTIFY_STATE_ENTERED("ROOT.Systeme.state_60.pedales.freinage_injection");
                    pushNullTransition();
                    pedales_subState = freinage_injection;
                    state_60_active = freinage_injection;
                    //#[ state Systeme.state_60.pedales.freinage_injection.(Entry) 
                    freiner_injection(brakePedal);
                    //#]
                    pedales_timeout = scheduleTimeout(1000/PARAM_SIMU_freq_rafraichissement, "ROOT.Systeme.state_60.pedales.freinage_injection");
                    NOTIFY_TRANSITION_TERMINATED("25");
                    res = eventConsumed;
                }
        }
    
    if(res == eventNotConsumed)
        {
            res = pedales_handleEvent();
        }
    return res;
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimated_SysVehicule::serializeAttributes(AOMSAttributes* aomsAttributes) const {
    aomsAttributes->addAttribute("speed", x2String(myReal->speed));
    aomsAttributes->addAttribute("brakePedal", x2String(myReal->brakePedal));
    aomsAttributes->addAttribute("ignition", x2String(myReal->ignition));
    aomsAttributes->addAttribute("distance", x2String(myReal->distance));
    aomsAttributes->addAttribute("throttle", x2String(myReal->throttle));
    aomsAttributes->addAttribute("alpha", x2String(myReal->alpha));
    aomsAttributes->addAttribute("accelPedal", x2String(myReal->accelPedal));
    aomsAttributes->addAttribute("float_distance", x2String(myReal->float_distance));
    aomsAttributes->addAttribute("_simu", x2String(myReal->_simu));
    aomsAttributes->addAttribute("float_speed", x2String(myReal->float_speed));
    aomsAttributes->addAttribute("vitesseConsigne", x2String(myReal->vitesseConsigne));
    aomsAttributes->addAttribute("reservoir_carburant", x2String(myReal->reservoir_carburant));
    aomsAttributes->addAttribute("niveau_batterie", x2String(myReal->niveau_batterie));
    aomsAttributes->addAttribute("cmd_contact", x2String(myReal->cmd_contact));
    aomsAttributes->addAttribute("voyant_regulateur", x2String(myReal->voyant_regulateur));
    aomsAttributes->addAttribute("voyant_limiteur", x2String(myReal->voyant_limiteur));
    aomsAttributes->addAttribute("PARAM_SIMU_max_throttle", x2String(myReal->PARAM_SIMU_max_throttle));
    aomsAttributes->addAttribute("PARAM_SIMU_max_speed", x2String(myReal->PARAM_SIMU_max_speed));
    aomsAttributes->addAttribute("PARAM_SIMU_masse", x2String(myReal->PARAM_SIMU_masse));
    aomsAttributes->addAttribute("PARAM_SIMU_frottement_air", x2String(myReal->PARAM_SIMU_frottement_air));
    aomsAttributes->addAttribute("PARAM_SIMU_puissance_moteur", x2String(myReal->PARAM_SIMU_puissance_moteur));
    aomsAttributes->addAttribute("PARAM_SIMU_puissance_frein", x2String(myReal->PARAM_SIMU_puissance_frein));
    aomsAttributes->addAttribute("PARAM_SIMU_freq_rafraichissement", x2String(myReal->PARAM_SIMU_freq_rafraichissement));
    aomsAttributes->addAttribute("PARAM_SIMU_vitesse_repos", x2String(myReal->PARAM_SIMU_vitesse_repos));
    aomsAttributes->addAttribute("PARAM_SIMU_max_accel", x2String(myReal->PARAM_SIMU_max_accel));
    aomsAttributes->addAttribute("PARAM_SIMU_max_brake", x2String(myReal->PARAM_SIMU_max_brake));
    aomsAttributes->addAttribute("PARAM_SIMU_Kp_regulateur", x2String(myReal->PARAM_SIMU_Kp_regulateur));
    aomsAttributes->addAttribute("PARAM_SIMU_freq_regulateur", x2String(myReal->PARAM_SIMU_freq_regulateur));
    aomsAttributes->addAttribute("PARAM_SIMU_Ki_regulateur", x2String(myReal->PARAM_SIMU_Ki_regulateur));
    aomsAttributes->addAttribute("SEUIL_batterie", x2String(myReal->SEUIL_batterie));
    aomsAttributes->addAttribute("SEUIL_carburant", x2String(myReal->SEUIL_carburant));
    aomsAttributes->addAttribute("Ki_regulateur", x2String(myReal->Ki_regulateur));
    aomsAttributes->addAttribute("Kp_regulateur", x2String(myReal->Kp_regulateur));
    aomsAttributes->addAttribute("throttle_repos", x2String(myReal->throttle_repos));
    aomsAttributes->addAttribute("steady", x2String(myReal->steady));
    aomsAttributes->addAttribute("limiteur_depasse", x2String(myReal->limiteur_depasse));
    aomsAttributes->addAttribute("batterie_faible", x2String(myReal->batterie_faible));
    aomsAttributes->addAttribute("carburant_faible", x2String(myReal->carburant_faible));
    aomsAttributes->addAttribute("valeur_initiale_limiteur", x2String(myReal->valeur_initiale_limiteur));
    aomsAttributes->addAttribute("limiteur_attente", x2String(myReal->limiteur_attente));
    aomsAttributes->addAttribute("VOYANT_bluetooth_vehicule", x2String(myReal->VOYANT_bluetooth_vehicule));
    aomsAttributes->addAttribute("VOYANT_telephone_appairage", x2String(myReal->VOYANT_telephone_appairage));
    aomsAttributes->addAttribute("VOYANT_telephone_connecte", x2String(myReal->VOYANT_telephone_connecte));
    aomsAttributes->addAttribute("champ_mdp", x2String(myReal->champ_mdp));
    aomsAttributes->addAttribute("affichage_appairage", x2String(myReal->affichage_appairage));
    aomsAttributes->addAttribute("liste_appareils_detectes", array2String(2, myReal->liste_appareils_detectes, sizeof(OMString), &x2String));
    aomsAttributes->addAttribute("messages_appairage", array2String(5, myReal->messages_appairage, sizeof(OMString), &x2String));
    aomsAttributes->addAttribute("mot_de_passe", x2String(myReal->mot_de_passe));
    aomsAttributes->addAttribute("affichage_liste_appareils", x2String(myReal->affichage_liste_appareils));
    aomsAttributes->addAttribute("VOYANT_vehicule_connectee", x2String(myReal->VOYANT_vehicule_connectee));
}

void OMAnimated_SysVehicule::rootState_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT");
    if(myReal->rootState_subState == _SysVehicule::Systeme)
        {
            Systeme_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::Systeme_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme");
    state_60_serializeStates(aomsState);
    state_61_serializeStates(aomsState);
    state_62_serializeStates(aomsState);
    state_71_serializeStates(aomsState);
    state_72_serializeStates(aomsState);
    state_75_serializeStates(aomsState);
    state_76_serializeStates(aomsState);
    state_87_serializeStates(aomsState);
    state_96_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_96_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96");
    switch (myReal->state_96_subState) {
        case _SysVehicule::initerfsegb:
        {
            initerfsegb_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::voy:
        {
            voy_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::voy_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.voy");
}

void OMAnimated_SysVehicule::initerfsegb_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_96.initerfsegb");
}

void OMAnimated_SysVehicule::state_87_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87");
    switch (myReal->state_87_subState) {
        case _SysVehicule::bluetooth_desactive:
        {
            bluetooth_desactive_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::bluetooth_active:
        {
            bluetooth_active_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::demarrage_bluetooth:
        {
            demarrage_bluetooth_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::demarrage_bluetooth_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.demarrage_bluetooth");
}

void OMAnimated_SysVehicule::bluetooth_desactive_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_desactive");
}

void OMAnimated_SysVehicule::bluetooth_active_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active");
    switch (myReal->bluetooth_active_subState) {
        case _SysVehicule::recherche_telephone:
        {
            recherche_telephone_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::telephone_connecte:
        {
            telephone_connecte_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::telephone_connecte_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.telephone_connecte");
}

void OMAnimated_SysVehicule::recherche_telephone_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_87.bluetooth_active.recherche_telephone");
}

void OMAnimated_SysVehicule::state_76_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76");
    switch (myReal->state_76_subState) {
        case _SysVehicule::limiteur_on:
        {
            limiteur_on_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::limiteur_off:
        {
            limiteur_off_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::limiteur_on_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on");
    state_81_serializeStates(aomsState);
    state_82_serializeStates(aomsState);
}

void OMAnimated_SysVehicule::state_82_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82");
    switch (myReal->state_82_subState) {
        case _SysVehicule::maintien_consigne:
        {
            maintien_consigne_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::state_82_plus:
        {
            state_82_plus_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::state_82_moins:
        {
            state_82_moins_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::state_82_plus_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82.plus");
}

void OMAnimated_SysVehicule::state_82_moins_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82.moins");
}

void OMAnimated_SysVehicule::maintien_consigne_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne");
    switch (myReal->maintien_consigne_subState) {
        case _SysVehicule::limite_tenue:
        {
            limite_tenue_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::depassement:
        {
            depassement_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::stabilisation:
        {
            stabilisation_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::stabilisation_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.stabilisation");
}

void OMAnimated_SysVehicule::limite_tenue_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.limite_tenue");
}

void OMAnimated_SysVehicule::depassement_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_82.maintien_consigne.depassement");
}

void OMAnimated_SysVehicule::state_81_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_81");
    switch (myReal->state_81_subState) {
        case _SysVehicule::limiteur_inhibe:
        {
            limiteur_inhibe_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::limiteur_effectif:
        {
            limiteur_effectif_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::limiteur_inhibe_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_inhibe");
}

void OMAnimated_SysVehicule::limiteur_effectif_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_on.state_81.limiteur_effectif");
}

void OMAnimated_SysVehicule::limiteur_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_76.limiteur_off");
}

void OMAnimated_SysVehicule::state_75_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_75");
    switch (myReal->state_75_subState) {
        case _SysVehicule::fonctionelle:
        {
            fonctionelle_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::panne_carburant:
        {
            panne_carburant_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::panne_batterie:
        {
            panne_batterie_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::remplir_carburant:
        {
            remplir_carburant_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::depanner_batterie:
        {
            depanner_batterie_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::remplir_carburant_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_75.remplir_carburant");
}

void OMAnimated_SysVehicule::panne_carburant_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_75.panne_carburant");
}

void OMAnimated_SysVehicule::panne_batterie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_75.panne_batterie");
}

void OMAnimated_SysVehicule::fonctionelle_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_75.fonctionelle");
}

void OMAnimated_SysVehicule::depanner_batterie_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_75.depanner_batterie");
}

void OMAnimated_SysVehicule::state_72_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_72");
    if(myReal->state_72_subState == _SysVehicule::simulation_du_vehicule)
        {
            simulation_du_vehicule_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::simulation_du_vehicule_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_72.simulation_du_vehicule");
}

void OMAnimated_SysVehicule::state_71_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71");
    switch (myReal->state_71_subState) {
        case _SysVehicule::mode_manuel:
        {
            mode_manuel_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::mode_regulateur:
        {
            mode_regulateur_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::mode_regulateur_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur");
    switch (myReal->mode_regulateur_subState) {
        case _SysVehicule::maintien:
        {
            maintien_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::plus:
        {
            plus_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::moins:
        {
            moins_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::plus_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur.plus");
}

void OMAnimated_SysVehicule::moins_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur.moins");
}

void OMAnimated_SysVehicule::maintien_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_regulateur.maintien");
}

void OMAnimated_SysVehicule::mode_manuel_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_71.mode_manuel");
}

void OMAnimated_SysVehicule::state_62_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_62");
    if(myReal->state_62_subState == _SysVehicule::horloge_rafraichissement)
        {
            horloge_rafraichissement_serializeStates(aomsState);
        }
}

void OMAnimated_SysVehicule::horloge_rafraichissement_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_62.horloge_rafraichissement");
}

void OMAnimated_SysVehicule::state_61_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61");
    switch (myReal->state_61_subState) {
        case _SysVehicule::contact_off:
        {
            contact_off_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::contact_on:
        {
            contact_on_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::contact_on_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on");
    switch (myReal->contact_on_subState) {
        case _SysVehicule::moteur_off:
        {
            moteur_off_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::moteur_on:
        {
            moteur_on_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::moteur_on_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.moteur_on");
}

void OMAnimated_SysVehicule::moteur_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_on.moteur_off");
}

void OMAnimated_SysVehicule::contact_off_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_61.contact_off");
}

void OMAnimated_SysVehicule::state_60_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60");
    switch (myReal->state_60_subState) {
        case _SysVehicule::pedales:
        {
            pedales_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::regulateur:
        {
            regulateur_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::regulateur_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.regulateur");
}

void OMAnimated_SysVehicule::pedales_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.pedales");
    switch (myReal->pedales_subState) {
        case _SysVehicule::freinage_injection:
        {
            freinage_injection_serializeStates(aomsState);
        }
        break;
        case _SysVehicule::acceleration:
        {
            acceleration_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimated_SysVehicule::freinage_injection_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.pedales.freinage_injection");
}

void OMAnimated_SysVehicule::acceleration_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.Systeme.state_60.pedales.acceleration");
}
//#]

IMPLEMENT_REACTIVE_META_P(_SysVehicule, _MonPkg, _MonPkg, false, OMAnimated_SysVehicule)

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setAccelPedal_double, "setAccelPedal", FALSE, "setAccelPedal(double)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setAccelPedal_double, _SysVehicule, setAccelPedal(p_accelPedal), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setAffichage_liste_appareils_OMString, "setAffichage_liste_appareils", FALSE, "setAffichage_liste_appareils(OMString)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setAffichage_liste_appareils_OMString, _SysVehicule, setAffichage_liste_appareils(p_affichage_liste_appareils), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setAlpha_int, "setAlpha", FALSE, "setAlpha(int)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setAlpha_int, _SysVehicule, setAlpha(p_alpha), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setBrakePedal_double, "setBrakePedal", FALSE, "setBrakePedal(double)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setBrakePedal_double, _SysVehicule, setBrakePedal(p_brakePedal), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setChamp_mdp_OMString, "setChamp_mdp", FALSE, "setChamp_mdp(OMString)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setChamp_mdp_OMString, _SysVehicule, setChamp_mdp(p_champ_mdp), NO_OP())

IMPLEMENT_META_OP(OMAnimated_SysVehicule, _MonPkg__SysVehicule_setCmd_contact_bool, "setCmd_contact", FALSE, "setCmd_contact(bool)", 1)

IMPLEMENT_OP_CALL(_MonPkg__SysVehicule_setCmd_contact_bool, _SysVehicule, setCmd_contact(p_cmd_contact), NO_OP())
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.cpp
*********************************************************************/
