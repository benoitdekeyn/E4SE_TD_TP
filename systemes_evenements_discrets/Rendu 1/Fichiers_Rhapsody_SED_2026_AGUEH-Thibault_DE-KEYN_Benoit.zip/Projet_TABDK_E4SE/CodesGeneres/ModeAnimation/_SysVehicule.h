/*********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _SysVehicule
//!	Generated Date	: Thu, 26, Nov 2026  
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.h
*********************************************************************/

#ifndef _SysVehicule_H
#define _SysVehicule_H

//## dependency math
#include <math.h>
//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "Windows.h"
//## auto_generated
#include "stdlib.h"
//## auto_generated
#include "stdio.h"
//## auto_generated
#include "string.h"
//## auto_generated
#include "stdint.h"
//## auto_generated
#include "tchar.h"
//## auto_generated
#include "_MonPkg.h"
//## auto_generated
#include <oxf\omthread.h>
//## auto_generated
#include <oxf\omreactive.h>
//## auto_generated
#include <oxf\state.h>
//## auto_generated
#include <oxf\event.h>
//#[ ignore
#define OMAnim__MonPkg__SysVehicule_setAccelPedal_double_ARGS_DECLARATION double p_accelPedal;

#define OMAnim__MonPkg__SysVehicule_setAffichage_liste_appareils_OMString_ARGS_DECLARATION OMString p_affichage_liste_appareils;

#define OMAnim__MonPkg__SysVehicule_setAlpha_int_ARGS_DECLARATION int p_alpha;

#define OMAnim__MonPkg__SysVehicule_setBrakePedal_double_ARGS_DECLARATION double p_brakePedal;

#define OMAnim__MonPkg__SysVehicule_setChamp_mdp_OMString_ARGS_DECLARATION OMString p_champ_mdp;

#define OMAnim__MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool_ARGS_DECLARATION bool p_cmd_bluetooth_telephone_actif;

#define OMAnim__MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool_ARGS_DECLARATION bool p_cmd_charge_vehicule_telephone;

#define OMAnim__MonPkg__SysVehicule_setCmd_contact_bool_ARGS_DECLARATION bool p_cmd_contact;

#define OMAnim__MonPkg__SysVehicule_setCmd_radio_bool_ARGS_DECLARATION bool p_cmd_radio;

#define OMAnim__MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool_ARGS_DECLARATION bool p_cmd_simulation_voiture_devant;

#define OMAnim__MonPkg__SysVehicule_setDistance_inter_voiture_double_ARGS_DECLARATION double p_distance_inter_voiture;

#define OMAnim__MonPkg__SysVehicule_setTelephone_allume_bool_ARGS_DECLARATION bool p_telephone_allume;

#define OMAnim__MonPkg__SysVehicule_setVitesse_voiture_devant_double_ARGS_DECLARATION double p_vitesse_voiture_devant;
//#]

//## package _MonPkg

//## class _SysVehicule
class _SysVehicule : public OMThread, public OMReactive {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimated_SysVehicule;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    ////    Operations    ////
    
    //## operation accelerer(double)
    void accelerer(double accelPedal);
    
    //## operation arreter()
    void arreter();
    
    //## operation ex_demarrer()
    void ex_demarrer();
    
    //## operation calcul_vitesse_distance()
    void calcul_vitesse_distance();
    
    //## operation freiner_injection(double)
    void freiner_injection(double brakePedal);
    
    ////    Additional operations    ////
    
    ////    Attributes    ////

protected :

    double brakePedal;		//## attribute brakePedal
    
    int distance;		//## attribute distance
    
    bool ignition;		//## attribute ignition
    
    int speed;		//## attribute speed
    
    ////    Relations and components    ////
    
    ////    Framework operations    ////
    
    double throttle;		//## attribute throttle

public :

    //## operation init()
    void init();

protected :

    double float_speed;		//## attribute float_speed
    
    double accelPedal;		//## attribute accelPedal
    
    int alpha;		//## attribute alpha
    
    double float_distance;		//## attribute float_distance
    
    bool _simu;		//## attribute _simu
    
    int vitesseConsigne;		//## attribute vitesseConsigne

public :

    //## auto_generated
    ~_SysVehicule();
    
    //## auto_generated
    bool get_simu();
    
    //## auto_generated
    void set_simu(bool p__simu);
    
    //## auto_generated
    double getAccelPedal();
    
    //## auto_generated
    void setAccelPedal(double p_accelPedal);
    
    //## auto_generated
    int getAlpha();
    
    //## auto_generated
    void setAlpha(int p_alpha);
    
    //## auto_generated
    double getBrakePedal();
    
    //## auto_generated
    void setBrakePedal(double p_brakePedal);
    
    //## auto_generated
    int getDistance();
    
    //## auto_generated
    void setDistance(int p_distance);
    
    //## auto_generated
    bool getIgnition();
    
    //## auto_generated
    int getSpeed();
    
    //## auto_generated
    double getSteady();
    
    //## auto_generated
    void setSteady(double p_steady);
    
    //## auto_generated
    double getThrottle();
    
    //## auto_generated
    int getVitesseConsigne();
    
    //## auto_generated
    void setVitesseConsigne(int p_vitesseConsigne);
    
    //## auto_generated
    virtual bool startBehavior();
    
    //## operation _SysVehicule()
    _SysVehicule(IOxfActive* theActiveContext = 0);
    
    //## operation Operation_215()
    void Operation_215();
    
    //## operation VOYANT_kit(bool)
    void VOYANT_kit(bool etat);
    
    //## operation affichage_batterie_telephone_vehicule()
    void affichage_batterie_telephone_vehicule();
    
    //## operation alerte_depassement(int)
    void alerte_depassement(int actif);
    
    //## operation calcul_batterie()
    void calcul_batterie();
    
    //## operation calcul_carburant()
    void calcul_carburant();
    
    //## operation calcul_distance_voiture_devant()
    void calcul_distance_voiture_devant();
    
    //## operation calcul_regulateur_distance()
    void calcul_regulateur_distance();
    
    //## operation calcul_regulateur_vitesse()
    void calcul_regulateur_vitesse();
    
    //## operation charge_telephone()
    void charge_telephone();
    
    //## operation decharge_telephone()
    void decharge_telephone();
    
    //## operation envoi_batterie_kit(int)
    const void envoi_batterie_kit(int batterie_telephone);
    
    //## operation eteindre_telephone()
    void eteindre_telephone();
    
    //## operation ex_actualisation_sms_telephone(int)
    void ex_actualisation_sms_telephone(int incrementation);
    
    //## operation ex_depanner_batterie()
    void ex_depanner_batterie();
    
    //## operation ex_jumeler()
    void ex_jumeler();
    
    //## operation ex_ok()
    void ex_ok();
    
    //## operation ex_remplir_carburant()
    void ex_remplir_carburant();
    
    //## operation ex_vitesseConsigne(int)
    void ex_vitesseConsigne(int delta);
    
    //## operation play_sound(OMString)
    void play_sound(const OMString& fichier);
    
    //## operation regulateur_Prof()
    void regulateur_Prof();
    
    //## operation verifier_mdp(OMString)
    boolean verifier_mdp(const OMString& mdp);
    
    //## auto_generated
    double getKi_regulateur();
    
    //## auto_generated
    void setKi_regulateur(double p_Ki_regulateur);
    
    //## auto_generated
    double getKp_regulateur();
    
    //## auto_generated
    void setKp_regulateur(double p_Kp_regulateur);
    
    //## auto_generated
    double getPARAM_SIMU_Ki_regulateur();
    
    //## auto_generated
    void setPARAM_SIMU_Ki_regulateur(double p_PARAM_SIMU_Ki_regulateur);
    
    //## auto_generated
    double getPARAM_SIMU_Kp_regulateur();
    
    //## auto_generated
    void setPARAM_SIMU_Kp_regulateur(double p_PARAM_SIMU_Kp_regulateur);
    
    //## auto_generated
    int getPARAM_SIMU_freq_rafraichissement();
    
    //## auto_generated
    void setPARAM_SIMU_freq_rafraichissement(int p_PARAM_SIMU_freq_rafraichissement);
    
    //## auto_generated
    int getPARAM_SIMU_freq_regulateur();
    
    //## auto_generated
    void setPARAM_SIMU_freq_regulateur(int p_PARAM_SIMU_freq_regulateur);
    
    //## auto_generated
    double getPARAM_SIMU_frottement_air();
    
    //## auto_generated
    void setPARAM_SIMU_frottement_air(double p_PARAM_SIMU_frottement_air);
    
    //## auto_generated
    int getPARAM_SIMU_masse();
    
    //## auto_generated
    void setPARAM_SIMU_masse(int p_PARAM_SIMU_masse);
    
    //## auto_generated
    int getPARAM_SIMU_max_accel();
    
    //## auto_generated
    void setPARAM_SIMU_max_accel(int p_PARAM_SIMU_max_accel);
    
    //## auto_generated
    int getPARAM_SIMU_max_brake();
    
    //## auto_generated
    void setPARAM_SIMU_max_brake(int p_PARAM_SIMU_max_brake);
    
    //## auto_generated
    int getPARAM_SIMU_max_speed();
    
    //## auto_generated
    void setPARAM_SIMU_max_speed(int p_PARAM_SIMU_max_speed);
    
    //## auto_generated
    double getPARAM_SIMU_max_throttle();
    
    //## auto_generated
    void setPARAM_SIMU_max_throttle(double p_PARAM_SIMU_max_throttle);
    
    //## auto_generated
    int getPARAM_SIMU_periode_pedales();
    
    //## auto_generated
    void setPARAM_SIMU_periode_pedales(int p_PARAM_SIMU_periode_pedales);
    
    //## auto_generated
    int getPARAM_SIMU_puissance_frein();
    
    //## auto_generated
    void setPARAM_SIMU_puissance_frein(int p_PARAM_SIMU_puissance_frein);
    
    //## auto_generated
    int getPARAM_SIMU_puissance_moteur();
    
    //## auto_generated
    void setPARAM_SIMU_puissance_moteur(int p_PARAM_SIMU_puissance_moteur);
    
    //## auto_generated
    int getPARAM_SIMU_vitesse_repos();
    
    //## auto_generated
    void setPARAM_SIMU_vitesse_repos(int p_PARAM_SIMU_vitesse_repos);
    
    //## auto_generated
    double getSEUIL_batterie();
    
    //## auto_generated
    void setSEUIL_batterie(double p_SEUIL_batterie);
    
    //## auto_generated
    double getSEUIL_carburant();
    
    //## auto_generated
    void setSEUIL_carburant(double p_SEUIL_carburant);
    
    //## auto_generated
    bool getVOYANT_bluetooth_vehicule();
    
    //## auto_generated
    void setVOYANT_bluetooth_vehicule(bool p_VOYANT_bluetooth_vehicule);
    
    //## auto_generated
    bool getVOYANT_kit_appel();
    
    //## auto_generated
    void setVOYANT_kit_appel(bool p_VOYANT_kit_appel);
    
    //## auto_generated
    bool getVOYANT_kit_connecte();
    
    //## auto_generated
    void setVOYANT_kit_connecte(bool p_VOYANT_kit_connecte);
    
    //## auto_generated
    bool getVOYANT_kit_sms();
    
    //## auto_generated
    void setVOYANT_kit_sms(bool p_VOYANT_kit_sms);
    
    //## auto_generated
    bool getVOYANT_kit_sonnerie();
    
    //## auto_generated
    void setVOYANT_kit_sonnerie(bool p_VOYANT_kit_sonnerie);
    
    //## auto_generated
    bool getVOYANT_radio();
    
    //## auto_generated
    void setVOYANT_radio(bool p_VOYANT_radio);
    
    //## auto_generated
    bool getVOYANT_telephone_appairage();
    
    //## auto_generated
    void setVOYANT_telephone_appairage(bool p_VOYANT_telephone_appairage);
    
    //## auto_generated
    bool getVOYANT_telephone_appel();
    
    //## auto_generated
    void setVOYANT_telephone_appel(bool p_VOYANT_telephone_appel);
    
    //## auto_generated
    bool getVOYANT_telephone_connecte();
    
    //## auto_generated
    void setVOYANT_telephone_connecte(bool p_VOYANT_telephone_connecte);
    
    //## auto_generated
    bool getVOYANT_telephone_sms();
    
    //## auto_generated
    void setVOYANT_telephone_sms(bool p_VOYANT_telephone_sms);
    
    //## auto_generated
    bool getVOYANT_telephone_sonnerie();
    
    //## auto_generated
    void setVOYANT_telephone_sonnerie(bool p_VOYANT_telephone_sonnerie);
    
    //## auto_generated
    OMString getAffichage_appairage();
    
    //## auto_generated
    void setAffichage_appairage(OMString p_affichage_appairage);
    
    //## auto_generated
    OMString getAffichage_liste_appareils();
    
    //## auto_generated
    void setAffichage_liste_appareils(OMString p_affichage_liste_appareils);
    
    //## auto_generated
    OMString getAffichage_titre_musique();
    
    //## auto_generated
    void setAffichage_titre_musique(OMString p_affichage_titre_musique);
    
    //## auto_generated
    bool getAppel_en_cours_telephone();
    
    //## auto_generated
    void setAppel_en_cours_telephone(bool p_appel_en_cours_telephone);
    
    //## auto_generated
    bool getBatterie_faible();
    
    //## auto_generated
    void setBatterie_faible(bool p_batterie_faible);
    
    //## auto_generated
    bool getCarburant_faible();
    
    //## auto_generated
    void setCarburant_faible(bool p_carburant_faible);
    
    //## auto_generated
    OMString getChamp_mdp();
    
    //## auto_generated
    void setChamp_mdp(OMString p_champ_mdp);
    
    //## auto_generated
    OMString getChemin_sons();
    
    //## auto_generated
    void setChemin_sons(OMString p_chemin_sons);
    
    //## auto_generated
    bool getCmd_bluetooth_telephone_actif();
    
    //## auto_generated
    void setCmd_bluetooth_telephone_actif(bool p_cmd_bluetooth_telephone_actif);
    
    //## auto_generated
    bool getCmd_charge_vehicule_telephone();
    
    //## auto_generated
    void setCmd_charge_vehicule_telephone(bool p_cmd_charge_vehicule_telephone);
    
    //## auto_generated
    bool getCmd_contact();
    
    //## auto_generated
    void setCmd_contact(bool p_cmd_contact);
    
    //## auto_generated
    bool getCmd_radio();
    
    //## auto_generated
    void setCmd_radio(bool p_cmd_radio);
    
    //## auto_generated
    bool getCmd_simulation_voiture_devant();
    
    //## auto_generated
    void setCmd_simulation_voiture_devant(bool p_cmd_simulation_voiture_devant);
    
    //## auto_generated
    int getDistance_entiere_voiture_devant();
    
    //## auto_generated
    void setDistance_entiere_voiture_devant(int p_distance_entiere_voiture_devant);
    
    //## auto_generated
    double getDistance_inter_voiture();
    
    //## auto_generated
    void setDistance_inter_voiture(double p_distance_inter_voiture);
    
    //## auto_generated
    double getDistance_securite();
    
    //## auto_generated
    void setDistance_securite(double p_distance_securite);
    
    //## auto_generated
    double getDistance_voiture_devant();
    
    //## auto_generated
    void setDistance_voiture_devant(double p_distance_voiture_devant);
    
    //## auto_generated
    double getFloat_distance();
    
    //## auto_generated
    void setFloat_distance(double p_float_distance);
    
    //## auto_generated
    double getFloat_speed();
    
    //## auto_generated
    void setFloat_speed(double p_float_speed);
    
    //## auto_generated
    void setIgnition(bool p_ignition);
    
    //## auto_generated
    bool getKit_jumele();
    
    //## auto_generated
    void setKit_jumele(bool p_kit_jumele);
    
    //## auto_generated
    bool getLimiteur_attente();
    
    //## auto_generated
    void setLimiteur_attente(bool p_limiteur_attente);
    
    //## auto_generated
    bool getLimiteur_depasse();
    
    //## auto_generated
    void setLimiteur_depasse(bool p_limiteur_depasse);
    
    //## auto_generated
    OMString getListe_appareils_detectes(int i1);
    
    //## auto_generated
    void setListe_appareils_detectes(int i1, OMString p_liste_appareils_detectes);
    
    //## auto_generated
    OMString getMessages_appairage(int i1);
    
    //## auto_generated
    void setMessages_appairage(int i1, OMString p_messages_appairage);
    
    //## auto_generated
    OMString getMot_de_passe();
    
    //## auto_generated
    void setMot_de_passe(OMString p_mot_de_passe);
    
    //## auto_generated
    int getNbr_sauvegarde_sms_telephone();
    
    //## auto_generated
    void setNbr_sauvegarde_sms_telephone(int p_nbr_sauvegarde_sms_telephone);
    
    //## auto_generated
    int getNbr_sms_kit();
    
    //## auto_generated
    void setNbr_sms_kit(int p_nbr_sms_kit);
    
    //## auto_generated
    int getNbr_sms_telephone();
    
    //## auto_generated
    void setNbr_sms_telephone(int p_nbr_sms_telephone);
    
    //## auto_generated
    double getNiveau_batterie();
    
    //## auto_generated
    void setNiveau_batterie(double p_niveau_batterie);
    
    //## auto_generated
    int getNiveau_batterie_kit();
    
    //## auto_generated
    void setNiveau_batterie_kit(int p_niveau_batterie_kit);
    
    //## auto_generated
    int getNiveau_batterie_telephone();
    
    //## auto_generated
    void setNiveau_batterie_telephone(int p_niveau_batterie_telephone);
    
    //## auto_generated
    double getReservoir_carburant();
    
    //## auto_generated
    void setReservoir_carburant(double p_reservoir_carburant);
    
    //## auto_generated
    bool getSonnerie_en_cours();
    
    //## auto_generated
    void setSonnerie_en_cours(bool p_sonnerie_en_cours);
    
    //## auto_generated
    void setSpeed(int p_speed);
    
    //## auto_generated
    bool getTelephone_allume();
    
    //## auto_generated
    void setTelephone_allume(bool p_telephone_allume);
    
    //## auto_generated
    void setThrottle(double p_throttle);
    
    //## auto_generated
    double getThrottle_repos();
    
    //## auto_generated
    void setThrottle_repos(double p_throttle_repos);
    
    //## auto_generated
    int getValeur_initiale_limiteur();
    
    //## auto_generated
    void setValeur_initiale_limiteur(int p_valeur_initiale_limiteur);
    
    //## auto_generated
    double getVitesse_voiture_devant();
    
    //## auto_generated
    void setVitesse_voiture_devant(double p_vitesse_voiture_devant);
    
    //## auto_generated
    bool getVoyant_limiteur();
    
    //## auto_generated
    void setVoyant_limiteur(bool p_voyant_limiteur);
    
    //## auto_generated
    bool getVoyant_regulateur();
    
    //## auto_generated
    void setVoyant_regulateur(bool p_voyant_regulateur);

protected :

    //## auto_generated
    void initStatechart();
    
    //## auto_generated
    void cancelTimeouts();
    
    //## auto_generated
    bool cancelTimeout(const IOxfTimeout* arg);
    
    double Ki_regulateur;		//## attribute Ki_regulateur
    
    double Kp_regulateur;		//## attribute Kp_regulateur
    
    double PARAM_SIMU_Ki_regulateur;		//## attribute PARAM_SIMU_Ki_regulateur
    
    double PARAM_SIMU_Kp_regulateur;		//## attribute PARAM_SIMU_Kp_regulateur
    
    int PARAM_SIMU_freq_rafraichissement;		//## attribute PARAM_SIMU_freq_rafraichissement
    
    int PARAM_SIMU_freq_regulateur;		//## attribute PARAM_SIMU_freq_regulateur
    
    double PARAM_SIMU_frottement_air;		//## attribute PARAM_SIMU_frottement_air
    
    int PARAM_SIMU_masse;		//## attribute PARAM_SIMU_masse
    
    int PARAM_SIMU_max_accel;		//## attribute PARAM_SIMU_max_accel
    
    int PARAM_SIMU_max_brake;		//## attribute PARAM_SIMU_max_brake
    
    int PARAM_SIMU_max_speed;		//## attribute PARAM_SIMU_max_speed
    
    double PARAM_SIMU_max_throttle;		//## attribute PARAM_SIMU_max_throttle
    
    int PARAM_SIMU_periode_pedales;		//## attribute PARAM_SIMU_periode_pedales
    
    int PARAM_SIMU_puissance_frein;		//## attribute PARAM_SIMU_puissance_frein
    
    int PARAM_SIMU_puissance_moteur;		//## attribute PARAM_SIMU_puissance_moteur
    
    int PARAM_SIMU_vitesse_repos;		//## attribute PARAM_SIMU_vitesse_repos
    
    double SEUIL_batterie;		//## attribute SEUIL_batterie
    
    double SEUIL_carburant;		//## attribute SEUIL_carburant
    
    bool VOYANT_bluetooth_vehicule;		//## attribute VOYANT_bluetooth_vehicule
    
    bool VOYANT_kit_appel;		//## attribute VOYANT_kit_appel
    
    bool VOYANT_kit_connecte;		//## attribute VOYANT_kit_connecte
    
    bool VOYANT_kit_sms;		//## attribute VOYANT_kit_sms
    
    bool VOYANT_kit_sonnerie;		//## attribute VOYANT_kit_sonnerie
    
    bool VOYANT_radio;		//## attribute VOYANT_radio
    
    bool VOYANT_telephone_appairage;		//## attribute VOYANT_telephone_appairage
    
    bool VOYANT_telephone_appel;		//## attribute VOYANT_telephone_appel
    
    bool VOYANT_telephone_connecte;		//## attribute VOYANT_telephone_connecte
    
    bool VOYANT_telephone_sms;		//## attribute VOYANT_telephone_sms
    
    bool VOYANT_telephone_sonnerie;		//## attribute VOYANT_telephone_sonnerie
    
    OMString affichage_appairage;		//## attribute affichage_appairage
    
    OMString affichage_liste_appareils;		//## attribute affichage_liste_appareils
    
    OMString affichage_titre_musique;		//## attribute affichage_titre_musique
    
    bool appel_en_cours_telephone;		//## attribute appel_en_cours_telephone
    
    bool batterie_faible;		//## attribute batterie_faible
    
    bool carburant_faible;		//## attribute carburant_faible
    
    OMString champ_mdp;		//## attribute champ_mdp
    
    OMString chemin_sons;		//## attribute chemin_sons
    
    bool cmd_bluetooth_telephone_actif;		//## attribute cmd_bluetooth_telephone_actif
    
    bool cmd_charge_vehicule_telephone;		//## attribute cmd_charge_vehicule_telephone
    
    bool cmd_contact;		//## attribute cmd_contact
    
    bool cmd_radio;		//## attribute cmd_radio
    
    bool cmd_simulation_voiture_devant;		//## attribute cmd_simulation_voiture_devant
    
    int distance_entiere_voiture_devant;		//## attribute distance_entiere_voiture_devant
    
    double distance_inter_voiture;		//## attribute distance_inter_voiture
    
    double distance_securite;		//## attribute distance_securite
    
    double distance_voiture_devant;		//## attribute distance_voiture_devant
    
    bool kit_jumele;		//## attribute kit_jumele
    
    bool limiteur_attente;		//## attribute limiteur_attente
    
    bool limiteur_depasse;		//## attribute limiteur_depasse
    
    OMString liste_appareils_detectes[2];		//## attribute liste_appareils_detectes
    
    OMString messages_appairage[6];		//## attribute messages_appairage
    
    OMString mot_de_passe;		//## attribute mot_de_passe
    
    int nbr_sauvegarde_sms_telephone;		//## attribute nbr_sauvegarde_sms_telephone
    
    int nbr_sms_kit;		//## attribute nbr_sms_kit
    
    int nbr_sms_telephone;		//## attribute nbr_sms_telephone
    
    double niveau_batterie;		//## attribute niveau_batterie
    
    int niveau_batterie_kit;		//## attribute niveau_batterie_kit
    
    int niveau_batterie_telephone;		//## attribute niveau_batterie_telephone
    
    double reservoir_carburant;		//## attribute reservoir_carburant
    
    bool sonnerie_en_cours;		//## attribute sonnerie_en_cours
    
    double steady;		//## attribute steady
    
    bool telephone_allume;		//## attribute telephone_allume
    
    double throttle_repos;		//## attribute throttle_repos
    
    int valeur_initiale_limiteur;		//## attribute valeur_initiale_limiteur
    
    double vitesse_voiture_devant;		//## attribute vitesse_voiture_devant
    
    bool voyant_limiteur;		//## attribute voyant_limiteur
    
    bool voyant_regulateur;		//## attribute voyant_regulateur

public :

    // rootState:
    //## statechart_method
    inline bool rootState_IN() const;
    
    //## statechart_method
    virtual void rootState_entDef();
    
    //## statechart_method
    void rootStateEntDef();
    
    //## statechart_method
    void rootState_exit();
    
    //## statechart_method
    virtual IOxfReactive::TakeEventStatus rootState_processEvent();
    
    // Systeme:
    //## statechart_method
    inline bool Systeme_IN() const;
    
    //## statechart_method
    void Systeme_entDef();
    
    //## statechart_method
    void Systeme_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus Systeme_processEvent();
    
    // state_96:
    //## statechart_method
    inline bool state_96_IN() const;
    
    //## statechart_method
    void state_96_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_96_processEvent();
    
    // telephone_eteint:
    //## statechart_method
    inline bool telephone_eteint_IN() const;
    
    // telephone_actif:
    //## statechart_method
    inline bool telephone_actif_IN() const;
    
    //## statechart_method
    void telephone_actif_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus telephone_actif_handleEvent();
    
    // bluetooth_telephone_desactive:
    //## statechart_method
    inline bool bluetooth_telephone_desactive_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus bluetooth_telephone_desactive_handleEvent();
    
    // bluetooth_telephone_active:
    //## statechart_method
    inline bool bluetooth_telephone_active_IN() const;
    
    //## statechart_method
    void bluetooth_telephone_active_entDef();
    
    //## statechart_method
    void bluetooth_telephone_active_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus bluetooth_telephone_active_handleEvent();
    
    // recherche_bluetooth:
    //## statechart_method
    inline bool recherche_bluetooth_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus recherche_bluetooth_handleEvent();
    
    // kit_detecte:
    //## statechart_method
    inline bool kit_detecte_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus kit_detecte_handleEvent();
    
    // kit_connecte:
    //## statechart_method
    inline bool kit_connecte_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus kit_connecte_handleEvent();
    
    // jumelage:
    //## statechart_method
    inline bool jumelage_IN() const;
    
    //## statechart_method
    void jumelage_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus jumelage_handleEvent();
    
    // jumelage_effectif:
    //## statechart_method
    inline bool jumelage_effectif_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus jumelage_effectif_handleEvent();
    
    // attente_reponse:
    //## statechart_method
    inline bool attente_reponse_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus attente_reponse_handleEvent();
    
    // attente_jumelage:
    //## statechart_method
    inline bool attente_jumelage_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus attente_jumelage_handleEvent();
    
    // interruption_bluetooth_kit:
    //## statechart_method
    inline bool interruption_bluetooth_kit_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus interruption_bluetooth_kit_handleEvent();
    
    // connexion:
    //## statechart_method
    inline bool connexion_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus connexion_handleEvent();
    
    // state_87:
    //## statechart_method
    inline bool state_87_IN() const;
    
    //## statechart_method
    void state_87_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_87_processEvent();
    
    // demarrage_bluetooth:
    //## statechart_method
    inline bool demarrage_bluetooth_IN() const;
    
    // bluetooth_desactive:
    //## statechart_method
    inline bool bluetooth_desactive_IN() const;
    
    // bluetooth_active:
    //## statechart_method
    inline bool bluetooth_active_IN() const;
    
    //## statechart_method
    void bluetooth_active_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus bluetooth_active_handleEvent();
    
    // telephone_connecte:
    //## statechart_method
    inline bool telephone_connecte_IN() const;
    
    // recherche_telephone:
    //## statechart_method
    inline bool recherche_telephone_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus recherche_telephone_handleEvent();
    
    // operation_jumelage:
    //## statechart_method
    inline bool operation_jumelage_IN() const;
    
    //## statechart_method
    void operation_jumelage_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus operation_jumelage_handleEvent();
    
    // jumelage_kit:
    //## statechart_method
    inline bool jumelage_kit_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus jumelage_kit_handleEvent();
    
    // attente_connexion:
    //## statechart_method
    inline bool attente_connexion_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus attente_connexion_handleEvent();
    
    // state_76:
    //## statechart_method
    inline bool state_76_IN() const;
    
    //## statechart_method
    void state_76_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_76_processEvent();
    
    // limiteur_on:
    //## statechart_method
    inline bool limiteur_on_IN() const;
    
    //## statechart_method
    void limiteur_on_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_on_handleEvent();
    
    // limiteur_on_plus:
    //## statechart_method
    inline bool limiteur_on_plus_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_on_plus_handleEvent();
    
    // limiteur_on_moins:
    //## statechart_method
    inline bool limiteur_on_moins_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_on_moins_handleEvent();
    
    // consigne_fixe:
    //## statechart_method
    inline bool consigne_fixe_IN() const;
    
    //## statechart_method
    void consigne_fixe_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus consigne_fixe_handleEvent();
    
    // limiteur_inhibe:
    //## statechart_method
    inline bool limiteur_inhibe_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_inhibe_handleEvent();
    
    // limiteur_effectif:
    //## statechart_method
    inline bool limiteur_effectif_IN() const;
    
    //## statechart_method
    void limiteur_effectif_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_effectif_handleEvent();
    
    // limite_tenue:
    //## statechart_method
    inline bool limite_tenue_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limite_tenue_handleEvent();
    
    // depassement:
    //## statechart_method
    inline bool depassement_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus depassement_handleEvent();
    
    // limiteur_off:
    //## statechart_method
    inline bool limiteur_off_IN() const;
    
    // state_72:
    //## statechart_method
    inline bool state_72_IN() const;
    
    //## statechart_method
    void state_72_entDef();
    
    //## statechart_method
    void state_72_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_72_processEvent();
    
    // simulation_du_vehicule:
    //## statechart_method
    inline bool simulation_du_vehicule_IN() const;
    
    // state_71:
    //## statechart_method
    inline bool state_71_IN() const;
    
    //## statechart_method
    void state_71_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_71_processEvent();
    
    // mode_regulateur:
    //## statechart_method
    inline bool mode_regulateur_IN() const;
    
    //## statechart_method
    void mode_regulateur_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus mode_regulateur_handleEvent();
    
    // plus:
    //## statechart_method
    inline bool plus_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus plus_handleEvent();
    
    // moins:
    //## statechart_method
    inline bool moins_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus moins_handleEvent();
    
    // maintien:
    //## statechart_method
    inline bool maintien_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus maintien_handleEvent();
    
    // mode_manuel:
    //## statechart_method
    inline bool mode_manuel_IN() const;
    
    // state_62:
    //## statechart_method
    inline bool state_62_IN() const;
    
    //## statechart_method
    void state_62_entDef();
    
    //## statechart_method
    void state_62_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_62_processEvent();
    
    // horloge_rafraichissement:
    //## statechart_method
    inline bool horloge_rafraichissement_IN() const;
    
    // state_61:
    //## statechart_method
    inline bool state_61_IN() const;
    
    //## statechart_method
    void state_61_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_61_processEvent();
    
    // contact_on:
    //## statechart_method
    inline bool contact_on_IN() const;
    
    //## statechart_method
    void contact_on_entDef();
    
    //## statechart_method
    void contact_on_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus contact_on_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus contact_on_handleEvent();
    
    // state_267:
    //## statechart_method
    inline bool state_267_IN() const;
    
    //## statechart_method
    void state_267_entDef();
    
    //## statechart_method
    void state_267_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_267_processEvent();
    
    // calcul_batterie_voiture:
    //## statechart_method
    inline bool calcul_batterie_voiture_IN() const;
    
    // state_266:
    //## statechart_method
    inline bool state_266_IN() const;
    
    //## statechart_method
    void state_266_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_266_processEvent();
    
    // moteur_on:
    //## statechart_method
    inline bool moteur_on_IN() const;
    
    // moteur_off:
    //## statechart_method
    inline bool moteur_off_IN() const;
    
    // contact_off:
    //## statechart_method
    inline bool contact_off_IN() const;
    
    // state_60:
    //## statechart_method
    inline bool state_60_IN() const;
    
    //## statechart_method
    void state_60_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_60_processEvent();
    
    // regulateur:
    //## statechart_method
    inline bool regulateur_IN() const;
    
    //## statechart_method
    void regulateur_entDef();
    
    //## statechart_method
    virtual void regulateur_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus regulateur_handleEvent();
    
    // verification_distance_securite:
    //## statechart_method
    inline bool verification_distance_securite_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus verification_distance_securite_handleEvent();
    
    // suivi_vitesse_consigne:
    //## statechart_method
    inline bool suivi_vitesse_consigne_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus suivi_vitesse_consigne_handleEvent();
    
    // suivi_distance_consigne:
    //## statechart_method
    inline bool suivi_distance_consigne_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus suivi_distance_consigne_handleEvent();
    
    // pedales:
    //## statechart_method
    inline bool pedales_IN() const;
    
    //## statechart_method
    void pedales_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus pedales_handleEvent();
    
    // freinage_injection:
    //## statechart_method
    inline bool freinage_injection_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus freinage_injection_handleEvent();
    
    // acceleration:
    //## statechart_method
    inline bool acceleration_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus acceleration_handleEvent();
    
    // state_278:
    //## statechart_method
    inline bool state_278_IN() const;
    
    //## statechart_method
    void state_278_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_278_processEvent();
    
    // radio_prete:
    //## statechart_method
    inline bool radio_prete_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus radio_prete_handleEvent();
    
    // radio_eteinte:
    //## statechart_method
    inline bool radio_eteinte_IN() const;
    
    // contact_radio_actif:
    //## statechart_method
    inline bool contact_radio_actif_IN() const;
    
    //## statechart_method
    void contact_radio_actif_entDef();
    
    //## statechart_method
    void contact_radio_actifEntDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus contact_radio_actif_handleEvent();
    
    // priorite_sonnerie:
    //## statechart_method
    inline bool priorite_sonnerie_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus priorite_sonnerie_handleEvent();
    
    // priorite_radio:
    //## statechart_method
    inline bool priorite_radio_IN() const;
    
    //## statechart_method
    void priorite_radio_entDef();
    
    //## statechart_method
    void priorite_radio_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus priorite_radio_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus priorite_radio_handleEvent();
    
    // state_260:
    //## statechart_method
    inline bool state_260_IN() const;
    
    //## statechart_method
    void state_260_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_260_processEvent();
    
    // attente_btn_radio:
    //## statechart_method
    inline bool attente_btn_radio_IN() const;
    
    // appui_btn_radio:
    //## statechart_method
    inline bool appui_btn_radio_IN() const;
    
    // state_233:
    //## statechart_method
    inline bool state_233_IN() const;
    
    //## statechart_method
    void state_233_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_233_processEvent();
    
    // radio_active:
    //## statechart_method
    inline bool radio_active_IN() const;
    
    //## statechart_method
    void radio_active_entDef();
    
    //## statechart_method
    void radio_active_exit();
    
    // musique_3:
    //## statechart_method
    inline bool musique_3_IN() const;
    
    // musique_2:
    //## statechart_method
    inline bool musique_2_IN() const;
    
    // musique_1:
    //## statechart_method
    inline bool musique_1_IN() const;
    
    // lancement_radio:
    //## statechart_method
    inline bool lancement_radio_IN() const;
    
    // priorite_appel:
    //## statechart_method
    inline bool priorite_appel_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus priorite_appel_handleEvent();
    
    // state_275:
    //## statechart_method
    inline bool state_275_IN() const;
    
    //## statechart_method
    void state_275_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_275_processEvent();
    
    // simulation_voiture_devant:
    //## statechart_method
    inline bool simulation_voiture_devant_IN() const;
    
    //## statechart_method
    void simulation_voiture_devant_entDef();
    
    //## statechart_method
    void simulation_voiture_devant_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus simulation_voiture_devant_handleEvent();
    
    // loop_simulation:
    //## statechart_method
    inline bool loop_simulation_IN() const;
    
    // reglage_voiture_devant:
    //## statechart_method
    inline bool reglage_voiture_devant_IN() const;
    
    // state_252:
    //## statechart_method
    inline bool state_252_IN() const;
    
    //## statechart_method
    void state_252_entDef();
    
    //## statechart_method
    void state_252_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_252_processEvent();
    
    // remplir_carburant:
    //## statechart_method
    inline bool remplir_carburant_IN() const;
    
    // panne_carburant:
    //## statechart_method
    inline bool panne_carburant_IN() const;
    
    // panne_batterie:
    //## statechart_method
    inline bool panne_batterie_IN() const;
    
    // fonctionelle:
    //## statechart_method
    inline bool fonctionelle_IN() const;
    
    // depanner_batterie:
    //## statechart_method
    inline bool depanner_batterie_IN() const;
    
    // state_206:
    //## statechart_method
    inline bool state_206_IN() const;
    
    //## statechart_method
    void state_206_entDef();
    
    //## statechart_method
    void state_206_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_206_processEvent();
    
    // sms_exterrieur:
    //## statechart_method
    inline bool sms_exterrieur_IN() const;
    
    // state_166:
    //## statechart_method
    inline bool state_166_IN() const;
    
    //## statechart_method
    void state_166_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_166_processEvent();
    
    // telephone_deconnecte:
    //## statechart_method
    inline bool telephone_deconnecte_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus telephone_deconnecteTakeEVAL();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus telephone_deconnecte_handleEvent();
    
    // controle_telephone_connecte:
    //## statechart_method
    inline bool controle_telephone_connecte_IN() const;
    
    //## statechart_method
    void controle_telephone_connecte_entDef();
    
    //## statechart_method
    void controle_telephone_connecte_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus controle_telephone_connecteTakeEVAL();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus controle_telephone_connecte_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus controle_telephone_connecte_handleEvent();
    
    // state_204:
    //## statechart_method
    inline bool state_204_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_204_processEvent();
    
    // state_199:
    //## statechart_method
    inline bool state_199_IN() const;
    
    //## statechart_method
    void state_199_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_199_processEvent();
    
    // messagerie_kit:
    //## statechart_method
    inline bool messagerie_kit_IN() const;
    
    // lire_message_kit:
    //## statechart_method
    inline bool lire_message_kit_IN() const;
    
    // init_redirection_sms_kit:
    //## statechart_method
    inline bool init_redirection_sms_kit_IN() const;
    
    // state_198:
    //## statechart_method
    inline bool state_198_IN() const;
    
    //## statechart_method
    void state_198_entDef();
    
    //## statechart_method
    void state_198_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_198_processEvent();
    
    // gestion_btn_lire_sms_kit:
    //## statechart_method
    inline bool gestion_btn_lire_sms_kit_IN() const;
    
    // state_174:
    //## statechart_method
    inline bool state_174_IN() const;
    
    //## statechart_method
    void state_174_entDef();
    
    //## statechart_method
    void state_174_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_174_processEvent();
    
    // gestion_btn_decrocher_kit:
    //## statechart_method
    inline bool gestion_btn_decrocher_kit_IN() const;
    
    // state_173:
    //## statechart_method
    inline bool state_173_IN() const;
    
    //## statechart_method
    void state_173_entDef();
    
    //## statechart_method
    void state_173_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_173_processEvent();
    
    // gestion_btn_raccrocher_kit:
    //## statechart_method
    inline bool gestion_btn_raccrocher_kit_IN() const;
    
    // state_131:
    //## statechart_method
    inline bool state_131_IN() const;
    
    //## statechart_method
    void state_131_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_131_processEvent();
    
    // gestion_sonnerie_kit:
    //## statechart_method
    inline bool gestion_sonnerie_kit_IN() const;
    
    //## statechart_method
    void gestion_sonnerie_kit_entDef();
    
    //## statechart_method
    void gestion_sonnerie_kit_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_kit_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_kit_handleEvent();
    
    // gestion_sonnerie_kit_state_240:
    //## statechart_method
    inline bool gestion_sonnerie_kit_state_240_IN() const;
    
    //## statechart_method
    void gestion_sonnerie_kit_state_240_entDef();
    
    //## statechart_method
    void gestion_sonnerie_kit_state_240_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_kit_state_240_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_kit_state_240_handleEvent();
    
    // sonnerie_sonore_kit:
    //## statechart_method
    inline bool sonnerie_sonore_kit_IN() const;
    
    // gestion_sonnerie_kit_gestion_sonnerie_kit:
    //## statechart_method
    inline bool gestion_sonnerie_kit_gestion_sonnerie_kit_IN() const;
    
    //## statechart_method
    void gestion_sonnerie_kit_gestion_sonnerie_kit_entDef();
    
    //## statechart_method
    void gestion_sonnerie_kit_gestion_sonnerie_kit_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_kit_gestion_sonnerie_kit_processEvent();
    
    // sonnerie_lumineuse_kit:
    //## statechart_method
    inline bool sonnerie_lumineuse_kit_IN() const;
    
    // attente_redirection_appel:
    //## statechart_method
    inline bool attente_redirection_appel_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus attente_redirection_appel_handleEvent();
    
    // appel_en_cours_kit:
    //## statechart_method
    inline bool appel_en_cours_kit_IN() const;
    
    // state_130:
    //## statechart_method
    inline bool state_130_IN() const;
    
    //## statechart_method
    void state_130_entDef();
    
    //## statechart_method
    void state_130_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_130_processEvent();
    
    // affichage_batterie:
    //## statechart_method
    inline bool affichage_batterie_IN() const;
    
    // state_146:
    //## statechart_method
    inline bool state_146_IN() const;
    
    //## statechart_method
    void state_146_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_146_processEvent();
    
    // tentative_appel:
    //## statechart_method
    inline bool tentative_appel_IN() const;
    
    //## statechart_method
    void tentative_appel_entDef();
    
    //## statechart_method
    virtual void tentative_appel_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus tentative_appel_handleEvent();
    
    // debut_tentative:
    //## statechart_method
    inline bool debut_tentative_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus debut_tentative_handleEvent();
    
    // telephone_SIM:
    //## statechart_method
    inline bool telephone_SIM_IN() const;
    
    // discussion_telephonique:
    //## statechart_method
    inline bool discussion_telephonique_IN() const;
    
    // state_139:
    //## statechart_method
    inline bool state_139_IN() const;
    
    //## statechart_method
    void state_139_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_139_processEvent();
    
    // gestion_communication:
    //## statechart_method
    inline bool gestion_communication_IN() const;
    
    //## statechart_method
    void gestion_communication_entDef();
    
    //## statechart_method
    void gestion_communicationEntDef();
    
    //## statechart_method
    void gestion_communication_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_communication_handleEvent();
    
    // gestion_communication_telephone:
    //## statechart_method
    inline bool gestion_communication_telephone_IN() const;
    
    //## statechart_method
    void gestion_communication_telephone_entDef();
    
    //## statechart_method
    void gestion_communication_telephone_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_communication_telephone_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_communication_telephone_handleEvent();
    
    // state_262:
    //## statechart_method
    inline bool state_262_IN() const;
    
    //## statechart_method
    void state_262_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_262_processEvent();
    
    // redirection_off:
    //## statechart_method
    inline bool redirection_off_IN() const;
    
    // redirection_kit_bluetooth_communication:
    //## statechart_method
    inline bool redirection_kit_bluetooth_communication_IN() const;
    
    //## statechart_method
    void redirection_kit_bluetooth_communication_entDef();
    
    //## statechart_method
    void redirection_kit_bluetooth_communication_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus redirection_kit_bluetooth_communication_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus redirection_kit_bluetooth_communication_handleEvent();
    
    // state_189:
    //## statechart_method
    inline bool state_189_IN() const;
    
    //## statechart_method
    void state_189_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_189_processEvent();
    
    // reception_sms_kit:
    //## statechart_method
    inline bool reception_sms_kit_IN() const;
    
    // lire_sms_kit:
    //## statechart_method
    inline bool lire_sms_kit_IN() const;
    
    // state_188:
    //## statechart_method
    inline bool state_188_IN() const;
    
    //## statechart_method
    void state_188_entDef();
    
    //## statechart_method
    void state_188_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_188_processEvent();
    
    // transfer_appel:
    //## statechart_method
    inline bool transfer_appel_IN() const;
    
    // sonnerie_transfert:
    //## statechart_method
    inline bool sonnerie_transfert_IN() const;
    
    //## statechart_method
    void sonnerie_transfert_entDef();
    
    //## statechart_method
    void sonnerie_transfert_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus sonnerie_transfert_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus sonnerie_transfert_handleEvent();
    
    // state_243:
    //## statechart_method
    inline bool state_243_IN() const;
    
    //## statechart_method
    void state_243_entDef();
    
    //## statechart_method
    void state_243_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_243_processEvent();
    
    // sonnerie_sonore_trasnfert:
    //## statechart_method
    inline bool sonnerie_sonore_trasnfert_IN() const;
    
    // state_242:
    //## statechart_method
    inline bool state_242_IN() const;
    
    //## statechart_method
    void state_242_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_242_processEvent();
    
    // sonnerie_kit_redirige:
    //## statechart_method
    inline bool sonnerie_kit_redirige_IN() const;
    
    // sonnerie_finie_kit:
    //## statechart_method
    inline bool sonnerie_finie_kit_IN() const;
    
    // init_appel_kit:
    //## statechart_method
    inline bool init_appel_kit_IN() const;
    
    // fin_appel_kit:
    //## statechart_method
    inline bool fin_appel_kit_IN() const;
    
    // attente_appel_kit:
    //## statechart_method
    inline bool attente_appel_kit_IN() const;
    
    // state_184:
    //## statechart_method
    inline bool state_184_IN() const;
    
    //## statechart_method
    void state_184_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_184_processEvent();
    
    // reception_sms:
    //## statechart_method
    inline bool reception_sms_IN() const;
    
    // lire_sms:
    //## statechart_method
    inline bool lire_sms_IN() const;
    
    // state_183:
    //## statechart_method
    inline bool state_183_IN() const;
    
    //## statechart_method
    void state_183_entDef();
    
    //## statechart_method
    void state_183_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_183_processEvent();
    
    // init_appel_telephone:
    //## statechart_method
    inline bool init_appel_telephone_IN() const;
    
    // gestion_sonnerie:
    //## statechart_method
    inline bool gestion_sonnerie_IN() const;
    
    //## statechart_method
    void gestion_sonnerie_entDef();
    
    //## statechart_method
    void gestion_sonnerie_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sonnerie_handleEvent();
    
    // state_240:
    //## statechart_method
    inline bool state_240_IN() const;
    
    //## statechart_method
    void state_240_entDef();
    
    //## statechart_method
    void state_240_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_240_processEvent();
    
    // sonnerie_sonore:
    //## statechart_method
    inline bool sonnerie_sonore_IN() const;
    
    // state_239:
    //## statechart_method
    inline bool state_239_IN() const;
    
    //## statechart_method
    void state_239_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_239_processEvent();
    
    // sonnerie_lumineuse:
    //## statechart_method
    inline bool sonnerie_lumineuse_IN() const;
    
    // sonnerie_finie:
    //## statechart_method
    inline bool sonnerie_finie_IN() const;
    
    // attente_appel_tel:
    //## statechart_method
    inline bool attente_appel_tel_IN() const;
    
    // appel_en_cours:
    //## statechart_method
    inline bool appel_en_cours_IN() const;
    
    // arret_de_communication:
    //## statechart_method
    inline bool arret_de_communication_IN() const;
    
    //## statechart_method
    void arret_de_communication_entDef();
    
    //## statechart_method
    void arret_de_communication_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus arret_de_communicationTakeEVAL();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus arret_de_communication_handleEvent();
    
    // gestion_sms_hors_ligne:
    //## statechart_method
    inline bool gestion_sms_hors_ligne_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus gestion_sms_hors_ligne_handleEvent();
    
    // state_126:
    //## statechart_method
    inline bool state_126_IN() const;
    
    //## statechart_method
    void state_126_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_126_processEvent();
    
    // verifiaction_telephone_allume:
    //## statechart_method
    inline bool verifiaction_telephone_allume_IN() const;
    
    // charge_batterie_telephone:
    //## statechart_method
    inline bool charge_batterie_telephone_IN() const;
    
    // batterie_telephone:
    //## statechart_method
    inline bool batterie_telephone_IN() const;

protected :

//#[ ignore
    enum _SysVehicule_Enum {
        OMNonState = 0,
        Systeme = 1,
        state_96 = 2,
        telephone_eteint = 3,
        telephone_actif = 4,
        bluetooth_telephone_desactive = 5,
        bluetooth_telephone_active = 6,
        recherche_bluetooth = 7,
        kit_detecte = 8,
        kit_connecte = 9,
        jumelage = 10,
        jumelage_effectif = 11,
        attente_reponse = 12,
        attente_jumelage = 13,
        interruption_bluetooth_kit = 14,
        connexion = 15,
        state_87 = 16,
        demarrage_bluetooth = 17,
        bluetooth_desactive = 18,
        bluetooth_active = 19,
        telephone_connecte = 20,
        recherche_telephone = 21,
        operation_jumelage = 22,
        jumelage_kit = 23,
        attente_connexion = 24,
        state_76 = 25,
        limiteur_on = 26,
        limiteur_on_plus = 27,
        limiteur_on_moins = 28,
        consigne_fixe = 29,
        limiteur_inhibe = 30,
        limiteur_effectif = 31,
        limite_tenue = 32,
        depassement = 33,
        limiteur_off = 34,
        state_72 = 35,
        simulation_du_vehicule = 36,
        state_71 = 37,
        mode_regulateur = 38,
        plus = 39,
        moins = 40,
        maintien = 41,
        mode_manuel = 42,
        state_62 = 43,
        horloge_rafraichissement = 44,
        state_61 = 45,
        contact_on = 46,
        state_267 = 47,
        calcul_batterie_voiture = 48,
        state_266 = 49,
        moteur_on = 50,
        moteur_off = 51,
        contact_off = 52,
        state_60 = 53,
        regulateur = 54,
        verification_distance_securite = 55,
        suivi_vitesse_consigne = 56,
        suivi_distance_consigne = 57,
        pedales = 58,
        freinage_injection = 59,
        acceleration = 60,
        state_278 = 61,
        radio_prete = 62,
        radio_eteinte = 63,
        contact_radio_actif = 64,
        priorite_sonnerie = 65,
        priorite_radio = 66,
        state_260 = 67,
        attente_btn_radio = 68,
        appui_btn_radio = 69,
        state_233 = 70,
        radio_active = 71,
        musique_3 = 72,
        musique_2 = 73,
        musique_1 = 74,
        lancement_radio = 75,
        priorite_appel = 76,
        state_275 = 77,
        simulation_voiture_devant = 78,
        loop_simulation = 79,
        reglage_voiture_devant = 80,
        state_252 = 81,
        remplir_carburant = 82,
        panne_carburant = 83,
        panne_batterie = 84,
        fonctionelle = 85,
        depanner_batterie = 86,
        state_206 = 87,
        sms_exterrieur = 88,
        state_166 = 89,
        telephone_deconnecte = 90,
        controle_telephone_connecte = 91,
        state_204 = 92,
        state_199 = 93,
        messagerie_kit = 94,
        lire_message_kit = 95,
        init_redirection_sms_kit = 96,
        state_198 = 97,
        gestion_btn_lire_sms_kit = 98,
        state_174 = 99,
        gestion_btn_decrocher_kit = 100,
        state_173 = 101,
        gestion_btn_raccrocher_kit = 102,
        state_131 = 103,
        gestion_sonnerie_kit = 104,
        gestion_sonnerie_kit_state_240 = 105,
        sonnerie_sonore_kit = 106,
        gestion_sonnerie_kit_gestion_sonnerie_kit = 107,
        sonnerie_lumineuse_kit = 108,
        attente_redirection_appel = 109,
        appel_en_cours_kit = 110,
        state_130 = 111,
        affichage_batterie = 112,
        state_146 = 113,
        tentative_appel = 114,
        debut_tentative = 115,
        telephone_SIM = 116,
        discussion_telephonique = 117,
        state_139 = 118,
        gestion_communication = 119,
        gestion_communication_telephone = 120,
        state_262 = 121,
        redirection_off = 122,
        redirection_kit_bluetooth_communication = 123,
        state_189 = 124,
        reception_sms_kit = 125,
        lire_sms_kit = 126,
        state_188 = 127,
        transfer_appel = 128,
        sonnerie_transfert = 129,
        state_243 = 130,
        sonnerie_sonore_trasnfert = 131,
        state_242 = 132,
        sonnerie_kit_redirige = 133,
        sonnerie_finie_kit = 134,
        init_appel_kit = 135,
        fin_appel_kit = 136,
        attente_appel_kit = 137,
        state_184 = 138,
        reception_sms = 139,
        lire_sms = 140,
        state_183 = 141,
        init_appel_telephone = 142,
        gestion_sonnerie = 143,
        state_240 = 144,
        sonnerie_sonore = 145,
        state_239 = 146,
        sonnerie_lumineuse = 147,
        sonnerie_finie = 148,
        attente_appel_tel = 149,
        appel_en_cours = 150,
        arret_de_communication = 151,
        gestion_sms_hors_ligne = 152,
        state_126 = 153,
        verifiaction_telephone_allume = 154,
        charge_batterie_telephone = 155,
        batterie_telephone = 156
    };
    
    int rootState_subState;
    
    int rootState_active;
    
    int state_96_subState;
    
    int state_96_active;
    
    int telephone_actif_subState;
    
    int bluetooth_telephone_active_subState;
    
    int jumelage_subState;
    
    IOxfTimeout* jumelage_timeout;
    
    IOxfTimeout* bluetooth_telephone_active_timeout;
    
    int state_87_subState;
    
    int state_87_active;
    
    IOxfTimeout* state_87_timeout;
    
    int bluetooth_active_subState;
    
    IOxfTimeout* bluetooth_active_timeout;
    
    int operation_jumelage_subState;
    
    int state_76_subState;
    
    int state_76_active;
    
    int limiteur_on_subState;
    
    IOxfTimeout* limiteur_on_timeout;
    
    int consigne_fixe_subState;
    
    int limiteur_effectif_subState;
    
    int state_72_subState;
    
    int state_72_active;
    
    int state_71_subState;
    
    int state_71_active;
    
    int mode_regulateur_subState;
    
    int state_62_subState;
    
    int state_62_active;
    
    IOxfTimeout* state_62_timeout;
    
    int state_61_subState;
    
    int state_61_active;
    
    int state_267_subState;
    
    int state_267_active;
    
    IOxfTimeout* state_267_timeout;
    
    int state_266_subState;
    
    int state_266_active;
    
    int state_60_subState;
    
    int state_60_active;
    
    int regulateur_subState;
    
    IOxfTimeout* state_60_timeout;
    
    int pedales_subState;
    
    IOxfTimeout* pedales_timeout;
    
    int state_278_subState;
    
    int state_278_active;
    
    int contact_radio_actif_subState;
    
    int state_260_subState;
    
    int state_260_active;
    
    IOxfTimeout* state_260_timeout;
    
    int state_233_subState;
    
    int state_233_active;
    
    int radio_active_subState;
    
    int radio_active_lastState;
    
    IOxfTimeout* radio_active_timeout;
    
    int state_275_subState;
    
    int state_275_active;
    
    int simulation_voiture_devant_subState;
    
    int state_252_subState;
    
    int state_252_active;
    
    int state_206_subState;
    
    int state_206_active;
    
    int state_166_subState;
    
    int state_166_active;
    
    int state_204_subState;
    
    int state_204_active;
    
    int state_199_subState;
    
    int state_199_active;
    
    int state_198_subState;
    
    int state_198_active;
    
    int state_174_subState;
    
    int state_174_active;
    
    int state_173_subState;
    
    int state_173_active;
    
    int state_131_subState;
    
    int state_131_active;
    
    int gestion_sonnerie_kit_state_240_subState;
    
    int gestion_sonnerie_kit_state_240_active;
    
    int gestion_sonnerie_kit_gestion_sonnerie_kit_subState;
    
    int gestion_sonnerie_kit_gestion_sonnerie_kit_active;
    
    int state_130_subState;
    
    int state_130_active;
    
    int state_146_subState;
    
    int state_146_active;
    
    int tentative_appel_subState;
    
    IOxfTimeout* state_146_timeout;
    
    IOxfTimeout* tentative_appel_timeout;
    
    int state_139_subState;
    
    int state_139_active;
    
    int gestion_communication_subState;
    
    int state_262_subState;
    
    int state_262_active;
    
    int state_189_subState;
    
    int state_189_active;
    
    IOxfTimeout* state_189_timeout;
    
    int state_188_subState;
    
    int state_188_active;
    
    int state_243_subState;
    
    int state_243_active;
    
    IOxfTimeout* state_243_timeout;
    
    int state_242_subState;
    
    int state_242_active;
    
    IOxfTimeout* state_242_timeout;
    
    int state_184_subState;
    
    int state_184_active;
    
    IOxfTimeout* state_184_timeout;
    
    int state_183_subState;
    
    int state_183_active;
    
    int state_240_subState;
    
    int state_240_active;
    
    IOxfTimeout* state_240_timeout;
    
    int state_239_subState;
    
    int state_239_active;
    
    IOxfTimeout* state_239_timeout;
    
    int arret_de_communication_subState;
    
    int state_126_subState;
    
    int state_126_active;
    
    IOxfTimeout* state_126_timeout;
//#]
};

#ifdef _OMINSTRUMENT
DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setAccelPedal_double)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setAffichage_liste_appareils_OMString)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setAlpha_int)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setBrakePedal_double)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setChamp_mdp_OMString)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setCmd_contact_bool)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setCmd_radio_bool)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setDistance_inter_voiture_double)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setTelephone_allume_bool)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setVitesse_voiture_devant_double)

//#[ ignore
class OMAnimated_SysVehicule : virtual public AOMInstance {
    DECLARE_REACTIVE_META(_SysVehicule, OMAnimated_SysVehicule)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setAccelPedal_double)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setAffichage_liste_appareils_OMString)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setAlpha_int)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setBrakePedal_double)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setChamp_mdp_OMString)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setCmd_bluetooth_telephone_actif_bool)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setCmd_charge_vehicule_telephone_bool)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setCmd_contact_bool)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setCmd_radio_bool)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setCmd_simulation_voiture_devant_bool)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setDistance_inter_voiture_double)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setTelephone_allume_bool)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setVitesse_voiture_devant_double)
    
    ////    Framework operations    ////
    
public :

    virtual void serializeAttributes(AOMSAttributes* aomsAttributes) const;
    
    //## statechart_method
    void rootState_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void Systeme_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_96_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void telephone_eteint_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void telephone_actif_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void bluetooth_telephone_desactive_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void bluetooth_telephone_active_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void recherche_bluetooth_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void kit_detecte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void kit_connecte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void jumelage_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void jumelage_effectif_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_reponse_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_jumelage_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void interruption_bluetooth_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void connexion_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_87_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void demarrage_bluetooth_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void bluetooth_desactive_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void bluetooth_active_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void telephone_connecte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void recherche_telephone_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void operation_jumelage_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void jumelage_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_connexion_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_76_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_on_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_on_plus_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_on_moins_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void consigne_fixe_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_inhibe_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_effectif_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limite_tenue_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void depassement_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_72_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void simulation_du_vehicule_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_71_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void mode_regulateur_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void plus_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void moins_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void maintien_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void mode_manuel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_62_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void horloge_rafraichissement_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_61_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void contact_on_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_267_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void calcul_batterie_voiture_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_266_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void moteur_on_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void moteur_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void contact_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_60_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void regulateur_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void verification_distance_securite_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void suivi_vitesse_consigne_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void suivi_distance_consigne_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void pedales_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void freinage_injection_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void acceleration_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_278_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void radio_prete_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void radio_eteinte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void contact_radio_actif_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void priorite_sonnerie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void priorite_radio_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_260_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_btn_radio_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void appui_btn_radio_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_233_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void radio_active_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void musique_3_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void musique_2_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void musique_1_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void lancement_radio_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void priorite_appel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_275_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void simulation_voiture_devant_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void loop_simulation_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void reglage_voiture_devant_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_252_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void remplir_carburant_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void panne_carburant_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void panne_batterie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void fonctionelle_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void depanner_batterie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_206_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sms_exterrieur_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_166_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void telephone_deconnecte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void controle_telephone_connecte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_204_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_199_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void messagerie_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void lire_message_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void init_redirection_sms_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_198_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_btn_lire_sms_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_174_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_btn_decrocher_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_173_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_btn_raccrocher_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_131_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_sonnerie_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_sonnerie_kit_state_240_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_sonore_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_sonnerie_kit_gestion_sonnerie_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_lumineuse_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_redirection_appel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void appel_en_cours_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_130_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void affichage_batterie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_146_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void tentative_appel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void debut_tentative_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void telephone_SIM_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void discussion_telephonique_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_139_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_communication_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_communication_telephone_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_262_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void redirection_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void redirection_kit_bluetooth_communication_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_189_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void reception_sms_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void lire_sms_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_188_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void transfer_appel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_transfert_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_243_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_sonore_trasnfert_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_242_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_kit_redirige_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_finie_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void init_appel_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void fin_appel_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_appel_kit_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_184_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void reception_sms_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void lire_sms_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_183_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void init_appel_telephone_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_sonnerie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_240_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_sonore_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_239_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_lumineuse_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void sonnerie_finie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void attente_appel_tel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void appel_en_cours_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void arret_de_communication_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void gestion_sms_hors_ligne_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_126_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void verifiaction_telephone_allume_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void charge_batterie_telephone_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void batterie_telephone_serializeStates(AOMSState* aomsState) const;
};
//#]
#endif // _OMINSTRUMENT

inline bool _SysVehicule::rootState_IN() const {
    return true;
}

inline bool _SysVehicule::Systeme_IN() const {
    return rootState_subState == Systeme;
}

inline bool _SysVehicule::state_96_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::telephone_eteint_IN() const {
    return state_96_subState == telephone_eteint;
}

inline bool _SysVehicule::telephone_actif_IN() const {
    return state_96_subState == telephone_actif;
}

inline bool _SysVehicule::bluetooth_telephone_desactive_IN() const {
    return telephone_actif_subState == bluetooth_telephone_desactive;
}

inline bool _SysVehicule::bluetooth_telephone_active_IN() const {
    return telephone_actif_subState == bluetooth_telephone_active;
}

inline bool _SysVehicule::recherche_bluetooth_IN() const {
    return bluetooth_telephone_active_subState == recherche_bluetooth;
}

inline bool _SysVehicule::kit_detecte_IN() const {
    return bluetooth_telephone_active_subState == kit_detecte;
}

inline bool _SysVehicule::kit_connecte_IN() const {
    return bluetooth_telephone_active_subState == kit_connecte;
}

inline bool _SysVehicule::jumelage_IN() const {
    return bluetooth_telephone_active_subState == jumelage;
}

inline bool _SysVehicule::jumelage_effectif_IN() const {
    return jumelage_subState == jumelage_effectif;
}

inline bool _SysVehicule::attente_reponse_IN() const {
    return jumelage_subState == attente_reponse;
}

inline bool _SysVehicule::attente_jumelage_IN() const {
    return jumelage_subState == attente_jumelage;
}

inline bool _SysVehicule::interruption_bluetooth_kit_IN() const {
    return bluetooth_telephone_active_subState == interruption_bluetooth_kit;
}

inline bool _SysVehicule::connexion_IN() const {
    return bluetooth_telephone_active_subState == connexion;
}

inline bool _SysVehicule::state_87_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::demarrage_bluetooth_IN() const {
    return state_87_subState == demarrage_bluetooth;
}

inline bool _SysVehicule::bluetooth_desactive_IN() const {
    return state_87_subState == bluetooth_desactive;
}

inline bool _SysVehicule::bluetooth_active_IN() const {
    return state_87_subState == bluetooth_active;
}

inline bool _SysVehicule::telephone_connecte_IN() const {
    return bluetooth_active_subState == telephone_connecte;
}

inline bool _SysVehicule::recherche_telephone_IN() const {
    return bluetooth_active_subState == recherche_telephone;
}

inline bool _SysVehicule::operation_jumelage_IN() const {
    return bluetooth_active_subState == operation_jumelage;
}

inline bool _SysVehicule::jumelage_kit_IN() const {
    return operation_jumelage_subState == jumelage_kit;
}

inline bool _SysVehicule::attente_connexion_IN() const {
    return operation_jumelage_subState == attente_connexion;
}

inline bool _SysVehicule::state_76_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::limiteur_on_IN() const {
    return state_76_subState == limiteur_on;
}

inline bool _SysVehicule::limiteur_on_plus_IN() const {
    return limiteur_on_subState == limiteur_on_plus;
}

inline bool _SysVehicule::limiteur_on_moins_IN() const {
    return limiteur_on_subState == limiteur_on_moins;
}

inline bool _SysVehicule::consigne_fixe_IN() const {
    return limiteur_on_subState == consigne_fixe;
}

inline bool _SysVehicule::limiteur_inhibe_IN() const {
    return consigne_fixe_subState == limiteur_inhibe;
}

inline bool _SysVehicule::limiteur_effectif_IN() const {
    return consigne_fixe_subState == limiteur_effectif;
}

inline bool _SysVehicule::limite_tenue_IN() const {
    return limiteur_effectif_subState == limite_tenue;
}

inline bool _SysVehicule::depassement_IN() const {
    return limiteur_effectif_subState == depassement;
}

inline bool _SysVehicule::limiteur_off_IN() const {
    return state_76_subState == limiteur_off;
}

inline bool _SysVehicule::state_72_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::simulation_du_vehicule_IN() const {
    return state_72_subState == simulation_du_vehicule;
}

inline bool _SysVehicule::state_71_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::mode_regulateur_IN() const {
    return state_71_subState == mode_regulateur;
}

inline bool _SysVehicule::plus_IN() const {
    return mode_regulateur_subState == plus;
}

inline bool _SysVehicule::moins_IN() const {
    return mode_regulateur_subState == moins;
}

inline bool _SysVehicule::maintien_IN() const {
    return mode_regulateur_subState == maintien;
}

inline bool _SysVehicule::mode_manuel_IN() const {
    return state_71_subState == mode_manuel;
}

inline bool _SysVehicule::state_62_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::horloge_rafraichissement_IN() const {
    return state_62_subState == horloge_rafraichissement;
}

inline bool _SysVehicule::state_61_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::contact_on_IN() const {
    return state_61_subState == contact_on;
}

inline bool _SysVehicule::state_267_IN() const {
    return contact_on_IN();
}

inline bool _SysVehicule::calcul_batterie_voiture_IN() const {
    return state_267_subState == calcul_batterie_voiture;
}

inline bool _SysVehicule::state_266_IN() const {
    return contact_on_IN();
}

inline bool _SysVehicule::moteur_on_IN() const {
    return state_266_subState == moteur_on;
}

inline bool _SysVehicule::moteur_off_IN() const {
    return state_266_subState == moteur_off;
}

inline bool _SysVehicule::contact_off_IN() const {
    return state_61_subState == contact_off;
}

inline bool _SysVehicule::state_60_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::regulateur_IN() const {
    return state_60_subState == regulateur;
}

inline bool _SysVehicule::verification_distance_securite_IN() const {
    return regulateur_subState == verification_distance_securite;
}

inline bool _SysVehicule::suivi_vitesse_consigne_IN() const {
    return regulateur_subState == suivi_vitesse_consigne;
}

inline bool _SysVehicule::suivi_distance_consigne_IN() const {
    return regulateur_subState == suivi_distance_consigne;
}

inline bool _SysVehicule::pedales_IN() const {
    return state_60_subState == pedales;
}

inline bool _SysVehicule::freinage_injection_IN() const {
    return pedales_subState == freinage_injection;
}

inline bool _SysVehicule::acceleration_IN() const {
    return pedales_subState == acceleration;
}

inline bool _SysVehicule::state_278_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::radio_prete_IN() const {
    return state_278_subState == radio_prete;
}

inline bool _SysVehicule::radio_eteinte_IN() const {
    return state_278_subState == radio_eteinte;
}

inline bool _SysVehicule::contact_radio_actif_IN() const {
    return state_278_subState == contact_radio_actif;
}

inline bool _SysVehicule::priorite_sonnerie_IN() const {
    return contact_radio_actif_subState == priorite_sonnerie;
}

inline bool _SysVehicule::priorite_radio_IN() const {
    return contact_radio_actif_subState == priorite_radio;
}

inline bool _SysVehicule::state_260_IN() const {
    return priorite_radio_IN();
}

inline bool _SysVehicule::attente_btn_radio_IN() const {
    return state_260_subState == attente_btn_radio;
}

inline bool _SysVehicule::appui_btn_radio_IN() const {
    return state_260_subState == appui_btn_radio;
}

inline bool _SysVehicule::state_233_IN() const {
    return priorite_radio_IN();
}

inline bool _SysVehicule::radio_active_IN() const {
    return state_233_subState == radio_active;
}

inline bool _SysVehicule::musique_3_IN() const {
    return radio_active_subState == musique_3;
}

inline bool _SysVehicule::musique_2_IN() const {
    return radio_active_subState == musique_2;
}

inline bool _SysVehicule::musique_1_IN() const {
    return radio_active_subState == musique_1;
}

inline bool _SysVehicule::lancement_radio_IN() const {
    return state_233_subState == lancement_radio;
}

inline bool _SysVehicule::priorite_appel_IN() const {
    return contact_radio_actif_subState == priorite_appel;
}

inline bool _SysVehicule::state_275_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::simulation_voiture_devant_IN() const {
    return state_275_subState == simulation_voiture_devant;
}

inline bool _SysVehicule::loop_simulation_IN() const {
    return simulation_voiture_devant_subState == loop_simulation;
}

inline bool _SysVehicule::reglage_voiture_devant_IN() const {
    return state_275_subState == reglage_voiture_devant;
}

inline bool _SysVehicule::state_252_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::remplir_carburant_IN() const {
    return state_252_subState == remplir_carburant;
}

inline bool _SysVehicule::panne_carburant_IN() const {
    return state_252_subState == panne_carburant;
}

inline bool _SysVehicule::panne_batterie_IN() const {
    return state_252_subState == panne_batterie;
}

inline bool _SysVehicule::fonctionelle_IN() const {
    return state_252_subState == fonctionelle;
}

inline bool _SysVehicule::depanner_batterie_IN() const {
    return state_252_subState == depanner_batterie;
}

inline bool _SysVehicule::state_206_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::sms_exterrieur_IN() const {
    return state_206_subState == sms_exterrieur;
}

inline bool _SysVehicule::state_166_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::telephone_deconnecte_IN() const {
    return state_166_subState == telephone_deconnecte;
}

inline bool _SysVehicule::controle_telephone_connecte_IN() const {
    return state_166_subState == controle_telephone_connecte;
}

inline bool _SysVehicule::state_204_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::state_199_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::messagerie_kit_IN() const {
    return state_199_subState == messagerie_kit;
}

inline bool _SysVehicule::lire_message_kit_IN() const {
    return state_199_subState == lire_message_kit;
}

inline bool _SysVehicule::init_redirection_sms_kit_IN() const {
    return state_199_subState == init_redirection_sms_kit;
}

inline bool _SysVehicule::state_198_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::gestion_btn_lire_sms_kit_IN() const {
    return state_198_subState == gestion_btn_lire_sms_kit;
}

inline bool _SysVehicule::state_174_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::gestion_btn_decrocher_kit_IN() const {
    return state_174_subState == gestion_btn_decrocher_kit;
}

inline bool _SysVehicule::state_173_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::gestion_btn_raccrocher_kit_IN() const {
    return state_173_subState == gestion_btn_raccrocher_kit;
}

inline bool _SysVehicule::state_131_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::gestion_sonnerie_kit_IN() const {
    return state_131_subState == gestion_sonnerie_kit;
}

inline bool _SysVehicule::gestion_sonnerie_kit_state_240_IN() const {
    return gestion_sonnerie_kit_IN();
}

inline bool _SysVehicule::sonnerie_sonore_kit_IN() const {
    return gestion_sonnerie_kit_state_240_subState == sonnerie_sonore_kit;
}

inline bool _SysVehicule::gestion_sonnerie_kit_gestion_sonnerie_kit_IN() const {
    return gestion_sonnerie_kit_IN();
}

inline bool _SysVehicule::sonnerie_lumineuse_kit_IN() const {
    return gestion_sonnerie_kit_gestion_sonnerie_kit_subState == sonnerie_lumineuse_kit;
}

inline bool _SysVehicule::attente_redirection_appel_IN() const {
    return state_131_subState == attente_redirection_appel;
}

inline bool _SysVehicule::appel_en_cours_kit_IN() const {
    return state_131_subState == appel_en_cours_kit;
}

inline bool _SysVehicule::state_130_IN() const {
    return controle_telephone_connecte_IN();
}

inline bool _SysVehicule::affichage_batterie_IN() const {
    return state_130_subState == affichage_batterie;
}

inline bool _SysVehicule::state_146_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::tentative_appel_IN() const {
    return state_146_subState == tentative_appel;
}

inline bool _SysVehicule::debut_tentative_IN() const {
    return tentative_appel_subState == debut_tentative;
}

inline bool _SysVehicule::telephone_SIM_IN() const {
    return state_146_subState == telephone_SIM;
}

inline bool _SysVehicule::discussion_telephonique_IN() const {
    return state_146_subState == discussion_telephonique;
}

inline bool _SysVehicule::state_139_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::gestion_communication_IN() const {
    return state_139_subState == gestion_communication;
}

inline bool _SysVehicule::gestion_communication_telephone_IN() const {
    return gestion_communication_subState == gestion_communication_telephone;
}

inline bool _SysVehicule::state_262_IN() const {
    return gestion_communication_telephone_IN();
}

inline bool _SysVehicule::redirection_off_IN() const {
    return state_262_subState == redirection_off;
}

inline bool _SysVehicule::redirection_kit_bluetooth_communication_IN() const {
    return state_262_subState == redirection_kit_bluetooth_communication;
}

inline bool _SysVehicule::state_189_IN() const {
    return redirection_kit_bluetooth_communication_IN();
}

inline bool _SysVehicule::reception_sms_kit_IN() const {
    return state_189_subState == reception_sms_kit;
}

inline bool _SysVehicule::lire_sms_kit_IN() const {
    return state_189_subState == lire_sms_kit;
}

inline bool _SysVehicule::state_188_IN() const {
    return redirection_kit_bluetooth_communication_IN();
}

inline bool _SysVehicule::transfer_appel_IN() const {
    return state_188_subState == transfer_appel;
}

inline bool _SysVehicule::sonnerie_transfert_IN() const {
    return state_188_subState == sonnerie_transfert;
}

inline bool _SysVehicule::state_243_IN() const {
    return sonnerie_transfert_IN();
}

inline bool _SysVehicule::sonnerie_sonore_trasnfert_IN() const {
    return state_243_subState == sonnerie_sonore_trasnfert;
}

inline bool _SysVehicule::state_242_IN() const {
    return sonnerie_transfert_IN();
}

inline bool _SysVehicule::sonnerie_kit_redirige_IN() const {
    return state_242_subState == sonnerie_kit_redirige;
}

inline bool _SysVehicule::sonnerie_finie_kit_IN() const {
    return state_242_subState == sonnerie_finie_kit;
}

inline bool _SysVehicule::init_appel_kit_IN() const {
    return state_188_subState == init_appel_kit;
}

inline bool _SysVehicule::fin_appel_kit_IN() const {
    return state_188_subState == fin_appel_kit;
}

inline bool _SysVehicule::attente_appel_kit_IN() const {
    return state_188_subState == attente_appel_kit;
}

inline bool _SysVehicule::state_184_IN() const {
    return gestion_communication_telephone_IN();
}

inline bool _SysVehicule::reception_sms_IN() const {
    return state_184_subState == reception_sms;
}

inline bool _SysVehicule::lire_sms_IN() const {
    return state_184_subState == lire_sms;
}

inline bool _SysVehicule::state_183_IN() const {
    return gestion_communication_telephone_IN();
}

inline bool _SysVehicule::init_appel_telephone_IN() const {
    return state_183_subState == init_appel_telephone;
}

inline bool _SysVehicule::gestion_sonnerie_IN() const {
    return state_183_subState == gestion_sonnerie;
}

inline bool _SysVehicule::state_240_IN() const {
    return gestion_sonnerie_IN();
}

inline bool _SysVehicule::sonnerie_sonore_IN() const {
    return state_240_subState == sonnerie_sonore;
}

inline bool _SysVehicule::state_239_IN() const {
    return gestion_sonnerie_IN();
}

inline bool _SysVehicule::sonnerie_lumineuse_IN() const {
    return state_239_subState == sonnerie_lumineuse;
}

inline bool _SysVehicule::sonnerie_finie_IN() const {
    return state_239_subState == sonnerie_finie;
}

inline bool _SysVehicule::attente_appel_tel_IN() const {
    return state_183_subState == attente_appel_tel;
}

inline bool _SysVehicule::appel_en_cours_IN() const {
    return state_183_subState == appel_en_cours;
}

inline bool _SysVehicule::arret_de_communication_IN() const {
    return state_139_subState == arret_de_communication;
}

inline bool _SysVehicule::gestion_sms_hors_ligne_IN() const {
    return arret_de_communication_subState == gestion_sms_hors_ligne;
}

inline bool _SysVehicule::state_126_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::verifiaction_telephone_allume_IN() const {
    return state_126_subState == verifiaction_telephone_allume;
}

inline bool _SysVehicule::charge_batterie_telephone_IN() const {
    return state_126_subState == charge_batterie_telephone;
}

inline bool _SysVehicule::batterie_telephone_IN() const {
    return state_126_subState == batterie_telephone;
}

#endif
/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.h
*********************************************************************/
