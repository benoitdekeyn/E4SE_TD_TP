################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/Ecran_LCD/Src/i2c-lcd.c 

OBJS += \
./Ecran_LCD/Src/i2c-lcd.o 

C_DEPS += \
./Ecran_LCD/Src/i2c-lcd.d 


# Each subdirectory must supply rules for building sources it contributes
Ecran_LCD/Src/i2c-lcd.o: C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/Ecran_LCD/Src/i2c-lcd.c Ecran_LCD/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I"C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/Ecran_LCD/Inc" -I"C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/Bande_LED/Inc" -I"C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/TMP102/Inc" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Ecran_LCD-2f-Src

clean-Ecran_LCD-2f-Src:
	-$(RM) ./Ecran_LCD/Src/i2c-lcd.cyclo ./Ecran_LCD/Src/i2c-lcd.d ./Ecran_LCD/Src/i2c-lcd.o ./Ecran_LCD/Src/i2c-lcd.su

.PHONY: clean-Ecran_LCD-2f-Src

