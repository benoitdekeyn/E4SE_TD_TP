/*********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: ModeAnimation
//!	Generated Date	: Sat, 10, Oct 2026  
	File Path	: CodesGeneres\ModeAnimation\MainCodesGeneres.h
*********************************************************************/

#ifndef MainCodesGeneres_H
#define MainCodesGeneres_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "Windows.h"
//## auto_generated
#include "stdlib.h"
//## auto_generated
#include "stdio.h"
//## auto_generated
#include "string.h"
//## auto_generated
#include "stdint.h"
//## auto_generated
#include "tchar.h"
#endif
/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\MainCodesGeneres.h
*********************************************************************/
