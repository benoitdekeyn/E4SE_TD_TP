################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/TMP102/Src/tmp102.c 

OBJS += \
./TMP102/Src/tmp102.o 

C_DEPS += \
./TMP102/Src/tmp102.d 


# Each subdirectory must supply rules for building sources it contributes
TMP102/Src/tmp102.o: C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/TMP102/Src/tmp102.c TMP102/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I"C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/Ecran_LCD/Inc" -I"C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/Bande_LED/Inc" -I"C:/Users/benoi/Documents/GitHub/E4SE_TD_TP/architecture_numeriques_embarquees/STM32CubeIDE_v1.19.0/Bibliotheques/TMP102/Inc" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-TMP102-2f-Src

clean-TMP102-2f-Src:
	-$(RM) ./TMP102/Src/tmp102.cyclo ./TMP102/Src/tmp102.d ./TMP102/Src/tmp102.o ./TMP102/Src/tmp102.su

.PHONY: clean-TMP102-2f-Src

