#include <TABDK/MoveAction.h>
#include <actionlib/client/simple_action_client.h>
#include <ros/ros.h>

#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <string>
#include <vector>

bool lireCoordonnee(const std::string &texte, double &valeur) {
  char *fin = nullptr;
  errno = 0;
  valeur = std::strtod(texte.c_str(), &fin);
  return fin != texte.c_str() && *fin == '\0' && errno != ERANGE &&
         std::isfinite(valeur);
}

void feedbackCallback(const TABDK::MoveFeedbackConstPtr &feedback) {
  ROS_INFO("Position (%.2f, %.2f), vitesse %.2f m/s, distance %.2f m, mode %s, pause %s",
           feedback->position.x, feedback->position.y, feedback->vitesse.linear.x,
           feedback->distance_restante, feedback->mode.c_str(),
           feedback->pause ? "oui" : "non");
}

int main(int argc, char **argv) {
  ros::init(argc, argv, "move_client");
  std::vector<std::string> arguments;
  ros::removeROSArgs(argc, argv, arguments);
  TABDK::MoveGoal goal;
  if (arguments.size() != 3 ||
      !lireCoordonnee(arguments[1], goal.position_x) ||
      !lireCoordonnee(arguments[2], goal.position_y)) {
    ROS_ERROR("Usage : rosrun TABDK move <x> <y>");
    return 1;
  }

  actionlib::SimpleActionClient<TABDK::MoveAction> client("/move", true);
  if (!client.waitForServer(ros::Duration(5.0))) {
    ROS_ERROR("Serveur /move indisponible");
    return 1;
  }
  client.sendGoal(goal, actionlib::SimpleActionClient<TABDK::MoveAction>::SimpleDoneCallback(),
                  actionlib::SimpleActionClient<TABDK::MoveAction>::SimpleActiveCallback(),
                  &feedbackCallback);
  client.waitForResult();

  const actionlib::SimpleClientGoalState etat = client.getState();
  const TABDK::MoveResultConstPtr result = client.getResult();
  if (!result) {
    ROS_ERROR("Action terminee sans resultat : %s", etat.toString().c_str());
    return 1;
  }
  ROS_INFO("Action %s : atteint=%d, temps=%.2f s, distance=%.2f m, position=(%.2f, %.2f, %.2f)",
           etat.toString().c_str(), result->atteint, result->temps_pris,
           result->distance_parcourue, result->position.x, result->position.y,
           result->position.theta);
  return etat == actionlib::SimpleClientGoalState::SUCCEEDED ? 0 : 1;
}
