/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SERIAL_TX_Pin GPIO_PIN_2
#define SERIAL_TX_GPIO_Port GPIOA
#define SERIAL_RX_Pin GPIO_PIN_3
#define SERIAL_RX_GPIO_Port GPIOA
#define GAZ_Pin GPIO_PIN_4
#define GAZ_GPIO_Port GPIOA
#define BTN_HOME_Pin GPIO_PIN_6
#define BTN_HOME_GPIO_Port GPIOA
#define BTN_HOME_EXTI_IRQn EXTI9_5_IRQn
#define RGB_ROUGE_Pin GPIO_PIN_7
#define RGB_ROUGE_GPIO_Port GPIOA
#define PLUIE_Pin GPIO_PIN_0
#define PLUIE_GPIO_Port GPIOB
#define LED_BLEUE_Pin GPIO_PIN_10
#define LED_BLEUE_GPIO_Port GPIOB
#define PIR_MVMT_Pin GPIO_PIN_7
#define PIR_MVMT_GPIO_Port GPIOC
#define PIR_MVMT_EXTI_IRQn EXTI9_5_IRQn
#define I2C_SDA_Pin GPIO_PIN_8
#define I2C_SDA_GPIO_Port GPIOA
#define SERVO_Pin GPIO_PIN_9
#define SERVO_GPIO_Port GPIOA
#define BTN_FENTR_Pin GPIO_PIN_10
#define BTN_FENTR_GPIO_Port GPIOA
#define BTN_FENTR_EXTI_IRQn EXTI15_10_IRQn
#define LED_JAUNE_Pin GPIO_PIN_3
#define LED_JAUNE_GPIO_Port GPIOB
#define I2C_SCL_Pin GPIO_PIN_4
#define I2C_SCL_GPIO_Port GPIOB
#define BUZZER_Pin GPIO_PIN_5
#define BUZZER_GPIO_Port GPIOB
#define RGB_BANDE_Pin GPIO_PIN_6
#define RGB_BANDE_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
