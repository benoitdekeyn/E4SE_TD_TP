/********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: IHM_Objets
//!	Generated Date	: Sat, 10, Oct 2026  
	File Path	: CodesGeneres\ModeAnimation\IHM_Objets.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "IHM_Objets.h"
//## auto_generated
#include "Main.h"
//## package IHM_Objets


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(IHM_Objets, IHM_Objets)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\IHM_Objets.cpp
*********************************************************************/
