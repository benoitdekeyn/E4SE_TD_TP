/*********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _MonPkg
//!	Generated Date	: Wed, 21, Oct 2026  
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.h
*********************************************************************/

#ifndef _MonPkg_H
#define _MonPkg_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "Windows.h"
//## auto_generated
#include "stdlib.h"
//## auto_generated
#include "stdio.h"
//## auto_generated
#include "string.h"
//## auto_generated
#include "stdint.h"
//## auto_generated
#include "tchar.h"
//## auto_generated
#include <oxf\event.h>
//## auto_generated
class _SysVehicule;

//#[ ignore
#define Push_Carburant__MonPkg_id 13401

#define cablage__MonPkg_id 13402

#define f__MonPkg_id 13403

#define Operation_108__MonPkg_id 13404

#define decr_vitesseConsigne__MonPkg_id 13405

#define incr_vitesseConsigne__MonPkg_id 13406

#define ev_Demarrer__MonPkg_id 13407

#define evDemarrer__MonPkg_id 13408

#define ev_demarrer__MonPkg_id 13409

#define ev_depanner_batterie__MonPkg_id 13410

#define ev_remplir_carburant__MonPkg_id 13411

#define ev_vitesseConsigne_moins__MonPkg_id 13412

#define ev_vitesseConsigne_plus__MonPkg_id 13413

#define ev___MonPkg_id 13414

#define moteur__MonPkg_id 13415

#define t__MonPkg_id 13416

#define EVAL__MonPkg_id 13417

#define ev_limiteur__MonPkg_id 13418

#define ev_regulateur__MonPkg_id 13419

#define ev_ok__MonPkg_id 13420

#define ev_jumeler__MonPkg_id 13421

#define GEN__MonPkg_id 13422

#define ev_kit_vehicule_pret__MonPkg_id 13423
//#]

//## package _MonPkg



//## event Push_Carburant()
class Push_Carburant : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedPush_Carburant;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    Push_Carburant();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedPush_Carburant : virtual public AOMEvent {
    DECLARE_META_EVENT(Push_Carburant)
};
//#]
#endif // _OMINSTRUMENT

//## event cablage()
class cablage : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedcablage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    cablage();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedcablage : virtual public AOMEvent {
    DECLARE_META_EVENT(cablage)
};
//#]
#endif // _OMINSTRUMENT

//## event f()
class f : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedf;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    f();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedf : virtual public AOMEvent {
    DECLARE_META_EVENT(f)
};
//#]
#endif // _OMINSTRUMENT

//## event Operation_108()
class Operation_108 : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedOperation_108;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    Operation_108();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedOperation_108 : virtual public AOMEvent {
    DECLARE_META_EVENT(Operation_108)
};
//#]
#endif // _OMINSTRUMENT

//## event decr_vitesseConsigne()
class decr_vitesseConsigne : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimateddecr_vitesseConsigne;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    decr_vitesseConsigne();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimateddecr_vitesseConsigne : virtual public AOMEvent {
    DECLARE_META_EVENT(decr_vitesseConsigne)
};
//#]
#endif // _OMINSTRUMENT

//## event incr_vitesseConsigne()
class incr_vitesseConsigne : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedincr_vitesseConsigne;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    incr_vitesseConsigne();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedincr_vitesseConsigne : virtual public AOMEvent {
    DECLARE_META_EVENT(incr_vitesseConsigne)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_Demarrer()
class ev_Demarrer : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_Demarrer;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_Demarrer();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_Demarrer : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_Demarrer)
};
//#]
#endif // _OMINSTRUMENT

//## event evDemarrer()
class evDemarrer : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedevDemarrer;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    evDemarrer();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedevDemarrer : virtual public AOMEvent {
    DECLARE_META_EVENT(evDemarrer)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_demarrer()
class ev_demarrer : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_demarrer;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_demarrer();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_demarrer : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_demarrer)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_depanner_batterie()
class ev_depanner_batterie : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_depanner_batterie;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_depanner_batterie();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_depanner_batterie : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_depanner_batterie)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_remplir_carburant()
class ev_remplir_carburant : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_remplir_carburant;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_remplir_carburant();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_remplir_carburant : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_remplir_carburant)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_vitesseConsigne_moins()
class ev_vitesseConsigne_moins : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_vitesseConsigne_moins;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_vitesseConsigne_moins();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_vitesseConsigne_moins : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_vitesseConsigne_moins)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_vitesseConsigne_plus()
class ev_vitesseConsigne_plus : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_vitesseConsigne_plus;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_vitesseConsigne_plus();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_vitesseConsigne_plus : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_vitesseConsigne_plus)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_()
class ev_ : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_ : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_)
};
//#]
#endif // _OMINSTRUMENT

//## event moteur()
class moteur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedmoteur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    moteur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedmoteur : virtual public AOMEvent {
    DECLARE_META_EVENT(moteur)
};
//#]
#endif // _OMINSTRUMENT

//## event t()
class t : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedt;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    t();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedt : virtual public AOMEvent {
    DECLARE_META_EVENT(t)
};
//#]
#endif // _OMINSTRUMENT

//## event EVAL()
class EVAL : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedEVAL;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    EVAL();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedEVAL : virtual public AOMEvent {
    DECLARE_META_EVENT(EVAL)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_limiteur()
class ev_limiteur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_limiteur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_limiteur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_limiteur : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_limiteur)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_regulateur()
class ev_regulateur : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_regulateur;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_regulateur();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_regulateur : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_regulateur)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_ok()
class ev_ok : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_ok;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_ok();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_ok : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_ok)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_jumeler()
class ev_jumeler : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_jumeler;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_jumeler();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_jumeler : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_jumeler)
};
//#]
#endif // _OMINSTRUMENT

//## event GEN()
class GEN : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedGEN;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    GEN();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedGEN : virtual public AOMEvent {
    DECLARE_META_EVENT(GEN)
};
//#]
#endif // _OMINSTRUMENT

//## event ev_kit_vehicule_pret()
class ev_kit_vehicule_pret : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedev_kit_vehicule_pret;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    ev_kit_vehicule_pret();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedev_kit_vehicule_pret : virtual public AOMEvent {
    DECLARE_META_EVENT(ev_kit_vehicule_pret)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_MonPkg.h
*********************************************************************/
