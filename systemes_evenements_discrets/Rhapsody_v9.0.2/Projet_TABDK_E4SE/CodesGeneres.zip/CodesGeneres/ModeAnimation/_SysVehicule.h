/*********************************************************************
	Rhapsody	: 9.0.2 
	Login		: benoi
	Component	: CodesGeneres 
	Configuration 	: ModeAnimation
	Model Element	: _SysVehicule
//!	Generated Date	: Wed, 21, Oct 2026  
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.h
*********************************************************************/

#ifndef _SysVehicule_H
#define _SysVehicule_H

//## dependency math
#include <math.h>
//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "Windows.h"
//## auto_generated
#include "stdlib.h"
//## auto_generated
#include "stdio.h"
//## auto_generated
#include "string.h"
//## auto_generated
#include "stdint.h"
//## auto_generated
#include "tchar.h"
//## auto_generated
#include "_MonPkg.h"
//## auto_generated
#include <oxf\omthread.h>
//## auto_generated
#include <oxf\omreactive.h>
//## auto_generated
#include <oxf\state.h>
//## auto_generated
#include <oxf\event.h>
//#[ ignore
#define OMAnim__MonPkg__SysVehicule_setAccelPedal_double_ARGS_DECLARATION double p_accelPedal;

#define OMAnim__MonPkg__SysVehicule_setAffichage_liste_appareils_OMString_ARGS_DECLARATION OMString p_affichage_liste_appareils;

#define OMAnim__MonPkg__SysVehicule_setAlpha_int_ARGS_DECLARATION int p_alpha;

#define OMAnim__MonPkg__SysVehicule_setBrakePedal_double_ARGS_DECLARATION double p_brakePedal;

#define OMAnim__MonPkg__SysVehicule_setChamp_mdp_OMString_ARGS_DECLARATION OMString p_champ_mdp;

#define OMAnim__MonPkg__SysVehicule_setCmd_contact_bool_ARGS_DECLARATION bool p_cmd_contact;
//#]

//## package _MonPkg

//## class _SysVehicule
class _SysVehicule : public OMThread, public OMReactive {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimated_SysVehicule;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    ////    Operations    ////
    
    //## operation accelerer(double)
    void accelerer(double accelPedal);
    
    //## operation arreter()
    void arreter();
    
    //## operation ex_demarrer()
    void ex_demarrer();
    
    //## operation calcul_vitesse_distance()
    void calcul_vitesse_distance();
    
    //## operation freiner_injection(double)
    void freiner_injection(double brakePedal);
    
    ////    Additional operations    ////
    
    ////    Attributes    ////

protected :

    double brakePedal;		//## attribute brakePedal
    
    int distance;		//## attribute distance
    
    bool ignition;		//## attribute ignition
    
    int speed;		//## attribute speed
    
    ////    Relations and components    ////
    
    ////    Framework operations    ////
    
    double throttle;		//## attribute throttle

public :

    //## operation init()
    void init();

protected :

    double float_speed;		//## attribute float_speed
    
    double accelPedal;		//## attribute accelPedal
    
    int alpha;		//## attribute alpha
    
    double float_distance;		//## attribute float_distance
    
    bool _simu;		//## attribute _simu
    
    int vitesseConsigne;		//## attribute vitesseConsigne

public :

    //## auto_generated
    ~_SysVehicule();
    
    //## auto_generated
    bool get_simu();
    
    //## auto_generated
    void set_simu(bool p__simu);
    
    //## auto_generated
    double getAccelPedal();
    
    //## auto_generated
    void setAccelPedal(double p_accelPedal);
    
    //## auto_generated
    int getAlpha();
    
    //## auto_generated
    void setAlpha(int p_alpha);
    
    //## auto_generated
    double getBrakePedal();
    
    //## auto_generated
    void setBrakePedal(double p_brakePedal);
    
    //## auto_generated
    int getDistance();
    
    //## auto_generated
    void setDistance(int p_distance);
    
    //## auto_generated
    bool getIgnition();
    
    //## auto_generated
    int getSpeed();
    
    //## auto_generated
    double getSteady();
    
    //## auto_generated
    void setSteady(double p_steady);
    
    //## auto_generated
    double getThrottle();
    
    //## auto_generated
    int getVitesseConsigne();
    
    //## auto_generated
    void setVitesseConsigne(int p_vitesseConsigne);
    
    //## auto_generated
    virtual bool startBehavior();
    
    //## operation _SysVehicule()
    _SysVehicule(IOxfActive* theActiveContext = 0);
    
    //## operation Operation_168()
    void Operation_168();
    
    //## operation alerte_depassement(int)
    void alerte_depassement(int actif);
    
    //## operation calcul_batterie()
    void calcul_batterie();
    
    //## operation calcul_carburant()
    void calcul_carburant();
    
    //## operation calcul_regulateur_vitesse()
    void calcul_regulateur_vitesse();
    
    //## operation ex_depanner_batterie()
    void ex_depanner_batterie();
    
    //## operation ex_jumeler()
    void ex_jumeler();
    
    //## operation ex_ok()
    void ex_ok();
    
    //## operation ex_remplir_carburant()
    void ex_remplir_carburant();
    
    //## operation ex_vitesseConsigne(int)
    void ex_vitesseConsigne(int delta);
    
    //## operation regulateur_Prof()
    void regulateur_Prof();
    
    //## auto_generated
    double getKi_regulateur();
    
    //## auto_generated
    void setKi_regulateur(double p_Ki_regulateur);
    
    //## auto_generated
    double getKp_regulateur();
    
    //## auto_generated
    void setKp_regulateur(double p_Kp_regulateur);
    
    //## auto_generated
    double getPARAM_SIMU_Ki_regulateur();
    
    //## auto_generated
    void setPARAM_SIMU_Ki_regulateur(double p_PARAM_SIMU_Ki_regulateur);
    
    //## auto_generated
    double getPARAM_SIMU_Kp_regulateur();
    
    //## auto_generated
    void setPARAM_SIMU_Kp_regulateur(double p_PARAM_SIMU_Kp_regulateur);
    
    //## auto_generated
    int getPARAM_SIMU_freq_rafraichissement();
    
    //## auto_generated
    void setPARAM_SIMU_freq_rafraichissement(int p_PARAM_SIMU_freq_rafraichissement);
    
    //## auto_generated
    int getPARAM_SIMU_freq_regulateur();
    
    //## auto_generated
    void setPARAM_SIMU_freq_regulateur(int p_PARAM_SIMU_freq_regulateur);
    
    //## auto_generated
    double getPARAM_SIMU_frottement_air();
    
    //## auto_generated
    void setPARAM_SIMU_frottement_air(double p_PARAM_SIMU_frottement_air);
    
    //## auto_generated
    int getPARAM_SIMU_masse();
    
    //## auto_generated
    void setPARAM_SIMU_masse(int p_PARAM_SIMU_masse);
    
    //## auto_generated
    int getPARAM_SIMU_max_accel();
    
    //## auto_generated
    void setPARAM_SIMU_max_accel(int p_PARAM_SIMU_max_accel);
    
    //## auto_generated
    int getPARAM_SIMU_max_brake();
    
    //## auto_generated
    void setPARAM_SIMU_max_brake(int p_PARAM_SIMU_max_brake);
    
    //## auto_generated
    int getPARAM_SIMU_max_speed();
    
    //## auto_generated
    void setPARAM_SIMU_max_speed(int p_PARAM_SIMU_max_speed);
    
    //## auto_generated
    double getPARAM_SIMU_max_throttle();
    
    //## auto_generated
    void setPARAM_SIMU_max_throttle(double p_PARAM_SIMU_max_throttle);
    
    //## auto_generated
    int getPARAM_SIMU_puissance_frein();
    
    //## auto_generated
    void setPARAM_SIMU_puissance_frein(int p_PARAM_SIMU_puissance_frein);
    
    //## auto_generated
    int getPARAM_SIMU_puissance_moteur();
    
    //## auto_generated
    void setPARAM_SIMU_puissance_moteur(int p_PARAM_SIMU_puissance_moteur);
    
    //## auto_generated
    int getPARAM_SIMU_vitesse_repos();
    
    //## auto_generated
    void setPARAM_SIMU_vitesse_repos(int p_PARAM_SIMU_vitesse_repos);
    
    //## auto_generated
    double getSEUIL_batterie();
    
    //## auto_generated
    void setSEUIL_batterie(double p_SEUIL_batterie);
    
    //## auto_generated
    double getSEUIL_carburant();
    
    //## auto_generated
    void setSEUIL_carburant(double p_SEUIL_carburant);
    
    //## auto_generated
    bool getVOYANT_bluetooth_vehicule();
    
    //## auto_generated
    void setVOYANT_bluetooth_vehicule(bool p_VOYANT_bluetooth_vehicule);
    
    //## auto_generated
    bool getVOYANT_telephone_appairage();
    
    //## auto_generated
    void setVOYANT_telephone_appairage(bool p_VOYANT_telephone_appairage);
    
    //## auto_generated
    bool getVOYANT_telephone_connecte();
    
    //## auto_generated
    void setVOYANT_telephone_connecte(bool p_VOYANT_telephone_connecte);
    
    //## auto_generated
    bool getVOYANT_vehicule_connectee();
    
    //## auto_generated
    void setVOYANT_vehicule_connectee(bool p_VOYANT_vehicule_connectee);
    
    //## auto_generated
    OMString getAffichage_appairage();
    
    //## auto_generated
    void setAffichage_appairage(OMString p_affichage_appairage);
    
    //## auto_generated
    OMString getAffichage_liste_appareils();
    
    //## auto_generated
    void setAffichage_liste_appareils(OMString p_affichage_liste_appareils);
    
    //## auto_generated
    bool getBatterie_faible();
    
    //## auto_generated
    void setBatterie_faible(bool p_batterie_faible);
    
    //## auto_generated
    bool getCarburant_faible();
    
    //## auto_generated
    void setCarburant_faible(bool p_carburant_faible);
    
    //## auto_generated
    OMString getChamp_mdp();
    
    //## auto_generated
    void setChamp_mdp(OMString p_champ_mdp);
    
    //## auto_generated
    bool getCmd_contact();
    
    //## auto_generated
    void setCmd_contact(bool p_cmd_contact);
    
    //## auto_generated
    double getFloat_distance();
    
    //## auto_generated
    void setFloat_distance(double p_float_distance);
    
    //## auto_generated
    double getFloat_speed();
    
    //## auto_generated
    void setFloat_speed(double p_float_speed);
    
    //## auto_generated
    void setIgnition(bool p_ignition);
    
    //## auto_generated
    bool getLimiteur_attente();
    
    //## auto_generated
    void setLimiteur_attente(bool p_limiteur_attente);
    
    //## auto_generated
    bool getLimiteur_depasse();
    
    //## auto_generated
    void setLimiteur_depasse(bool p_limiteur_depasse);
    
    //## auto_generated
    OMString getListe_appareils_detectes(int i1);
    
    //## auto_generated
    void setListe_appareils_detectes(int i1, OMString p_liste_appareils_detectes);
    
    //## auto_generated
    OMString getMessages_appairage(int i1);
    
    //## auto_generated
    void setMessages_appairage(int i1, OMString p_messages_appairage);
    
    //## auto_generated
    OMString getMot_de_passe();
    
    //## auto_generated
    void setMot_de_passe(OMString p_mot_de_passe);
    
    //## auto_generated
    double getNiveau_batterie();
    
    //## auto_generated
    void setNiveau_batterie(double p_niveau_batterie);
    
    //## auto_generated
    double getReservoir_carburant();
    
    //## auto_generated
    void setReservoir_carburant(double p_reservoir_carburant);
    
    //## auto_generated
    void setSpeed(int p_speed);
    
    //## auto_generated
    void setThrottle(double p_throttle);
    
    //## auto_generated
    double getThrottle_repos();
    
    //## auto_generated
    void setThrottle_repos(double p_throttle_repos);
    
    //## auto_generated
    int getValeur_initiale_limiteur();
    
    //## auto_generated
    void setValeur_initiale_limiteur(int p_valeur_initiale_limiteur);
    
    //## auto_generated
    bool getVoyant_limiteur();
    
    //## auto_generated
    void setVoyant_limiteur(bool p_voyant_limiteur);
    
    //## auto_generated
    bool getVoyant_regulateur();
    
    //## auto_generated
    void setVoyant_regulateur(bool p_voyant_regulateur);

protected :

    //## auto_generated
    void initStatechart();
    
    //## auto_generated
    void cancelTimeouts();
    
    //## auto_generated
    bool cancelTimeout(const IOxfTimeout* arg);
    
    double Ki_regulateur;		//## attribute Ki_regulateur
    
    double Kp_regulateur;		//## attribute Kp_regulateur
    
    double PARAM_SIMU_Ki_regulateur;		//## attribute PARAM_SIMU_Ki_regulateur
    
    double PARAM_SIMU_Kp_regulateur;		//## attribute PARAM_SIMU_Kp_regulateur
    
    int PARAM_SIMU_freq_rafraichissement;		//## attribute PARAM_SIMU_freq_rafraichissement
    
    int PARAM_SIMU_freq_regulateur;		//## attribute PARAM_SIMU_freq_regulateur
    
    double PARAM_SIMU_frottement_air;		//## attribute PARAM_SIMU_frottement_air
    
    int PARAM_SIMU_masse;		//## attribute PARAM_SIMU_masse
    
    int PARAM_SIMU_max_accel;		//## attribute PARAM_SIMU_max_accel
    
    int PARAM_SIMU_max_brake;		//## attribute PARAM_SIMU_max_brake
    
    int PARAM_SIMU_max_speed;		//## attribute PARAM_SIMU_max_speed
    
    double PARAM_SIMU_max_throttle;		//## attribute PARAM_SIMU_max_throttle
    
    int PARAM_SIMU_puissance_frein;		//## attribute PARAM_SIMU_puissance_frein
    
    int PARAM_SIMU_puissance_moteur;		//## attribute PARAM_SIMU_puissance_moteur
    
    int PARAM_SIMU_vitesse_repos;		//## attribute PARAM_SIMU_vitesse_repos
    
    double SEUIL_batterie;		//## attribute SEUIL_batterie
    
    double SEUIL_carburant;		//## attribute SEUIL_carburant
    
    bool VOYANT_bluetooth_vehicule;		//## attribute VOYANT_bluetooth_vehicule
    
    bool VOYANT_telephone_appairage;		//## attribute VOYANT_telephone_appairage
    
    bool VOYANT_telephone_connecte;		//## attribute VOYANT_telephone_connecte
    
    bool VOYANT_vehicule_connectee;		//## attribute VOYANT_vehicule_connectee
    
    OMString affichage_appairage;		//## attribute affichage_appairage
    
    OMString affichage_liste_appareils;		//## attribute affichage_liste_appareils
    
    bool batterie_faible;		//## attribute batterie_faible
    
    bool carburant_faible;		//## attribute carburant_faible
    
    OMString champ_mdp;		//## attribute champ_mdp
    
    bool cmd_contact;		//## attribute cmd_contact
    
    bool limiteur_attente;		//## attribute limiteur_attente
    
    bool limiteur_depasse;		//## attribute limiteur_depasse
    
    OMString liste_appareils_detectes[2];		//## attribute liste_appareils_detectes
    
    OMString messages_appairage[5];		//## attribute messages_appairage
    
    OMString mot_de_passe;		//## attribute mot_de_passe
    
    double niveau_batterie;		//## attribute niveau_batterie
    
    double reservoir_carburant;		//## attribute reservoir_carburant
    
    double steady;		//## attribute steady
    
    double throttle_repos;		//## attribute throttle_repos
    
    int valeur_initiale_limiteur;		//## attribute valeur_initiale_limiteur
    
    bool voyant_limiteur;		//## attribute voyant_limiteur
    
    bool voyant_regulateur;		//## attribute voyant_regulateur

public :

    // rootState:
    //## statechart_method
    inline bool rootState_IN() const;
    
    //## statechart_method
    virtual void rootState_entDef();
    
    //## statechart_method
    void rootStateEntDef();
    
    //## statechart_method
    void rootState_exit();
    
    //## statechart_method
    virtual IOxfReactive::TakeEventStatus rootState_processEvent();
    
    // Systeme:
    //## statechart_method
    inline bool Systeme_IN() const;
    
    //## statechart_method
    void Systeme_entDef();
    
    //## statechart_method
    void Systeme_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus Systeme_processEvent();
    
    // state_96:
    //## statechart_method
    inline bool state_96_IN() const;
    
    //## statechart_method
    void state_96_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_96_processEvent();
    
    // voy:
    //## statechart_method
    inline bool voy_IN() const;
    
    // initerfsegb:
    //## statechart_method
    inline bool initerfsegb_IN() const;
    
    // state_87:
    //## statechart_method
    inline bool state_87_IN() const;
    
    //## statechart_method
    void state_87_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_87_processEvent();
    
    // demarrage_bluetooth:
    //## statechart_method
    inline bool demarrage_bluetooth_IN() const;
    
    // bluetooth_desactive:
    //## statechart_method
    inline bool bluetooth_desactive_IN() const;
    
    // bluetooth_active:
    //## statechart_method
    inline bool bluetooth_active_IN() const;
    
    //## statechart_method
    void bluetooth_active_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus bluetooth_active_handleEvent();
    
    // telephone_connecte:
    //## statechart_method
    inline bool telephone_connecte_IN() const;
    
    // recherche_telephone:
    //## statechart_method
    inline bool recherche_telephone_IN() const;
    
    // state_76:
    //## statechart_method
    inline bool state_76_IN() const;
    
    //## statechart_method
    void state_76_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_76_processEvent();
    
    // limiteur_on:
    //## statechart_method
    inline bool limiteur_on_IN() const;
    
    //## statechart_method
    void limiteur_on_entDef();
    
    //## statechart_method
    void limiteur_on_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_on_processEvent();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_on_handleEvent();
    
    // state_82:
    //## statechart_method
    inline bool state_82_IN() const;
    
    //## statechart_method
    void state_82_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_82_processEvent();
    
    // state_82_plus:
    //## statechart_method
    inline bool state_82_plus_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_82_plus_handleEvent();
    
    // state_82_moins:
    //## statechart_method
    inline bool state_82_moins_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_82_moins_handleEvent();
    
    // maintien_consigne:
    //## statechart_method
    inline bool maintien_consigne_IN() const;
    
    //## statechart_method
    void maintien_consigne_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus maintien_consigne_handleEvent();
    
    // stabilisation:
    //## statechart_method
    inline bool stabilisation_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus stabilisation_handleEvent();
    
    // limite_tenue:
    //## statechart_method
    inline bool limite_tenue_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limite_tenue_handleEvent();
    
    // depassement:
    //## statechart_method
    inline bool depassement_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus depassement_handleEvent();
    
    // state_81:
    //## statechart_method
    inline bool state_81_IN() const;
    
    //## statechart_method
    void state_81_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_81_processEvent();
    
    // limiteur_inhibe:
    //## statechart_method
    inline bool limiteur_inhibe_IN() const;
    
    // limiteur_effectif:
    //## statechart_method
    inline bool limiteur_effectif_IN() const;
    
    // limiteur_off:
    //## statechart_method
    inline bool limiteur_off_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus limiteur_off_handleEvent();
    
    // state_75:
    //## statechart_method
    inline bool state_75_IN() const;
    
    //## statechart_method
    void state_75_entDef();
    
    //## statechart_method
    void state_75_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_75_processEvent();
    
    // remplir_carburant:
    //## statechart_method
    inline bool remplir_carburant_IN() const;
    
    // panne_carburant:
    //## statechart_method
    inline bool panne_carburant_IN() const;
    
    // panne_batterie:
    //## statechart_method
    inline bool panne_batterie_IN() const;
    
    // fonctionelle:
    //## statechart_method
    inline bool fonctionelle_IN() const;
    
    // depanner_batterie:
    //## statechart_method
    inline bool depanner_batterie_IN() const;
    
    // state_72:
    //## statechart_method
    inline bool state_72_IN() const;
    
    //## statechart_method
    void state_72_entDef();
    
    //## statechart_method
    void state_72_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_72_processEvent();
    
    // simulation_du_vehicule:
    //## statechart_method
    inline bool simulation_du_vehicule_IN() const;
    
    // state_71:
    //## statechart_method
    inline bool state_71_IN() const;
    
    //## statechart_method
    void state_71_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_71_processEvent();
    
    // mode_regulateur:
    //## statechart_method
    inline bool mode_regulateur_IN() const;
    
    //## statechart_method
    void mode_regulateur_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus mode_regulateur_handleEvent();
    
    // plus:
    //## statechart_method
    inline bool plus_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus plus_handleEvent();
    
    // moins:
    //## statechart_method
    inline bool moins_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus moins_handleEvent();
    
    // maintien:
    //## statechart_method
    inline bool maintien_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus maintien_handleEvent();
    
    // mode_manuel:
    //## statechart_method
    inline bool mode_manuel_IN() const;
    
    // state_62:
    //## statechart_method
    inline bool state_62_IN() const;
    
    //## statechart_method
    void state_62_entDef();
    
    //## statechart_method
    void state_62_exit();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_62_processEvent();
    
    // horloge_rafraichissement:
    //## statechart_method
    inline bool horloge_rafraichissement_IN() const;
    
    // state_61:
    //## statechart_method
    inline bool state_61_IN() const;
    
    //## statechart_method
    void state_61_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_61_processEvent();
    
    // contact_on:
    //## statechart_method
    inline bool contact_on_IN() const;
    
    //## statechart_method
    void contact_on_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus contact_on_handleEvent();
    
    // moteur_on:
    //## statechart_method
    inline bool moteur_on_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus moteur_on_handleEvent();
    
    // moteur_off:
    //## statechart_method
    inline bool moteur_off_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus moteur_off_handleEvent();
    
    // contact_off:
    //## statechart_method
    inline bool contact_off_IN() const;
    
    // state_60:
    //## statechart_method
    inline bool state_60_IN() const;
    
    //## statechart_method
    void state_60_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus state_60_processEvent();
    
    // regulateur:
    //## statechart_method
    inline bool regulateur_IN() const;
    
    // pedales:
    //## statechart_method
    inline bool pedales_IN() const;
    
    //## statechart_method
    void pedales_entDef();
    
    //## statechart_method
    IOxfReactive::TakeEventStatus pedales_handleEvent();
    
    // freinage_injection:
    //## statechart_method
    inline bool freinage_injection_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus freinage_injection_handleEvent();
    
    // acceleration:
    //## statechart_method
    inline bool acceleration_IN() const;
    
    //## statechart_method
    IOxfReactive::TakeEventStatus acceleration_handleEvent();

protected :

//#[ ignore
    enum _SysVehicule_Enum {
        OMNonState = 0,
        Systeme = 1,
        state_96 = 2,
        voy = 3,
        initerfsegb = 4,
        state_87 = 5,
        demarrage_bluetooth = 6,
        bluetooth_desactive = 7,
        bluetooth_active = 8,
        telephone_connecte = 9,
        recherche_telephone = 10,
        state_76 = 11,
        limiteur_on = 12,
        state_82 = 13,
        state_82_plus = 14,
        state_82_moins = 15,
        maintien_consigne = 16,
        stabilisation = 17,
        limite_tenue = 18,
        depassement = 19,
        state_81 = 20,
        limiteur_inhibe = 21,
        limiteur_effectif = 22,
        limiteur_off = 23,
        state_75 = 24,
        remplir_carburant = 25,
        panne_carburant = 26,
        panne_batterie = 27,
        fonctionelle = 28,
        depanner_batterie = 29,
        state_72 = 30,
        simulation_du_vehicule = 31,
        state_71 = 32,
        mode_regulateur = 33,
        plus = 34,
        moins = 35,
        maintien = 36,
        mode_manuel = 37,
        state_62 = 38,
        horloge_rafraichissement = 39,
        state_61 = 40,
        contact_on = 41,
        moteur_on = 42,
        moteur_off = 43,
        contact_off = 44,
        state_60 = 45,
        regulateur = 46,
        pedales = 47,
        freinage_injection = 48,
        acceleration = 49
    };
    
    int rootState_subState;
    
    int rootState_active;
    
    int state_96_subState;
    
    int state_96_active;
    
    int state_87_subState;
    
    int state_87_active;
    
    IOxfTimeout* state_87_timeout;
    
    int bluetooth_active_subState;
    
    IOxfTimeout* bluetooth_active_timeout;
    
    int state_76_subState;
    
    int state_76_active;
    
    int state_82_subState;
    
    int state_82_active;
    
    IOxfTimeout* state_82_timeout;
    
    int maintien_consigne_subState;
    
    IOxfTimeout* maintien_consigne_timeout;
    
    int state_81_subState;
    
    int state_81_active;
    
    int state_75_subState;
    
    int state_75_active;
    
    int state_72_subState;
    
    int state_72_active;
    
    int state_71_subState;
    
    int state_71_active;
    
    int mode_regulateur_subState;
    
    int state_62_subState;
    
    int state_62_active;
    
    IOxfTimeout* state_62_timeout;
    
    int state_61_subState;
    
    int state_61_active;
    
    int contact_on_subState;
    
    int contact_on_lastState;
    
    IOxfTimeout* state_61_timeout;
    
    int state_60_subState;
    
    int state_60_active;
    
    IOxfTimeout* state_60_timeout;
    
    int pedales_subState;
    
    IOxfTimeout* pedales_timeout;
//#]
};

#ifdef _OMINSTRUMENT
DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setAccelPedal_double)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setAffichage_liste_appareils_OMString)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setAlpha_int)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setBrakePedal_double)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setChamp_mdp_OMString)

DECLARE_OPERATION_CLASS(_MonPkg__SysVehicule_setCmd_contact_bool)

//#[ ignore
class OMAnimated_SysVehicule : virtual public AOMInstance {
    DECLARE_REACTIVE_META(_SysVehicule, OMAnimated_SysVehicule)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setAccelPedal_double)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setAffichage_liste_appareils_OMString)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setAlpha_int)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setBrakePedal_double)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setChamp_mdp_OMString)
    
    DECLARE_META_OP(_MonPkg__SysVehicule_setCmd_contact_bool)
    
    ////    Framework operations    ////
    
public :

    virtual void serializeAttributes(AOMSAttributes* aomsAttributes) const;
    
    //## statechart_method
    void rootState_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void Systeme_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_96_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void voy_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void initerfsegb_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_87_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void demarrage_bluetooth_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void bluetooth_desactive_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void bluetooth_active_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void telephone_connecte_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void recherche_telephone_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_76_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_on_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_82_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_82_plus_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_82_moins_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void maintien_consigne_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void stabilisation_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limite_tenue_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void depassement_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_81_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_inhibe_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_effectif_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void limiteur_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_75_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void remplir_carburant_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void panne_carburant_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void panne_batterie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void fonctionelle_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void depanner_batterie_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_72_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void simulation_du_vehicule_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_71_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void mode_regulateur_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void plus_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void moins_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void maintien_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void mode_manuel_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_62_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void horloge_rafraichissement_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_61_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void contact_on_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void moteur_on_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void moteur_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void contact_off_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_60_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void regulateur_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void pedales_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void freinage_injection_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void acceleration_serializeStates(AOMSState* aomsState) const;
};
//#]
#endif // _OMINSTRUMENT

inline bool _SysVehicule::rootState_IN() const {
    return true;
}

inline bool _SysVehicule::Systeme_IN() const {
    return rootState_subState == Systeme;
}

inline bool _SysVehicule::state_96_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::voy_IN() const {
    return state_96_subState == voy;
}

inline bool _SysVehicule::initerfsegb_IN() const {
    return state_96_subState == initerfsegb;
}

inline bool _SysVehicule::state_87_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::demarrage_bluetooth_IN() const {
    return state_87_subState == demarrage_bluetooth;
}

inline bool _SysVehicule::bluetooth_desactive_IN() const {
    return state_87_subState == bluetooth_desactive;
}

inline bool _SysVehicule::bluetooth_active_IN() const {
    return state_87_subState == bluetooth_active;
}

inline bool _SysVehicule::telephone_connecte_IN() const {
    return bluetooth_active_subState == telephone_connecte;
}

inline bool _SysVehicule::recherche_telephone_IN() const {
    return bluetooth_active_subState == recherche_telephone;
}

inline bool _SysVehicule::state_76_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::limiteur_on_IN() const {
    return state_76_subState == limiteur_on;
}

inline bool _SysVehicule::state_82_IN() const {
    return limiteur_on_IN();
}

inline bool _SysVehicule::state_82_plus_IN() const {
    return state_82_subState == state_82_plus;
}

inline bool _SysVehicule::state_82_moins_IN() const {
    return state_82_subState == state_82_moins;
}

inline bool _SysVehicule::maintien_consigne_IN() const {
    return state_82_subState == maintien_consigne;
}

inline bool _SysVehicule::stabilisation_IN() const {
    return maintien_consigne_subState == stabilisation;
}

inline bool _SysVehicule::limite_tenue_IN() const {
    return maintien_consigne_subState == limite_tenue;
}

inline bool _SysVehicule::depassement_IN() const {
    return maintien_consigne_subState == depassement;
}

inline bool _SysVehicule::state_81_IN() const {
    return limiteur_on_IN();
}

inline bool _SysVehicule::limiteur_inhibe_IN() const {
    return state_81_subState == limiteur_inhibe;
}

inline bool _SysVehicule::limiteur_effectif_IN() const {
    return state_81_subState == limiteur_effectif;
}

inline bool _SysVehicule::limiteur_off_IN() const {
    return state_76_subState == limiteur_off;
}

inline bool _SysVehicule::state_75_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::remplir_carburant_IN() const {
    return state_75_subState == remplir_carburant;
}

inline bool _SysVehicule::panne_carburant_IN() const {
    return state_75_subState == panne_carburant;
}

inline bool _SysVehicule::panne_batterie_IN() const {
    return state_75_subState == panne_batterie;
}

inline bool _SysVehicule::fonctionelle_IN() const {
    return state_75_subState == fonctionelle;
}

inline bool _SysVehicule::depanner_batterie_IN() const {
    return state_75_subState == depanner_batterie;
}

inline bool _SysVehicule::state_72_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::simulation_du_vehicule_IN() const {
    return state_72_subState == simulation_du_vehicule;
}

inline bool _SysVehicule::state_71_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::mode_regulateur_IN() const {
    return state_71_subState == mode_regulateur;
}

inline bool _SysVehicule::plus_IN() const {
    return mode_regulateur_subState == plus;
}

inline bool _SysVehicule::moins_IN() const {
    return mode_regulateur_subState == moins;
}

inline bool _SysVehicule::maintien_IN() const {
    return mode_regulateur_subState == maintien;
}

inline bool _SysVehicule::mode_manuel_IN() const {
    return state_71_subState == mode_manuel;
}

inline bool _SysVehicule::state_62_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::horloge_rafraichissement_IN() const {
    return state_62_subState == horloge_rafraichissement;
}

inline bool _SysVehicule::state_61_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::contact_on_IN() const {
    return state_61_subState == contact_on;
}

inline bool _SysVehicule::moteur_on_IN() const {
    return contact_on_subState == moteur_on;
}

inline bool _SysVehicule::moteur_off_IN() const {
    return contact_on_subState == moteur_off;
}

inline bool _SysVehicule::contact_off_IN() const {
    return state_61_subState == contact_off;
}

inline bool _SysVehicule::state_60_IN() const {
    return Systeme_IN();
}

inline bool _SysVehicule::regulateur_IN() const {
    return state_60_subState == regulateur;
}

inline bool _SysVehicule::pedales_IN() const {
    return state_60_subState == pedales;
}

inline bool _SysVehicule::freinage_injection_IN() const {
    return pedales_subState == freinage_injection;
}

inline bool _SysVehicule::acceleration_IN() const {
    return pedales_subState == acceleration;
}

#endif
/*********************************************************************
	File Path	: CodesGeneres\ModeAnimation\_SysVehicule.h
*********************************************************************/
